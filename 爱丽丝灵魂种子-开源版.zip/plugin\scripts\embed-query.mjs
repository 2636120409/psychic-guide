/**
 * 拿「你刚说的这句话」去比长账，看哪几条旧事被勾起来了。
 *
 * 读 memory-vectors.json 里存好的账向量，只给这一句话算一次向量，
 * 结果落 memory-query.json，给提示词那张索引用。
 *
 * 跑法：node scripts/embed-query.mjs "你刚说的那句"
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { isRuntimeText } from '../lib/memory-layers.mjs'
import { longTermWeight } from '../lib/decay.mjs'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const ROOT = path.join(HOME, 'auto-conversation-memory')
const VECTOR_FILE = path.join(ROOT, 'memory-vectors.json')
const BANK_FILE = path.join(ROOT, 'long-term', 'shared.json')
const OUT_FILE = path.join(ROOT, 'memory-query.json')
const PYTHON = process.env.DSH_PYTHON || 'python'
const SCRIPT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..', '..', 'tools', 'embed', 'embed_texts.py')

/** 一句话最多勾起几条。 */
const TOP = 2
/** 热层：余弦到这条线之上才算「想起来」。宁可少勾，别乱勾。 */
const HIT_ABOVE = 0.72
/** 冷层：门槛再高一档，而且一次最多浮一条。 */
const COLD_ABOVE = 0.76
const COLD_TOP = 1
const HOT_MIN_WEIGHT = 0.35
/** 太长的不算：那是别人的正文，不是问话。 */
const TEXT_LIMIT = 200

const keyOf = (text) => createHash('sha1').update(text).digest('hex')
const short = (text, limit = 20) => (text.length <= limit ? text : `${text.slice(0, limit)}…`)

const text = String(process.argv.slice(2).join(' ') || '').trim().slice(0, TEXT_LIMIT)
if (text.length === 0) {
  console.log('embed-query: 没话可查')
  process.exit(0)
}

let book
try {
  book = JSON.parse(fs.readFileSync(VECTOR_FILE, 'utf8'))
} catch {
  book = null
}
const vectors = book !== null && book !== undefined && book.vectors !== null && book.vectors !== undefined ? book.vectors : null
if (vectors === null || Object.keys(vectors).length === 0) {
  console.log('embed-query: 账向量还没算过，先跑 embed-bank')
  process.exit(0)
}

let entries = []
try {
  const bank = JSON.parse(fs.readFileSync(BANK_FILE, 'utf8'))
  entries = Array.isArray(bank.entries) ? bank.entries : []
} catch {
  entries = []
}

const result = spawnSync(PYTHON, [SCRIPT], {
  input: JSON.stringify([text]),
  encoding: 'utf8',
  timeout: 120000,
  maxBuffer: 16 * 1024 * 1024,
})
if ((result.error !== undefined && result.error !== null) || result.status !== 0) {
  console.log(`embed-query: 算向量失败 ${String(result.stderr || '').slice(0, 120)}`)
  process.exit(0)
}
const query = JSON.parse(result.stdout)[0] || []

const scored = []
for (const entry of entries) {
  if (entry === null || entry === undefined || typeof entry !== 'object') continue
  if (entry.superseded === true) continue
  const raw = String(entry.text || '').trim()
  if (raw.length === 0) continue
  if (isRuntimeText(raw)) continue
  const vector = vectors[keyOf(raw.slice(0, 400))]
  if (!Array.isArray(vector) || vector.length === 0) continue
  let dot = 0
  for (let index = 0; index < query.length; index += 1) dot += query[index] * (vector[index] || 0)
  const weight = longTermWeight(entry, Date.now())
  if (weight < 0.12) continue
  scored.push({ score: dot, text: raw, cold: weight < HOT_MIN_WEIGHT })
}
scored.sort((a, b) => b.score - a.score)
const hot = scored.filter((one) => one.cold !== true && one.score >= HIT_ABOVE).slice(0, TOP)
const cold = scored.filter((one) => one.cold === true && one.score >= COLD_ABOVE).slice(0, COLD_TOP)
const hits = [...hot, ...cold]
  .map((one) => ({ score: Number(one.score.toFixed(3)), text: short(one.text, 30), cold: one.cold === true }))

fs.mkdirSync(ROOT, { recursive: true })
fs.writeFileSync(OUT_FILE, JSON.stringify({ at: Date.now(), query: text, hits }))
console.log(`embed-query: ${hits.length} 条像`)
