/**
 * 自检：短期转写的清洗。
 * 跑法：node scripts/selftest-transcript.mjs
 */
import assert from 'node:assert/strict'
import * as transcript from '../lib/transcript.mjs'
const { sanitizeTranscript } = transcript

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const base = 1_000_000

check('正常几句原样留着', () => {
  const out = sanitizeTranscript([
    { at: base, role: 'user', text: '爱丽丝在么' },
    { at: base + 10_000, role: 'assistant', text: '在呢' },
  ])
  assert.equal(out.length, 2)
  assert.equal(out[0].role, 'user')
})

check('剥掉宿主注入的壳', () => {
  const out = sanitizeTranscript([{ at: base, role: 'user', text: '<persona_state>状态</persona_state>真正的话' }])
  assert.equal(out[0].text, '真正的话')
})

check('只剩壳的整句丢掉', () => {
  const out = sanitizeTranscript([{ at: base, role: 'user', text: '<persona>只有壳</persona>' }])
  assert.equal(out.length, 0)
})

check('一瞬间记两回的并成一回', () => {
  const out = sanitizeTranscript([
    { at: base, role: 'user', text: '同一句话' },
    { at: base + 1000, role: 'user', text: '同一句话' },
  ])
  assert.equal(out.length, 1)
})

check('隔得久了不算重复', () => {
  const out = sanitizeTranscript([
    { at: base, role: 'user', text: '同一句话' },
    { at: base + 60_000, role: 'user', text: '同一句话' },
  ])
  assert.equal(out.length, 2)
})

check('关键词随行，情绪与来客记号都留着', () => {
  const out = sanitizeTranscript([{
    at: base,
    role: 'user',
    text: '主人喜欢安静',
    keys: ['主人', '喜欢'],
    from: '阿明',
    external: true,
    emotion: { name: '喜', score: 0.8 },
    sessionId: 's1',
  }])
  assert.deepEqual(out[0].keys, ['主人', '喜欢'])
  assert.equal(out[0].from, '阿明')
  assert.equal(out[0].external, true)
  assert.equal(out[0].emotion.name, '喜')
  assert.equal(out[0].sessionId, 's1')
})

check('没给关键词就现算', () => {
  const out = sanitizeTranscript([{ at: base, role: 'user', text: '今天吃面' }])
  assert.ok(out[0].keys.length > 0)
})

check('坏条目跳过', () => {
  const out = sanitizeTranscript([null, '字', { role: 'user', text: '' }])
  assert.equal(out.length, 0)
})

check('添一句：剥壳、带词、留记号', () => {
  const added = transcript.appendMessage([], { role: 'user', text: '主人喜欢安静' }, { now: base, sessionId: 's1' })
  assert.equal(added.duplicate, false)
  assert.equal(added.transcript.length, 1)
  assert.equal(added.entry.text, '主人喜欢安静')
  assert.equal(added.entry.sessionId, 's1')
  assert.ok(added.entry.keys.length > 0)
})

check('添一句：一瞬间记两回算一回', () => {
  const first = transcript.appendMessage([], { role: 'user', text: '同一句' }, { now: base })
  const second = transcript.appendMessage(first.transcript, { role: 'user', text: '同一句' }, { now: base + 1000 })
  assert.equal(second.duplicate, true)
  assert.equal(second.transcript.length, 1)
})

check('添一句：只有壳的不收', () => {
  const added = transcript.appendMessage([], { role: 'user', text: '<persona>只有壳</persona>' }, { now: base })
  assert.equal(added.entry, null)
  assert.equal(added.transcript.length, 0)
})

check('添一句：外人与情绪读数随行', () => {
  const added = transcript.appendMessage([], {
    role: 'user',
    text: '听来的事',
    from: '阿明',
    emotion: { name: '喜', score: 0.7 },
  }, { now: base })
  assert.equal(added.entry.from, '阿明')
  assert.equal(added.entry.external, true)
  assert.equal(added.entry.emotion.name, '喜')
})

console.log(`\n共 ${count} 项，全过。`)
