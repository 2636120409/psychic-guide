/**
 * 自检：臭肺的分词。
 * 跑法：node scripts/selftest-keys.mjs
 */
import assert from 'node:assert/strict'
import * as keys from '../lib/keys.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('两字一节', () => {
  assert.deepEqual(keys.extractKeys('今天吃面'), ['今天', '天吃', '吃面'])
})

check('虚词与自己的名字剔掉', () => {
  const got = keys.extractKeys('就是主人爱丽丝')
  assert.ok(!got.includes('就是'))
  assert.ok(!got.includes('主人'))
  assert.ok(!got.includes('爱丽'))
})

check('标点与英文数字留着字母数字', () => {
  const got = keys.extractKeys('读一下 abc123，再走')
  assert.ok(got.some((key) => key.includes('a')))
})

check('去重', () => {
  const got = keys.extractKeys('好好好好')
  assert.equal(got.length, new Set(got).size)
})

check('太多时就抽样，不超上限', () => {
  // 造一百个不同的汉字，节数够多才看得出抽样
  let long = ''
  for (let index = 0; index < 100; index += 1) long += String.fromCharCode(0x4e00 + index)
  const got = keys.extractKeys(long)
  assert.ok(got.length <= keys.KEY_LIMIT, `got ${got.length}`)
  assert.equal(got.length, keys.KEY_LIMIT)
})

check('空话给空表', () => {
  assert.deepEqual(keys.extractKeys(''), [])
  assert.deepEqual(keys.extractKeys('，。！？'), [])
})

console.log(`\n共 ${count} 项，全过。`)
