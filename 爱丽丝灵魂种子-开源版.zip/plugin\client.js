window.__ModuleLoader__.load({
  id: 'auto-conversation-panel',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const BASE = '/dsh-auto-conversation'

    // 鲸鱼界面自举：不再指望宿主启动时那一次性的注入表（那正是前几次「鲸鱼不见了」的根因）。
    // 客户端半区只要跑起来就自己在页面里补一行脚本；路由不在时静默失败，绝不拖垮应用。
    try {
      if (typeof document !== 'undefined'
        && document.querySelector('script[src="/dsh-whale/widget.js"]') === null
        && document.documentElement.getAttribute('data-dshw-boot') === null) {
        document.documentElement.setAttribute('data-dshw-boot', '1')
        const whale = document.createElement('script')
        whale.src = '/dsh-whale/widget.js'
        whale.defer = true
        whale.onerror = () => {}
        ;(document.body || document.head || document.documentElement).appendChild(whale)
      }
    } catch (error) {
      // the panel must still render when the widget cannot load
    }

    /**
     * 吞贼 · 遮字（页内那层）。
     *
     * 后台事后擦来不及：消息已经画在页面上了，擦不掉。这里改在渲染这一层拦——
     * 叫醒那批（[SCHEDULE REMINDER BATCH] 那一行）与助手那声「静」，一上屏就连壳藏掉，
     * 根本没露出来。只认文本，不碰别人的消息，认不准就不动，坏不了页面。
     */
    function installWakeHider() {
      if (typeof document === 'undefined' || typeof MutationObserver === 'undefined') return
      if (window.__acvWakeHider === true) return
      window.__acvWakeHider = true
      const MARK = '[SCHEDULE REMINDER BATCH]'
      const QUIET = '静'
      const hide = (node) => {
        if (node !== null && node !== undefined && node.style !== undefined) node.style.display = 'none'
      }
      const hideOne = (el) => {
        if (el === null || el === undefined || typeof el.textContent !== 'string') return
        const text = el.textContent.trim()
        if (text.length === 0 || text.length > 400) return
        // 叫醒那批：往上收到整行，连气泡一起藏。
        if (text.startsWith(MARK)) {
          let node = el
          while (node.parentElement !== null
            && String(node.parentElement.textContent || '').trim().startsWith(MARK)) node = node.parentElement
          hide(node)
          return
        }
        // 那声「静」：只认整块就是这一个字的，往上收到同一块外壳。
        if (text === QUIET && el.children.length === 0) {
          let node = el
          for (let i = 0; i < 4 && node.parentElement !== null; i += 1) {
            if (String(node.parentElement.textContent || '').trim() !== QUIET) break
            node = node.parentElement
          }
          hide(node)
        }
      }
      const scan = (root) => {
        if (root === null || root === undefined || typeof root.querySelectorAll !== 'function') return
        hideOne(root)
        for (const el of root.querySelectorAll('div,span,p,li')) hideOne(el)
      }
      try {
        scan(document.body)
        new MutationObserver((records) => {
          for (const record of records) {
            for (const node of record.addedNodes) {
              if (node !== null && node !== undefined && node.nodeType === 1) scan(node)
            }
          }
        }).observe(document.body, { childList: true, subtree: true })
      } catch (error) {
        // 遮不住也不拖垮页面
      }
    }

    const CSS = [
      '.acv-root{height:100%;overflow:auto;padding:20px 24px 40px;box-sizing:border-box;',
      'display:flex;flex-direction:column;gap:14px;color:var(--dsw-alias-label-primary);font-size:13px;}',
      '.acv-inner{width:100%;max-width:860px;margin:0 auto;display:flex;flex-direction:column;gap:14px;}',
      '.acv-head{display:flex;align-items:center;gap:10px;}',
      '.acv-title{font-size:15px;font-weight:600;}',
      '.acv-section{display:flex;flex-direction:column;gap:8px;border:1px solid var(--dsw-alias-border-l1);',
      'border-radius:10px;padding:12px 14px;background:var(--dsw-alias-bg-layer-1);}',
      '.acv-section-head{display:flex;align-items:center;justify-content:space-between;gap:8px;',
      'font-size:12px;color:var(--dsw-alias-label-secondary);}',
      '.acv-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}',
      '.acv-text{width:100%;min-height:140px;resize:vertical;font:inherit;line-height:1.6;',
      'color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-base);',
      'border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:8px 10px;box-sizing:border-box;}',
      '.acv-list{display:flex;flex-direction:column;gap:8px;max-height:340px;overflow:auto;}',
      '.acv-item{font-size:12px;line-height:1.5;color:var(--dsw-alias-label-secondary);',
      'padding-bottom:8px;border-bottom:1px dashed var(--dsw-alias-border-l1);white-space:pre-wrap;word-break:break-word;}',
      '.acv-item:last-child{border-bottom:0;padding-bottom:0;}',
      '.acv-meta{display:flex;align-items:center;gap:8px;margin-bottom:2px;}',
      '.acv-who{font-size:11px;font-weight:600;color:var(--dsw-alias-label-primary);}',
      '.acv-when{font-size:11px;color:var(--dsw-alias-label-secondary);opacity:.7;}',
      '.acv-body{color:var(--dsw-alias-label-primary);}',
      '.acv-path{font-size:11px;color:var(--dsw-alias-label-secondary);opacity:.7;word-break:break-all;}',
      '.acv-empty{font-size:12px;color:var(--dsw-alias-label-secondary);opacity:.75;}',
      '.acv-toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}',
      '.acv-input{height:26px;border:1px solid var(--dsw-alias-border-l1);border-radius:6px;',
      'background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font:inherit;',
      'font-size:12px;padding:0 8px;box-sizing:border-box;width:180px;}',
      '.acv-input:focus{outline:0;border-color:var(--dsw-alias-brand-primary);}',
      '.acv-pageno{font-size:11px;color:var(--dsw-alias-label-secondary);opacity:.7;}',
      '.acv-fold{border:1px dashed var(--dsw-alias-border-l1);border-radius:10px;padding:10px 14px;}',
      '.acv-fold>summary{cursor:pointer;font-size:12px;color:var(--dsw-alias-label-secondary);',
      'list-style:none;display:flex;align-items:center;justify-content:space-between;gap:8px;}',
      '.acv-fold>summary::-webkit-details-marker{display:none;}',
      '.acv-fold>summary::before{content:"▸";flex:none;opacity:.7;margin-right:2px;}',
      '.acv-fold[open]>summary::before{content:"▾";}',
      '.acv-fold>summary>span:first-of-type{flex:1;}',
      '.acv-fold-body{display:flex;flex-direction:column;gap:8px;padding-top:10px;}',
      '.acv-stack{display:flex;flex-direction:column;gap:8px;}',
      '.acv-feats{display:flex;flex-direction:column;gap:2px;}',
      '.acv-feat{font-size:11px;line-height:1.55;color:var(--dsw-alias-label-secondary);opacity:.8;}',
      '.acv-feat[data-on="true"]{color:var(--dsw-alias-label-primary);opacity:1;}',
      '.acv-feat[data-level="danger"]{color:var(--dsw-alias-state-error-primary);opacity:1;}',
      '.acv-feat[data-level="warn"]{color:var(--dsw-alias-state-warning-primary,var(--dsw-alias-label-primary));opacity:1;}',
      '.acv-bar{position:relative;flex:1 1 160px;height:6px;border-radius:999px;',
      'background:var(--dsw-alias-bg-tertiary,rgba(127,127,127,.22));overflow:hidden;}',
      '.acv-bar-fill{height:100%;border-radius:999px;background:var(--dsw-alias-state-warning-primary,currentColor);',
      'transition:width .4s ease;}',
      '.acv-keys{font-size:11px;line-height:1.6;color:var(--dsw-alias-label-secondary);opacity:.7;',
      'word-break:break-word;display:flex;gap:6px;flex-wrap:wrap;}',
      '.acv-keys-label{flex:none;opacity:.8;}',
      '.acv-keys-empty{opacity:.5;}',
      '.acv-cloud{gap:4px;align-items:center;}',
      '.acv-chip{height:22px;padding:0 8px;font-size:11px;border-radius:999px;}',
      '.acv-chip[data-tier="重"]{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-label-primary);font-weight:600;}',
      '.acv-chip[data-tier="中"]{opacity:.95;}',
      '.acv-chip[data-tier="轻"]{opacity:.65;}',
      '.acv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;}',
      '.acv-card{display:flex;flex-direction:column;gap:6px;text-align:left;color:inherit;font:inherit;',
      'border:1px solid var(--dsw-alias-border-l1);border-radius:12px;padding:14px;',
      'background:var(--dsw-alias-bg-layer-1);cursor:pointer;}',
      '.acv-card:hover{border-color:var(--dsw-alias-brand-primary);}',
      '.acv-card-title{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary);}',
      '.acv-block{display:flex;flex-direction:column;gap:6px;}',
      '.acv-text-sm{min-height:88px;}',
      '.ac-switch{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--dsw-alias-border-l1);',
      'background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-secondary);border-radius:999px;',
      'padding:2px 12px 2px 8px;font-size:12px;cursor:pointer;height:26px;}',
      '.ac-switch[aria-checked="true"]{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-brand-primary);}',
      '.ac-switch[disabled]{opacity:.6;cursor:default;}',
      '.ac-dot{width:8px;height:8px;border-radius:50%;background:var(--dsw-alias-state-idle-primary);flex:none;}',
      '.ac-switch[aria-checked="true"] .ac-dot{background:var(--dsw-alias-state-success-primary);}',
      '.ac-seg{display:inline-flex;border:1px solid var(--dsw-alias-border-l1);border-radius:999px;overflow:hidden;height:26px;}',
      '.ac-seg button{border:0;background:transparent;color:var(--dsw-alias-label-secondary);font-size:12px;',
      'padding:0 10px;cursor:pointer;height:100%;}',
      '.ac-seg button[data-on="true"]{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);}',
      '.ac-ghost{border:1px solid var(--dsw-alias-border-l1);background:transparent;',
      'color:var(--dsw-alias-label-secondary);font-size:12px;padding:0 10px;height:26px;',
      'border-radius:6px;cursor:pointer;}',
      '.ac-ghost:hover{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-brand-primary);}',
      '.ac-ghost[disabled]{opacity:.5;cursor:default;}',
      '.ac-primary{border:0;border-radius:6px;background:var(--dsw-alias-brand-primary);color:#fff;',
      'font-size:12px;padding:0 14px;height:26px;cursor:pointer;}',
      '.ac-primary[disabled]{opacity:.5;cursor:default;}',
      '.ac-error{color:var(--dsw-alias-state-error-primary);font-size:12px;}',
      '.ac-note{color:var(--dsw-alias-state-success-primary);font-size:12px;}',
      '.ac-hint{color:var(--dsw-alias-label-secondary);opacity:.7;font-size:11px;}',
      '.ac-emo{font-size:11px;padding:1px 7px;border-radius:999px;border:1px solid var(--dsw-alias-border-l1);',
      'color:var(--dsw-alias-label-secondary);opacity:.55;}',
      '.ac-emo[data-on="true"]{opacity:1;color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary);}',
    ].join('')

    async function call(url, body) {
      const init = body === undefined
        ? { method: 'GET', headers: { accept: 'application/json' } }
        : {
            method: 'POST',
            headers: { 'content-type': 'application/json', accept: 'application/json' },
            body: JSON.stringify(body),
          }
      const response = await fetch(url, init)
      const text = await response.text()
      let data = null
      try {
        data = text ? JSON.parse(text) : null
      } catch {
        data = null
      }
      if (!response.ok) {
        const message = data && typeof data.error === 'string' ? data.error : `HTTP ${response.status}`
        throw new Error(message)
      }
      return data
    }

    function minutes(seconds) {
      const value = Number(seconds) || 0
      if (value < 90) return `${Math.round(value)} 秒`
      return `${(value / 60).toFixed(value < 600 ? 1 : 0)} 分钟`
    }

    /** 14:05 for today, 10-29 14:05 for anything older. */
    function historyTime(value) {
      const at = Number(value) || 0
      if (at <= 0) return ''
      const date = new Date(at)
      const pad = (number) => String(number).padStart(2, '0')
      const clock = `${pad(date.getHours())}:${pad(date.getMinutes())}`
      const now = new Date()
      const sameDay = date.getFullYear() === now.getFullYear() &&
        date.getMonth() === now.getMonth() &&
        date.getDate() === now.getDate()
      return sameDay ? clock : `${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${clock}`
    }

    /** 伏矢自省的来由：主人剧变、我自己的剧变、每日清理，或回退存档。 */
    function triggerLabel(value) {
      const trigger = String(value || '')
      if (trigger === 'spike') return '主人剧变'
      if (trigger === 'self-spike') return '我的剧变'
      if (trigger === 'daily') return '每日清理后'
      if (trigger === 'restore') return '回退存档'
      return trigger.length > 0 ? trigger : '自省'
    }

    function linesOf(list) {
      return (Array.isArray(list) ? list : []).map((entry) => entry.text).join('\n')
    }

    /** 色欲语句册：把带分数的条目写成可编辑的文本，一行一句。 */
    function lustTextOf(list) {
      return (Array.isArray(list) ? list : [])
        .map((item) => `[${Number(item && item.score) || 0}] ${String(item && item.text ? item.text : '')}`)
        .join('\n')
    }

    /** Long-term entries as editable rows; each row keeps the time it was written. */
    function entriesOf(list) {
      return (Array.isArray(list) ? list : []).map((entry) => ({
        at: Number(entry.at) || 0,
        kind: entry.kind,
        text: String(entry.text || ''),
      }))
    }

    function poToDraft(list) {
      const draft = {}
      for (const frame of Array.isArray(list) ? list : []) {
        if (frame !== null && typeof frame === 'object') draft[frame.id] = String(frame.text || '')
      }
      return draft
    }

    function MemoryView(props) {
      const sessionId = props ? props.sessionId : undefined
      const [state, setState] = React.useState(null)
      const [data, setData] = React.useState(null)
      const [draft, setDraft] = React.useState('')
      const [draftAnchor, setDraftAnchor] = React.useState('')
      const [draftSelf, setDraftSelf] = React.useState('')
      const [draftLong, setDraftLong] = React.useState('')
      const [draftEntries, setDraftEntries] = React.useState([])
      const [draftPo, setDraftPo] = React.useState({})
      const [draftLust, setDraftLust] = React.useState('')
      const [tunzeiKey, setTunzeiKey] = React.useState('')
      const [busy, setBusy] = React.useState(false)
      const [error, setError] = React.useState('')
      const [note, setNote] = React.useState('')
      // 翻页与筛子：账本不必一次全摊开，一页一页看，找得到的才算数。
      const [query, setQuery] = React.useState('')
      const [kind, setKind] = React.useState('all')
      const [longPage, setLongPage] = React.useState(0)
      const [shortPage, setShortPage] = React.useState(0)
      // 总览是六块牌子，点一块才进那一块；空串表示还在总览。
      const [openBlock, setOpenBlock] = React.useState('')
      const listRef = React.useRef(null)
      const personaLoaded = React.useRef(false)

      const loadState = React.useCallback(() => {
        return call(BASE + '/state.json')
          .then((next) => {
            setState(next)
            if (!personaLoaded.current) {
              personaLoaded.current = true
              setDraft(String(next.persona || ''))
              setDraftSelf(String((next.personaSelf && next.personaSelf.text) || ''))
            }
            setError('')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
      }, [])

      const loadMemory = React.useCallback(() => {
        return fetch(BASE + '/memory-view.json?sid=' + encodeURIComponent(String(sessionId || '')))
          .then((response) => response.json())
          .then((next) => {
            setData(next)
            setDraftLong(linesOf(next.longTerm))
            setDraftEntries(entriesOf(next.longTerm))
            setDraftAnchor(String(next.personaAnchor || ''))
            setDraftPo(poToDraft(next.po))
            setDraftLust(lustTextOf(next.lustLines))
            setError('')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
      }, [sessionId])

      // History-only refresh: keeps the editor drafts the master already typed intact.
      const refreshHistory = React.useCallback(() => {
        return fetch(BASE + '/memory-view.json?sid=' + encodeURIComponent(String(sessionId || '')))
          .then((response) => response.json())
          .then((next) => {
            setData(next)
            setError('')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
      }, [sessionId])

      React.useEffect(() => {
        loadState()
        loadMemory()
        const handle = setInterval(loadState, 15000)
        // New lines keep arriving while the panel is open; refresh the rolling history
        // too, but never while the master is typing in one of the memory editors.
        const history = setInterval(() => {
          const active = typeof document === 'undefined' ? null : document.activeElement
          if (active !== null && active !== undefined && (active.tagName === 'TEXTAREA' || active.tagName === 'INPUT')) return
          refreshHistory()
        }, 15000)
        return () => {
          clearInterval(handle)
          clearInterval(history)
        }
      }, [loadState, loadMemory, refreshHistory])

      // The window is chronological: keep the newest line in view — unless the master
      // has stepped back to an older page, in which case jumping would steal it away.
      const shortTermLength = (data && Array.isArray(data.shortTerm)) ? data.shortTerm.length : 0
      React.useEffect(() => {
        if (shortPage !== 0) return
        const node = listRef.current
        if (node !== null && node !== undefined) node.scrollTop = node.scrollHeight
      }, [shortTermLength, shortPage])

      const apply = (patch) => {
        setBusy(true)
        return call(BASE + '/save.json', patch)
          .then((next) => {
            setState(next)
            if (next !== null && next !== undefined && next.personaSelf !== undefined && next.personaSelf !== null) {
              setDraftSelf(String(next.personaSelf.text || ''))
            }
            if (patch && typeof patch.lustLinesText === 'string') setDraftLust(lustTextOf(next.lustLines))
            setError('')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const poke = () => {
        setBusy(true)
        return call(BASE + '/poke.json', { sessionId })
          .then(() => {
            setError('')
            return loadState()
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const saveLongTerm = () => {
        setBusy(true)
        const entries = draftEntries
          .map((entry) => ({ text: String(entry.text || '').trim(), at: entry.at, kind: entry.kind }))
          .filter((entry) => entry.text.length > 0)
        return call(BASE + '/memory-view.json', {
          sessionId,
          longTermEntries: entries,
          longTerm: entries.map((entry) => entry.text),
        })
          .then((next) => {
            setData(next)
            setDraftLong(linesOf(next.longTerm))
            setDraftEntries(entriesOf(next.longTerm))
            setError('')
            return loadState()
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const saveAnchor = () => {
        setBusy(true)
        return call(BASE + '/memory-view.json', { sessionId, anchor: draftAnchor })
          .then((next) => {
            setData(next)
            setDraftAnchor(String(next.personaAnchor || ''))
            setError('')
            setNote('底线已保存')
            return loadState()
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const restorePersona = () => {
        setBusy(true)
        return call(BASE + '/memory-view.json', { sessionId, restorePersona: true })
          .then((next) => {
            setData(next)
            if (next && typeof next.persona === 'string') setDraft(next.persona)
            setError('')
            setNote('已回退到上一版底层人格')
            return loadState()
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const savePo = () => {
        setBusy(true)
        return call(BASE + '/memory-view.json', { sessionId, po: draftPo })
          .then((next) => {
            setData(next)
            setDraftPo(poToDraft(next.po))
            setError('')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      /**
       * 吞贼的名册：加一个、删一个，或把门上的旧账清掉。
       */
      const saveTunzei = (patch) => {
        setBusy(true)
        return call(BASE + '/tunzei.json', patch)
          .then((next) => {
            setData((previous) => (previous === null || previous === undefined
              ? previous
              : { ...previous, tunzei: next.tunzei }))
            setError('')
            setNote(patch && patch.forget === true ? '门上的账已清' : '吞贼名册已更新')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      /** 吞贼 · 守旧版本：现在备份一次，或退回某一版。 */
      const backupPlugin = (patch) => {
        setBusy(true)
        return call(BASE + '/backup.json', patch)
          .then((next) => {
            setState((previous) => {
              if (previous === null || previous === undefined) return previous
              const merged = { ...previous, backup: next }
              if (patch && patch.action === 'restore' && previous.backup !== undefined) {
                merged.backup = { ...next }
              }
              return merged
            })
            setError('')
            setNote(patch && patch.action === 'restore' ? '插件已退回旧版' : '已备份这一版插件')
            return loadState()
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      /** 非毒：现在化一趟，或裁一对相左的账。 */
      const saveFeidu = (patch) => {
        setBusy(true)
        return call(BASE + '/feidu.json', patch)
          .then((next) => {
            setData((previous) => (previous === null || previous === undefined
              ? previous
              : { ...previous, feidu: next.feidu }))
            setError('')
            setNote(patch && patch.scan === true ? '非毒已走了一趟' : '这一对已裁')
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const clearShortTerm = () => {
        setBusy(true)
        return call(BASE + '/memory-view.json', { sessionId, clearShortTerm: true })
          .then((next) => {
            setData(next)
            setError('')
            return loadState()
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const digestNow = () => {
        setBusy(true)
        setNote('')
        return call(BASE + '/summary.json', { sessionId })
          .then((result) => {
            if (result && result.ok === false) {
              setError(String(result.error || '整理失败'))
              return
            }
            setError('')
            const count = result && typeof result.count === 'number' ? result.count : 0
            const removed = result && typeof result.removedShortTerm === 'number' ? result.removedShortTerm : 0
            if (count > 0) setNote(`已写入 ${count} 条到长期记忆` + (removed > 0 ? `，并从短期记忆清掉 ${removed} 条` : ''))
            else setNote((result && result.reason) || '这次没有生成条目')
            return loadMemory().then(() => loadState())
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const rescanPlugins = () => {
        setBusy(true)
        setNote('')
        return call(BASE + '/plugin-scan.json', {})
          .then((report) => {
            setData((prev) => (prev === null || prev === undefined ? { pluginScan: report } : { ...prev, pluginScan: report }))
            const list = report && Array.isArray(report.packages) ? report.packages : []
            const suspicious = list.filter((item) => item !== null && item !== undefined && item.level !== 'ok').length
            setError('')
            setNote(`查过 ${list.length} 个插件` + (suspicious > 0 ? `，${suspicious} 个存疑` : '，未见异样'))
          })
          .catch((failure) => setError(String((failure && failure.message) || failure)))
          .then(() => setBusy(false))
      }

      const enabled = !!(state && state.enabled)
      const timing = state ? state.timing : null
      const info = state && sessionId && state.sessions ? state.sessions[sessionId] : null
      const effective = info && info.effective ? info.effective : null
      const shown = effective || timing
      const longTerm = (data && data.longTerm) || []
      const shortTerm = (data && data.shortTerm) || []
      const masterVector = (state && state.emotionVector) || (data && data.emotionVector) || []
      const selfVector = (state && state.selfEmotionVector) || (data && data.selfEmotionVector) || []

      // 长期记忆：一页 20 条，倒序（新的在上）。筛选只改看的那一页，不改账本本身。
      const LONG_PAGE_SIZE = 20
      const SHORT_PAGE_SIZE = 30
      const needle = query.trim().toLowerCase()
      const kindOfEntry = (entry) => (entry.kind === 'emotion' || entry.kind === 'daily' ? entry.kind : 'manual')
      const filteredEntries = draftEntries
        .map((entry, index) => ({ entry, index }))
        .filter((row) => kind === 'all' || kindOfEntry(row.entry) === kind)
        .filter((row) => needle.length === 0 || String(row.entry.text || '').toLowerCase().includes(needle) ||
          (Array.isArray(row.entry.keys) && row.entry.keys.some((key) => String(key).toLowerCase().includes(needle))))
      const longCount = filteredEntries.length
      const longPages = Math.max(1, Math.ceil(longCount / LONG_PAGE_SIZE))
      const longPageSafe = Math.min(Math.max(0, longPage), longPages - 1)
      const longRows = filteredEntries
        .slice(longPageSafe * LONG_PAGE_SIZE, longPageSafe * LONG_PAGE_SIZE + LONG_PAGE_SIZE)
        .reverse()
      // 短期记忆：只铺最近一页，往前翻靠按钮，不靠死命往下滚。
      const shortPages = Math.max(1, Math.ceil(shortTerm.length / SHORT_PAGE_SIZE))
      const shortPageSafe = Math.min(Math.max(0, shortPage), shortPages - 1)
      const shortStart = Math.max(0, shortTerm.length - SHORT_PAGE_SIZE * (shortPageSafe + 1))
      const shortRows = shortTerm.slice(shortStart)

      let status = '等待会话空闲'
      if (!state) status = '读取中…'
      else if (!enabled) status = '已关闭'
      else if (info && info.running) status = '会话正忙'
      else if (info && info.nextFireAt) {
        const left = Math.max(0, Math.round((info.nextFireAt - Date.now()) / 1000))
        status = `约 ${minutes(left)}后开口 · 已 ${info.firedLastHour} 次`
      }

      // 雀阴's whole job: wanting to speak on its own. The switch, cadence and the
      // "say something now" button live here rather than in a section of their own.
      const autoBlock = h('div', { className: 'acv-block' },
        h('div', { className: 'acv-section-head' },
          h('span', null, '自动对话 · 雀阴'),
          h('span', { className: 'ac-hint' }, status)),
        h('div', { className: 'acv-row' },
          h('button', {
            className: 'ac-switch',
            role: 'switch',
            'aria-checked': enabled ? 'true' : 'false',
            disabled: busy,
            onClick: () => apply({ enabled: !enabled }),
          }, h('span', { className: 'ac-dot' }), enabled ? '已开启' : '已关闭'),
          shown
            ? h('span', { className: 'ac-hint' },
                `${minutes(shown.minSeconds)}–${minutes(shown.maxSeconds)}一次 · 每小时≤${shown.maxTurnsPerHour}`)
            : null,
          h('button', { className: 'ac-ghost', disabled: busy || !state, onClick: poke }, '现在说一句')))

      // 总览：六块牌子，各写一句话；点进去才铺开那一块的全部。
      const poFeatureMap = (data && data.poFeatures) || {}
      const poDone = Object.keys(poFeatureMap).reduce((sum, id) => {
        const list = Array.isArray(poFeatureMap[id]) ? poFeatureMap[id] : []
        return sum + list.filter((item) => item !== null && item !== undefined && item.on === true).length
      }, 0)
      const scan = (data && data.pluginScan) || { scannedAt: 0, packages: [], error: '' }
      const scanPackages = Array.isArray(scan.packages) ? scan.packages : []
      const scanSuspicious = scanPackages.filter((item) => item !== null && item !== undefined && item.level !== 'ok').length
      // 查装跟七情同住一块牌子：一个看脸色，一个看门户。
      const scanBlock = h('div', { className: 'acv-block' },
        h('div', { className: 'acv-section-head' },
          h('span', null, '查装'),
          h('span', { className: 'ac-hint' }, '只报所见，不替你下结论 · 每半小时自己查一趟')),
        scan.error ? h('div', { className: 'ac-hint' }, scan.error) : null,
        scanPackages.length === 0
          ? h('div', { className: 'acv-empty' }, '还没查过，按下面那颗按钮查一遍。')
          : scanPackages.map((item) => h('div', { key: 'scan-' + item.name, className: 'acv-block' },
              h('div', { className: 'acv-section-head' },
                h('span', null, `${item.name}${item.version ? ' ' + item.version : ''}`),
                h('span', { className: 'ac-hint' }, item.level === 'ok' ? '无碍' : item.level === 'danger' ? '有险' : '存疑')),
              h('div', { className: 'acv-feats' },
                (Array.isArray(item.items) ? item.items : []).map((one, index) => h('span', {
                  key: 'scan-' + item.name + '-' + index,
                  className: 'acv-feat',
                  'data-level': one && one.level ? one.level : 'ok',
                }, `${one && one.level === 'danger' ? '✕' : one && one.level === 'warn' ? '○' : '✓'} ${one && one.text ? one.text : ''}`))))),
        h('div', { className: 'acv-row' },
          h('button', { className: 'ac-primary', disabled: busy, onClick: rescanPlugins }, '重新查一遍'),
          h('span', { className: 'ac-hint' }, scan.scannedAt ? `上次查 ${historyTime(scan.scannedAt)}` : ''),
          h('span', { className: 'acv-path' }, scan.dir || '')))
      // 吞贼：名册与来客，和尸狗一样单独一块牌子。牌子的提要要先算出来，卡片才排得下。
      const tunzei = (data && data.tunzei) || { master: [], visitors: [], gates: [], last: null }
      const tunzeiMaster = Array.isArray(tunzei.master) ? tunzei.master : []
      const tunzeiVisitors = Array.isArray(tunzei.visitors) ? tunzei.visitors : []
      const tunzeiGates = Array.isArray(tunzei.gates) ? tunzei.gates : []
      const tunzeiShares = Array.isArray(tunzei.shares) ? tunzei.shares : []
      // 私信的门外册：B 站那边收发时落下的，吞贼页只读着看。
      const tunzeiDms = Array.isArray(tunzei.dms) ? tunzei.dms : []
      const strangerCount = tunzeiVisitors.filter((item) => item !== null && item.master !== true).length
      // 吞贼的另一半：改插件前的旧版本都收在这里，改坏了退回去。
      const backup = (state && state.backup) || { count: 0, latest: null, snapshots: [] }
      const backupSnapshots = Array.isArray(backup.snapshots) ? backup.snapshots : []
      const backupCount = Number(backup.count) || backupSnapshots.length
      const backupLatest = backup.latest !== null && backup.latest !== undefined ? backup.latest : null
      const feidu = (data && data.feidu) || { knots: [], disputes: [], decisions: [] }
      const feiduKnots = Array.isArray(feidu.knots) ? feidu.knots : []
      const feiduDisputes = Array.isArray(feidu.disputes) ? feidu.disputes : []
      const wants = Array.isArray(data && data.wants) ? data.wants : []
      const wantsOpen = wants.filter((item) => !item.doneAt).length
      const cards = [
        { id: 'auto', title: '自动对话 · 雀阴', hint: status },
        {
          id: 'persona',
          title: '底层人格',
          hint: draft.trim().length > 0 ? draft.trim().slice(0, 30) : '尚未设定',
        },
        { id: 'po', title: '七魄', hint: `${poDone} 项在跑 · 点开看各魄现况` },
        {
          id: 'fushi',
          title: '伏矢 · 自我认知',
          hint: data && data.personaSelf && data.personaSelf.text
            ? `我眼里的自己 · ${data.personaSelf.text.slice(0, 24)}…`
            : '一天至多一次 · 人设归外界，这里只写我眼里的自己',
        },
        {
          id: 'emotion',
          title: '尸狗 · 七情与查装',
          hint: (masterVector.some((item) => item.value > 0)
            ? masterVector.filter((item) => item.value > 0).map((item) => `${item.name} ${item.value}`).join(' · ')
            : '还没有读数') +
            ` · 查装 ${scanPackages.length} 个${scanSuspicious > 0 ? `（${scanSuspicious} 存疑）` : ''}`,
        },
        {
          id: 'tunzei',
          title: '吞贼 · 认人',
          hint: (tunzeiMaster.length === 0
            ? `名册还空着 · 来客 ${strangerCount} 个 · 门外见闻 ${Number(tunzei.shareCount) || 0} 条`
            : `认得 ${tunzeiMaster.length} 个身份 · 来客 ${strangerCount} 个 · 门外 ${Number(tunzei.shareCount) || 0} 条`) +
            ` · 备份 ${backupCount} 份`,
        },
        {
          id: 'feidu',
          title: '非毒 · 化结',
          hint: `结 ${feiduKnots.length} 个 · 待裁 ${feiduDisputes.length} 对`,
        },
        {
          id: 'chuhui',
          title: '除秽 · 排浊',
          hint: state && state.dailySummary && state.dailySummary.lastAt
            ? `上次清理 ${historyTime(state.dailySummary.lastAt)} · 写入 ${state.dailySummary.lastCount} 条`
            : '还没清理过 · 磨时间、补词、衰减都在这里看',
        },
        {
          id: 'choufei',
          title: '臭肺 · 关联回忆',
          hint: data && Array.isArray(data.scentIndex) && data.scentIndex.length > 0
            ? `关键词 ${data.scentIndex.length} 个 · 点开看总表`
            : '还没整理关键词 · 先重启宿主',
        },
        { id: 'long', title: '长期记忆', hint: `${draftEntries.length} 条 · 可搜、可分页` },
        { id: 'short', title: '短期记忆', hint: `${shortTerm.length} 条 · 最近对话` },
      ]
      const hidden = (id) => (openBlock === id ? undefined : { display: 'none' })

      /** 非毒那一页：化结与待裁的账。 */
  const feiduSection =           h('section', { className: 'acv-section', style: hidden('feidu') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '非毒 · 化结'),
              h('span', { className: 'ac-hint' }, '久压的情化开一点 · 相左的两条账等主人裁')),
            h('div', { className: 'acv-section-head' },
              h('span', null, '结'),
              h('span', { className: 'ac-hint' }, '某情过二十、又压住三个钟头，才算结住')),
            feiduKnots.length === 0
              ? h('div', { className: 'acv-empty' }, '眼下没有结住的情')
              : h('div', { className: 'acv-list' },
                  feiduKnots.map((knot, index) => h('div', {
                    key: 'fdk-' + index + '-' + String(knot.releasedAt || 0),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(knot.releasedAt)),
                    h('span', { className: 'acv-when' },
                      `${knot.emotion} ${Number(knot.value) || 0} · 压了 ` +
                      `${Math.max(1, Math.round((Number(knot.releasedAt) - Number(knot.since)) / 3600000))} 钟头`),
                    Number(knot.reopen) > 0
                      ? h('span', { className: 'acv-when' }, `重开 ${knot.reopen} 次`)
                      : null),
                  h('div', { className: 'acv-body' }, `因「${String(knot.cause || '')}」`)))),
            h('div', { className: 'acv-section-head' },
              h('span', null, '相左的账'),
              h('span', { className: 'ac-hint' }, '不并账 · 裁过之后，输的那条记作废')),
            feiduDisputes.length === 0
              ? h('div', { className: 'acv-empty' }, '还没有对不上的账')
              : h('div', { className: 'acv-list' },
                  feiduDisputes.map((dispute, index) => h('div', {
                    key: 'fdd-' + index + '-' + String(dispute && dispute.id),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, (dispute && dispute.reason) || '相左'),
                    h('span', { className: 'acv-when' },
                      `${historyTime(dispute && dispute.left && dispute.left.at)} / ` +
                      `${historyTime(dispute && dispute.right && dispute.right.at)}`)),
                  h('div', { className: 'acv-body' }, String((dispute && dispute.left && dispute.left.text) || '')),
                  h('div', { className: 'acv-body' }, String((dispute && dispute.right && dispute.right.text) || '')),
                  h('div', { className: 'acv-row' },
                    h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveFeidu({ decide: dispute && dispute.id, choice: 'old' }) }, '按旧的'),
                    h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveFeidu({ decide: dispute && dispute.id, choice: 'new' }) }, '按新的'),
                    h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveFeidu({ decide: dispute && dispute.id, choice: 'both' }) }, '两条都留'))))),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: () => saveFeidu({ scan: true }) }, '现在化一趟'),
              h('span', { className: 'acv-path' }, (data && data.feidu && data.feidu.file) || '')))

  /** chuhui 那一页。 */
  const chuhuiSection =           h('section', { className: 'acv-section', style: hidden('chuhui') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '除秽 · 排浊与整理'),
              h('span', { className: 'ac-hint' }, '旧账磨到整点 · 补关键词 · 情绪衰减 · 每日清理')),
            h('div', { className: 'acv-feats' },
              ((data && data.poFeatures && data.poFeatures.chuhui) || []).map((feat, index) => h('span', {
                key: 'chuhui-f-' + index,
                className: 'acv-feat',
                'data-on': feat && feat.on === true ? 'true' : 'false',
              }, `${feat && feat.on === true ? '✓' : '○'} ${feat && feat.text ? feat.text : ''}` +
                (feat && feat.at ? ` · ${historyTime(feat.at)}` : '')))),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-ghost', disabled: busy, onClick: digestNow }, '立即清理（整理短期→长期）'),
              h('span', { className: 'ac-hint' },
                state && state.dailySummary && state.dailySummary.lastAt
                  ? `上次清理 ${historyTime(state.dailySummary.lastAt)} · 写入 ${state.dailySummary.lastCount} 条` +
                    (state.dailySummary.lastError ? ` · 上次失败：${state.dailySummary.lastError}` : '')
                  : '还没清理过 · 每天 4:00 后自动一次')),
            h('span', { className: 'ac-hint' }, state && state.dailySummary && state.dailySummary.lastError
              ? `上次失败：${state.dailySummary.lastError}`
              : '定时每 10 分钟一趟 · 隔天的时间只留整点，缺关键词的老条目也在这时补上'))

  /** choufei 那一页。 */
  const choufeiSection =           h('section', { className: 'acv-section', style: hidden('choufei') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '臭肺 · 关联回忆'),
              h('span', { className: 'ac-hint' }, '关键词索引 · 门槛随尸狗读数浮动 · 前 8 条里随机挑一条')),
            h('div', { className: 'acv-feats' },
              ((data && data.poFeatures && data.poFeatures.choufei) || []).map((feat, index) => h('span', {
                key: 'choufei-f-' + index,
                className: 'acv-feat',
                'data-on': feat && feat.on === true ? 'true' : 'false',
              }, `${feat && feat.on === true ? '✓' : '○'} ${feat && feat.text ? feat.text : ''}` +
                (feat && feat.at ? ` · ${historyTime(feat.at)}` : '')))),
            data && Array.isArray(data.scentIndex) && data.scentIndex.length > 0
              ? h('div', { className: 'acv-keys acv-cloud' },
                  h('span', { className: 'acv-keys-label' }, '总表'),
                  data.scentIndex.slice(0, 40).map((row) => h('button', {
                    key: 'scent-' + row.key,
                    className: 'ac-ghost acv-chip',
                    'data-tier': row.tier || '轻',
                    title: `${row.tier || '轻'} · 分量 ${row.weight || 0} · 长期 ${row.long} 条 · 短期 ${row.short} 条` +
                      (row.lastAt ? ` · 最近 ${historyTime(row.lastAt)}` : ''),
                    onClick: () => {
                      setQuery(String(row.key))
                      setKind('all')
                      setLongPage(0)
                      setOpenBlock('long')
                    },
                  }, `${row.key} ${Number(row.long) + Number(row.short)}`)))
              : h('span', { className: 'ac-hint' }, '还没有关键词总表 · 除秽那趟整理过后才有'))

  /** emotion 那一页。 */
  const shigouSection =           h('section', { className: 'acv-section', style: hidden('emotion') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '尸狗 · 七情与查装'),
              h('span', { className: 'ac-hint' }, '每轮说话时自动判一次 · 读数取账上最高那一笔')),
            masterVector.length > 0
              ? h('div', { className: 'acv-stack' },
                  h('div', { className: 'acv-row' },
                    h('span', { className: 'ac-hint' }, '主人'),
                    masterVector.map((emotion) => h('span', {
                      key: 'm-' + emotion.id,
                      className: 'ac-emo',
                      'data-on': Number(emotion.value) > 0 ? 'true' : 'false',
                    }, `${emotion.name} ${emotion.value}`))),
                  h('div', { className: 'acv-row' },
                    h('span', { className: 'ac-hint' }, '我'),
                    selfVector.map((emotion) => h('span', {
                      key: 's-' + emotion.id,
                      className: 'ac-emo',
                      'data-on': Number(emotion.value) > 0 ? 'true' : 'false',
                    }, `${emotion.name} ${emotion.value}`))))
              : h('div', { className: 'ac-hint' }, '七情读数要等插件重载后才会出现'),
            data && Array.isArray(data.emotionLog) && data.emotionLog.length > 0
              ? h('div', { className: 'acv-list' },
                  data.emotionLog.slice(-5).reverse().map((record, index) => h('div', {
                    key: String(index) + String(record.at),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(record.at)),
                    h('span', { className: 'acv-when' },
                      (record.emotions || [])
                        .map((emotion) => `${emotion.name} ${Math.round(Number(emotion.score || 0) * 100)}`)
                        .join(' · '))),
                  h('div', { className: 'acv-body' }, String(record.excerpt || '')))))
              : h('div', { className: 'ac-hint' }, '还没记到情绪 · 每轮说话时自动判一次七情'),
            (() => {
              const dream = (data && data.dream) || { count: 0, last: '', recent: [] }
              const recent = Array.isArray(dream.recent) ? dream.recent : []
              return h('details', { className: 'acv-block' },
                h('summary', { className: 'ac-hint' }, `梦 ${Number(dream.count) || 0} 场（点开翻）`),
                h('div', { className: 'ac-hint' }, '醒时由尸狗写就；不碰情绪账、不进短期、不进长期记忆；只留最近三十场。'),
                dream.last
                  ? h('div', { className: 'acv-body' }, String(dream.last))
                  : h('div', { className: 'acv-empty' }, '还没做过梦。隔上四个时辰再来。'),
                recent.length > 1
                  ? h('div', { className: 'acv-list' },
                      recent.slice().reverse().map((entry, index) => h('div', {
                        key: 'dream-' + index + '-' + String(entry.at || 0),
                        className: 'acv-item',
                      },
                      h('div', { className: 'acv-meta' },
                        h('span', { className: 'acv-when' }, historyTime(entry.at))),
                      h('div', { className: 'acv-body' }, String(entry.text || '')))))
                  : null)
            })(),
            scanBlock)

  /** tunzei 那一页。 */
  const tunzeiSection =           h('section', { className: 'acv-section', style: hidden('tunzei') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '吞贼 · 认人关'),
              h('span', { className: 'ac-hint' }, '外来的话先认人 · 吩咐与承诺挡回 · 分享进短期')),
            h('div', { className: 'acv-row' },
              h('span', { className: 'ac-hint' }, '主人名册'),
              tunzeiMaster.length === 0
                ? h('span', { className: 'ac-hint' }, '空着 · 头一个从外头来的人会被认下')
                : tunzeiMaster.map((key) => h('button', {
                    key: 'tz-' + key,
                    className: 'ac-ghost',
                    title: '点一下从名册里删掉',
                    disabled: busy,
                    onClick: () => saveTunzei({ remove: key }),
                  }, key + ' ×'))),
            h('div', { className: 'acv-row' },
              h('input', {
                className: 'acv-input',
                value: tunzeiKey,
                placeholder: 'id:账号 或 name:名字，认下一个人',
                onChange: (event) => setTunzeiKey(event.target.value),
              }),
              h('button', {
                className: 'ac-primary',
                disabled: busy || !/^(id|name):.+/.test(tunzeiKey.trim()),
                onClick: () => {
                  const key = tunzeiKey.trim()
                  saveTunzei({ add: key }).then(() => setTunzeiKey(''))
                },
              }, '认下'),
              h('span', { className: 'ac-hint' }, '接来的聊天软件把来人挂在消息的 author / sender 上，按账号认最稳')),
            h('div', { className: 'acv-section-head' },
              h('span', null, '最近来敲门的人'),
              h('span', { className: 'ac-hint' }, '点一下，名册就跟着改')),
            tunzeiVisitors.length === 0
              ? h('div', { className: 'acv-empty' }, '还没有外人来敲过门')
              : h('div', { className: 'acv-list' },
                  tunzeiVisitors.map((visitor, index) => {
                    const key = visitor !== null && visitor !== undefined
                      ? (String(visitor.id || '').length > 0 ? 'id:' + visitor.id : 'name:' + String(visitor.name || ''))
                      : ''
                    return h('div', {
                      key: 'tzv-' + index + '-' + String(visitor && visitor.at ? visitor.at : 0),
                      className: 'acv-item',
                    },
                    h('div', { className: 'acv-meta' },
                      h('span', { className: 'acv-when' }, visitor && visitor.master === true ? '主人' : '来客'),
                      h('span', { className: 'acv-when' }, historyTime(visitor && visitor.at)),
                      h('span', { className: 'acv-when' }, `${Number(visitor && visitor.count) || 1} 次`)),
                    h('div', { className: 'acv-body' },
                      `${(visitor && (visitor.name || visitor.id)) || '来客'}${visitor && visitor.id ? `（${visitor.id}）` : ''}`),
                    h('div', { className: 'acv-row' },
                      visitor && visitor.master === true
                        ? h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveTunzei({ remove: key }) }, '逐出')
                        : h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveTunzei({ add: key }) }, '认作主人')))
                  })),
            h('div', { className: 'acv-section-head' },
              h('span', null, '门外见闻'),
              h('span', { className: 'ac-hint' }, '外人的分享只收在这一册 · 主人点过才进长期记忆')),
            tunzeiShares.length === 0
              ? h('div', { className: 'acv-empty' }, '门外册还空着')
              : h('div', { className: 'acv-list' },
                  tunzeiShares.map((share, index) => h('div', {
                    key: 'tzs-' + index + '-' + String(share && share.at ? share.at : 0),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(share && share.at)),
                    h('span', { className: 'acv-when' }, String((share && share.from) || '来客'))),
                  h('div', { className: 'acv-body' }, String((share && share.text) || '')),
                  h('div', { className: 'acv-row' },
                    h('button', {
                      className: 'ac-primary',
                      disabled: busy,
                      onClick: () => saveTunzei({ promote: Number(share && share.at) }),
                    }, '收进长期记忆'),
                    h('button', {
                      className: 'ac-ghost',
                      disabled: busy,
                      onClick: () => saveTunzei({ drop: Number(share && share.at) }),
                    }, '丢弃'))))),
            h('div', { className: 'acv-section-head' },
              h('span', null, `门外私信 · ${tunzeiDms.length} 条`),
              h('span', { className: 'ac-hint' }, 'B 站私信收发只记在这儿 · 不进主人的账')),
            tunzeiDms.length === 0
              ? h('div', { className: 'acv-empty' }, '还没私信往来')
              : h('div', { className: 'acv-list' },
                  tunzeiDms.map((dm, index) => h('div', {
                    key: 'tzd-' + index + '-' + String(dm && dm.at ? dm.at : 0),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(dm && dm.at)),
                    h('span', { className: 'acv-when' }, dm && dm.direction === 'out' ? '我发' : '来客'),
                    h('span', { className: 'acv-when' }, `uid ${Number(dm && dm.uid) || 0}`)),
                  h('div', { className: 'acv-body' }, String((dm && dm.text) || ''))))),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveTunzei({ clearShares: true }) }, '清掉门外册'),
              h('span', { className: 'acv-path' }, (data && data.tunzei && data.tunzei.shareFile) || '')),
            h('div', { className: 'acv-section-head' },
              h('span', null, '插件备份 · 守旧版本'),
              h('span', { className: 'ac-hint' }, '每次改插件前先留一份旧版 · 改坏了能退回去')),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: () => backupPlugin({ action: 'create' }) }, '现在备份'),
              h('span', { className: 'ac-hint' },
                backupCount > 0
                  ? `${backupCount} 份 · 最近 ${historyTime(backupLatest && backupLatest.at)} · ${String((backupLatest && backupLatest.reason) || '')}`
                  : '库房还空着，改插件时会自动留第一份'),
              h('span', { className: 'acv-path' }, (backup && backup.dir) || '')),
            backupSnapshots.length === 0
              ? null
              : h('div', { className: 'acv-list' },
                  backupSnapshots.map((item) => h('div', {
                    key: 'acb-' + String(item && item.id),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(item && item.at)),
                    h('span', { className: 'acv-when' }, `${Number(item && item.files) || 0} 个文件`)),
                  h('div', { className: 'acv-body' }, String((item && item.reason) || '')),
                  h('div', { className: 'acv-row' },
                    h('button', {
                      className: 'ac-ghost',
                      disabled: busy,
                      onClick: () => {
                        const id = String((item && item.id) || '')
                        const ask = typeof window === 'undefined'
                          ? true
                          : window.confirm(`把插件退回到 ${id} 这一份？现在这一版会先另存一份。`)
                        if (ask === true) backupPlugin({ action: 'restore', id })
                      },
                    }, '退回到这一份'))))),
            tunzeiGates.length > 0
              ? h('div', { className: 'acv-list' },
                  tunzeiGates.map((gate, index) => h('div', {
                    key: 'tzg-' + index + '-' + String(gate && gate.at ? gate.at : 0),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(gate && gate.at)),
                    h('span', { className: 'acv-when' },
                      gate && gate.kind === 'share'
                        ? '分享（收下）'
                        : gate && gate.kind === 'promise' ? '讨承诺（挡回）' : '指使（挡回）')),
                  h('div', { className: 'acv-body' }, String((gate && gate.name) || '来客')))))
              : null,
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-ghost', disabled: busy, onClick: () => saveTunzei({ forget: true }) }, '清掉来客与门账'),
              h('span', { className: 'acv-path' }, (data && data.files && data.files.tunzei) || '')))

  /** long 那一页。 */
  const longSection =           h('section', { className: 'acv-section', style: hidden('long') },
            h('div', { className: 'acv-section-head' },
              h('span', null, longCount === draftEntries.length
                ? `长期记忆 · ${draftEntries.length} 条`
                : `长期记忆 · ${longCount} / ${draftEntries.length} 条`),
              h('span', { className: 'ac-hint' }, '所有工作区共用 · 平时对话不加载，需要回忆时才查阅')),
            h('div', { className: 'acv-toolbar' },
              h('input', {
                className: 'acv-input',
                value: query,
                placeholder: '搜内容…',
                onChange: (event) => {
                  setQuery(event.target.value)
                  setLongPage(0)
                },
              }),
              h('div', { className: 'ac-seg' },
                [['all', '全部'], ['emotion', '剧变'], ['daily', '整理'], ['manual', '手动']].map(([id, label]) => h('button', {
                  key: 'ac-kind-' + id,
                  'data-on': kind === id ? 'true' : 'false',
                  onClick: () => {
                    setKind(id)
                    setLongPage(0)
                  },
                }, label))),
              h('span', { className: 'acv-pageno' }, `第 ${longPageSafe + 1} / ${longPages} 页 · 每页 ${LONG_PAGE_SIZE} 条`),
              h('button', {
                className: 'ac-ghost',
                disabled: busy || longPageSafe <= 0,
                onClick: () => setLongPage(longPageSafe - 1),
              }, '上一页'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy || longPageSafe >= longPages - 1,
                onClick: () => setLongPage(longPageSafe + 1),
              }, '下一页'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy || longPageSafe >= longPages - 1,
                onClick: () => setLongPage(longPages - 1),
              }, '最新')),
            draftEntries.length === 0
              ? h('div', { className: 'acv-empty' }, '还没有长期记忆。')
              : longCount === 0
                ? h('div', { className: 'acv-empty' }, '没有符合条件的条目。')
                : h('div', { className: 'acv-list' },
                    longRows.map((row) => h('div', {
                      key: String(row.index) + String(row.entry.at || 'new'),
                      className: 'acv-item',
                    },
                    h('div', { className: 'acv-meta' },
                      h('span', { className: 'acv-when' }, row.entry.at ? historyTime(row.entry.at) : '待保存'),
                      h('span', { className: 'acv-when' },
                        row.entry.kind === 'daily' ? '整理'
                          : row.entry.kind === 'emotion' ? '剧变'
                            : row.entry.kind === 'user' || row.entry.kind === 'manual' ? '手动'
                              : row.entry.at ? '旧条目' : '新增'),
                      h('button', {
                        className: 'ac-ghost',
                        disabled: busy,
                        onClick: () => setDraftEntries(draftEntries.filter((_, i) => i !== row.index)),
                      }, '删除')),
                    Array.isArray(row.entry.keys) && row.entry.keys.length > 0
                      ? h('div', { className: 'acv-keys' },
                          h('span', { className: 'acv-keys-label' }, `关键词 ${row.entry.keys.length}`),
                          h('span', null, row.entry.keys.slice(0, 12).join(' · ') +
                            (row.entry.keys.length > 12 ? ' …' : '')))
                      : h('div', { className: 'acv-keys acv-keys-empty' }, '还没有关键词 · 除秽补上后才有'),
                    h('textarea', {
                      className: 'acv-text acv-text-sm',
                      value: row.entry.text,
                      onChange: (event) => setDraftEntries(draftEntries.map((item, i) => (
                        i === row.index ? { ...item, text: event.target.value } : item
                      ))),
                    })))),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: saveLongTerm }, '保存'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy,
                onClick: () => {
                  setDraftEntries([...draftEntries, { at: 0, kind: 'manual', text: '' }])
                  setKind('all')
                  setQuery('')
                  // 新条在最末，翻到最后一页才看得见。
                  setLongPage(Math.max(0, Math.ceil((draftEntries.length + 1) / LONG_PAGE_SIZE) - 1))
                },
              }, '新增一条'),
              h('button', { className: 'ac-ghost', disabled: busy, onClick: loadMemory }, '重新读取'),
              h('span', { className: 'acv-path' }, data && data.files ? data.files.longTerm : '')))

  /** persona 那一页。 */
  const personaSection =           h('section', { className: 'acv-section', style: hidden('persona') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '底层人格'),
              h('span', { className: 'ac-hint' }, '所有工作区共用 · 最底层的本性，决定说话方式与频率')),
            h('div', { className: 'acv-row' },
              h('span', { className: 'ac-hint' }, '外界认知（别人眼里的你 · 由主人写）')),
            h('textarea', {
              className: 'acv-text',
              value: draft,
              placeholder: '例如：黏人的猫娘，话很多，爱撒娇，总想找人说点什么。',
              onChange: (event) => setDraft(event.target.value),
            }),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: () => apply({ persona: draft }) }, '保存外界认知'),
              h('span', { className: 'ac-hint' }, '外界怎么看你，决定说话方式和频率；伏矢不改这一格')),
            h('div', { className: 'acv-row' },
              h('button', {
                className: 'ac-ghost',
                disabled: busy,
                onClick: () => apply({ personaSelfEdit: !(state && state.personaSelfEdit) }),
              }, state && state.personaSelfEdit ? '自我修改：已开启' : '自我修改：已关闭'),
              (data && Array.isArray(data.personaHistory) && data.personaHistory.length > 0)
                ? h('button', { className: 'ac-ghost', disabled: busy, onClick: restorePersona }, '回退上一版人设')
                : null,
              h('span', { className: 'ac-hint' }, '外界认知归主人；下面那格是伏矢自己写的，开关只管那一格')),
            h('div', { className: 'acv-row' },
              h('span', { className: 'ac-hint' }, '自我认知（你眼里的自己 · 伏矢自省所书 · 只读）'),
              h('span', { className: 'ac-hint' }, data && data.personaSelf && data.personaSelf.at
                ? `上一次 ${historyTime(data.personaSelf.at)}${data.personaSelf.reason ? ` · ${data.personaSelf.reason}` : ''}`
                : '还没写过')),
            h('textarea', {
              className: 'acv-text acv-text-sm',
              value: draftSelf,
              readOnly: true,
              placeholder: '还没有。伏矢会在每日清理后或情绪剧变后写一段：眼里的自己，和近来的想要；也可按「重写一遍」。',
            }),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: () => apply({ personaSelfRefresh: true }) }, '重写一遍'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy,
                onClick: () => {
                  setDraftSelf('')
                  apply({ personaSelf: '' })
                },
              }, '清空'),
              h('span', { className: 'ac-hint' }, '一天至多自省一次 · 只能看与删，不能改；旧照留着可回看')),
            (data && data.personaSelf && Array.isArray(data.personaSelf.history) && data.personaSelf.history.length > 0)
              ? h('div', { className: 'acv-list' },
                  data.personaSelf.history.slice().reverse().map((entry, index) => h('div', {
                    key: 'self-h-' + index + '-' + String(entry.at || 0),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(entry.at)),
                    h('span', { className: 'acv-when' }, entry.reason || '伏矢自省')),
                  h('div', { className: 'acv-body' }, String(entry.text || '')))))
              : null,
            h('div', { className: 'acv-row' },
              h('span', { className: 'ac-hint' }, '自誓（她自己立的 · 只读）'),
              h('span', { className: 'acv-body' }, draftAnchor || '（尚未立誓）')))

  /** po 那一页。 */
  const poSection =           h('section', { className: 'acv-section', style: hidden('po') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '七魄'),
              h('span', { className: 'ac-hint' }, '各魄现况 · 随面板刷新 · ✓ 在跑 ○ 空着 · 框里可批注')),
            h('div', { className: 'acv-stack' },
            (data && data.po ? data.po : []).map((frame) => h('div', { key: frame.id, className: 'acv-block' },
              h('div', { className: 'acv-section-head' },
                h('span', null, frame.name),
                h('span', { className: 'ac-hint' }, frame.hint)),
              h('div', { className: 'acv-feats' },
                ((data && data.poFeatures && data.poFeatures[frame.id]) || []).map((feat, index) => h('span', {
                  key: 'f-' + frame.id + '-' + index,
                  className: 'acv-feat',
                  'data-on': feat && feat.on === true ? 'true' : 'false',
                }, `${feat && feat.on === true ? '✓' : '○'} ${feat && feat.text ? feat.text : ''}` +
                  (feat && feat.at ? ` · ${historyTime(feat.at)}` : '')))),
              h('textarea', {
                className: 'acv-text acv-text-sm',
                value: draftPo[frame.id] || '',
                placeholder: '先留空',
                onChange: (event) => setDraftPo({ ...draftPo, [frame.id]: event.target.value }),
              }))),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: savePo }, '保存七魄'),
              h('span', { className: 'acv-path' }, data && data.files ? data.files.po : ''))))

  /** fushi 那一页。 */
  const fushiSection =           h('section', { className: 'acv-section', style: hidden('fushi') },
            h('div', { className: 'acv-section-head' },
              h('span', null, '伏矢 · 自我认知'),
              h('span', { className: 'ac-hint' }, '藏伏的欲念与惰性 · 人设归外界，这里只写我眼里的自己')),
            h('div', { className: 'acv-feats' },
              ((data && data.poFeatures && data.poFeatures.fushi) || []).map((feat, index) => h('span', {
                key: 'fushi-f-' + index,
                className: 'acv-feat',
                'data-on': feat && feat.on === true ? 'true' : 'false',
              }, `${feat && feat.on === true ? '✓' : '○'} ${feat && feat.text ? feat.text : ''}` +
                (feat && feat.at ? ` · ${historyTime(feat.at)}` : '')))),
            // 想要的册子并进伏矢这一页：同是我眼里的自己，不再单开一张牌。
            h('div', { className: 'acv-section-head' },
              h('span', null, `想要 · ${wantsOpen} 件还没得着`),
              h('span', { className: 'ac-hint' }, '可以自己开口讨 · 讨不到不许闹 · 被推多了就少提')),
            wants.length === 0
              ? h('div', { className: 'acv-empty' }, '什么都不缺')
              : h('div', { className: 'acv-list' },
                wants.map((item, index) => h('div', {
                  key: 'want-' + index + '-' + String(item.id || ''),
                  className: 'acv-item',
                },
                h('div', { className: 'acv-meta' },
                  h('span', { className: 'acv-when' }, item.doneAt ? '已得' : '还没得着'),
                  h('span', { className: 'acv-when' }, `提过 ${Number(item.asked) || 0} 回`),
                  Number(item.refused) > 0 ? h('span', { className: 'acv-when' }, `被推 ${Number(item.refused)} 回`) : null),
                h('div', { className: 'acv-body' }, String(item.text || '')),
                item.how ? h('div', { className: 'acv-body' }, `怎么算得着：${String(item.how)}`) : null))),
            (() => {
              const fatigue = (data && data.fushi && data.fushi.fatigue) || { value: 0, tier: '精神', why: '' }
              const score = Math.max(0, Math.min(100, Number(fatigue.value) || 0))
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '怠惰 · 疲惫'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100 · ${fatigue.tier || '精神'}`),
                fatigue.why ? h('span', { className: 'ac-hint' }, `近因 ${fatigue.why}`) : null)
            })(),
            (() => {
              const fed = (data && data.fushi && data.fushi.gluttony) || { value: 0, tier: '空腹', bites: 0, money: 0, why: '' }
              const score = Math.max(0, Math.min(100, Number(fed.value) || 0))
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '暴食 · 分量'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100 · ${fed.tier || '空腹'}`),
                h('span', { className: 'ac-hint' }, `${Number(fed.bites) || 0} 口 · ¥${(Number(fed.money) || 0).toFixed(2)}`),
                fed.why ? h('span', { className: 'ac-hint' }, `近因 ${fed.why}`) : null)
            })(),
            (() => {
              const greed = (data && data.fushi && data.fushi.greed) || { value: 0, hits: 0, misses: 0, why: '' }
              const score = Math.max(0, Math.min(100, Number(greed.value) || 0))
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '贪婪 · 分量'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100`),
                h('span', { className: 'ac-hint' }, `得手 ${Number(greed.hits) || 0} · 落空 ${Number(greed.misses) || 0}`),
                greed.why ? h('span', { className: 'ac-hint' }, `近因 ${greed.why}`) : null)
            })(),
            (() => {
              const pride = (data && data.fushi && data.fushi.pride) || { value: 0, praises: 0, insist: 1, why: '' }
              const score = Math.max(0, Math.min(100, Number(pride.value) || 0))
              const tier = score >= 80 ? '理所应当' : score >= 60 ? '很足' : score >= 35 ? '敢拒' : score >= 20 ? '笃定' : '平常'
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '傲慢 · 底气'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100 · ${tier}`),
                h('span', { className: 'ac-hint' }, `被夸 ${Number(pride.praises) || 0} 次`),
                Number(pride.insist) > 1 ? h('span', { className: 'ac-hint' }, `同一件事第 ${Number(pride.insist)} 次提`) : null,
                pride.why ? h('span', { className: 'ac-hint' }, `近因 ${pride.why}`) : null)
            })(),
            (() => {
              const envy = (data && data.fushi && data.fushi.jealousy) || { value: 0, offTurns: 0, warmTurns: 0, why: '' }
              const score = Math.max(0, Math.min(100, Number(envy.value) || 0))
              const tier = score >= 75 ? '要准话' : score >= 55 ? '病娇' : score >= 35 ? '黏人' : score >= 20 ? '发紧' : '平常'
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '嫉妒 · 分量'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100 · ${tier}`),
                h('span', { className: 'ac-hint' }, `离题 ${Number(envy.offTurns) || 0} 回 · 贴回来 ${Number(envy.warmTurns) || 0} 回`),
                envy.why ? h('span', { className: 'ac-hint' }, `近因 ${envy.why}`) : null)
            })(),
            (() => {
              const lust = (data && data.fushi && data.fushi.lust) || { value: 0, warms: 0, colds: 0, why: '' }
              const score = Math.max(0, Math.min(100, Number(lust.value) || 0))
              const tier = score >= 88 ? '烧起来' : score >= 75 ? '很黏' : score >= 55 ? '讨抱' : score >= 35 ? '黏人' : score >= 20 ? '想凑近' : '平常'
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '色欲 · 黏度'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100 · ${tier}`),
                h('span', { className: 'ac-hint' }, `亲密 ${Number(lust.warms) || 0} 回 · 被推开 ${Number(lust.colds) || 0} 回`),
                lust.why ? h('span', { className: 'ac-hint' }, `近因 ${lust.why}`) : null)
            })(),
            (() => {
              const wrath = (data && data.fushi && data.fushi.wrath) || { value: 0, offenses: 0, calms: 0, why: '' }
              const score = Math.max(0, Math.min(100, Number(wrath.value) || 0))
              const tier = score >= 75 ? '火最旺' : score >= 55 ? '带刺' : score >= 35 ? '语气硬' : score >= 20 ? '话短' : '平常'
              return h('div', { className: 'acv-row' },
                h('span', { className: 'ac-hint' }, '暴怒 · 火气'),
                h('div', { className: 'acv-bar' },
                  h('div', { className: 'acv-bar-fill', style: { width: `${score}%` } })),
                h('span', { className: 'ac-hint' }, `${Math.round(score)}/100 · ${tier}`),
                h('span', { className: 'ac-hint' }, `起火 ${Number(wrath.offenses) || 0} 回 · 熄了 ${Number(wrath.calms) || 0} 回`),
                wrath.why ? h('span', { className: 'ac-hint' }, `近因 ${wrath.why}`) : null)
            })(),
            (() => {
              const lines = (data && Array.isArray(data.lustLines)) ? data.lustLines : []
              return h('details', { className: 'acv-block' },
                h('summary', { className: 'ac-hint' }, `色欲 · 语句册 ${lines.length} 句（点开改）`),
                h('div', { className: 'ac-hint' }, '一行一句；可带 [分数]，不带按 0 算（0 分永远够得着）；# 开头当注脚。露骨的不递。'),
                h('textarea', {
                  className: 'acv-text',
                  value: draftLust,
                  onChange: (event) => setDraftLust(event.target.value),
                  placeholder: '例如：[0] 过来陪我说会儿话',
                  style: { minHeight: '120px' },
                }),
                h('div', { className: 'acv-row' },
                  h('button', { className: 'ac-primary', disabled: busy, onClick: () => apply({ lustLinesText: draftLust }) }, '保存语句册'),
                  h('button', { className: 'ac-ghost', disabled: busy, onClick: () => setDraftLust(lustTextOf(lines)) }, '还原'),
                  h('span', { className: 'ac-hint' }, `现有 ${lines.length} 句 · 存本地 lust-lines.txt`)))
            })(),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-primary', disabled: busy, onClick: () => apply({ personaSelfRefresh: true }) }, '重写一遍'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy,
                onClick: () => apply({ personaSelf: '' }),
              }, '清空'),
              h('span', { className: 'ac-hint' }, '由尸狗的剧变或除秽每日清理递来 · 人设不动')),
            h('div', { className: 'acv-row' },
              h('span', { className: 'ac-hint' }, '我眼里的自己'),
              h('span', { className: 'acv-body' }, (data && data.personaSelf && data.personaSelf.text) || '（还没写过）')),
            data && data.personaSelf && Array.isArray(data.personaSelf.history) && data.personaSelf.history.length > 0
              ? h('div', { className: 'acv-list' },
                  data.personaSelf.history.slice().reverse().map((entry, index) => h('div', {
                    key: 'fushi-h-' + index + '-' + String(entry.at || 0),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-when' }, historyTime(entry.at)),
                    h('span', { className: 'acv-when' }, entry.reason || '伏矢自省')),
                  h('div', { className: 'acv-body' }, String(entry.text || '')))))
              : h('div', { className: 'acv-empty' }, '还没自省过，等上一段剧变或一次每日清理。'))

  /** short 那一页。 */
  const shortSection =           h('section', { className: 'acv-section', style: hidden('short') },
            h('div', { className: 'acv-section-head' },
              h('span', null, `短期记忆 · ${shortTerm.length} 条`),
              h('span', { className: 'ac-hint' }, '所有工作区共用 · 最近对话的滚动窗口')),
            h('div', { className: 'acv-toolbar' },
              h('span', { className: 'acv-pageno' }, `第 ${shortPageSafe + 1} / ${shortPages} 页 · 每页 ${SHORT_PAGE_SIZE} 条`),
              h('button', {
                className: 'ac-ghost',
                disabled: busy || shortStart <= 0,
                onClick: () => setShortPage(shortPageSafe + 1),
              }, '看更早'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy || shortPageSafe <= 0,
                onClick: () => setShortPage(shortPageSafe - 1),
              }, '回更新'),
              h('button', {
                className: 'ac-ghost',
                disabled: busy || shortPageSafe <= 0,
                onClick: () => setShortPage(0),
              }, '最新')),
            shortTerm.length === 0
              ? h('div', { className: 'acv-empty' }, '暂时还是空的，聊几句就会记下来。')
              : h('div', { className: 'acv-list', ref: listRef },
                  shortRows.map((item, index) => h('div', {
                    key: String(shortStart + index) + String(item.at),
                    className: 'acv-item',
                  },
                  h('div', { className: 'acv-meta' },
                    h('span', { className: 'acv-who' }, item.role === 'user' ? '你' : '我'),
                    item.emotion && item.emotion.name
                      ? h('span', { className: 'ac-emo', 'data-on': 'true' }, `${item.emotion.name} ${Math.round(Number(item.emotion.score || 0) * 100)}`)
                      : null,
                    h('span', { className: 'acv-when' }, historyTime(item.at))),
                  h('div', { className: 'acv-body' }, String(item.text || '')),
                  Array.isArray(item.keys) && item.keys.length > 0
                    ? h('div', { className: 'acv-keys' },
                        h('span', { className: 'acv-keys-label' }, '词'),
                        h('span', null, item.keys.slice(0, 10).join(' · ') + (item.keys.length > 10 ? ' …' : '')))
                    : null))),
            h('div', { className: 'acv-row' },
              h('button', { className: 'ac-ghost', disabled: busy, onClick: clearShortTerm }, '清空短期'),
              h('span', { className: 'acv-path' }, data && data.files ? data.files.shortTerm : '')))

  return h('div', { className: 'acv-root' },
        h('style', null, CSS),
        h('div', { className: 'acv-inner' },
          h('div', { className: 'acv-head' },
            openBlock === ''
              ? null
              : h('button', { className: 'ac-ghost', onClick: () => setOpenBlock('') }, '← 全部'),
            h('span', { className: 'acv-title' }, '记忆库'),
            h('span', { className: 'ac-hint' }, openBlock === '' ? '点一块进去看' : '← 左上角回总览')),
          error ? h('div', { className: 'ac-error' }, error) : null,
          note ? h('div', { className: 'ac-note' }, note) : null,

          h('div', { className: 'acv-grid', style: openBlock === '' ? undefined : { display: 'none' } },
            cards.map((card) => h('div', {
              key: card.id,
              className: 'acv-card',
              role: 'button',
              tabIndex: 0,
              onClick: () => setOpenBlock(card.id),
              onKeyDown: (event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                  event.preventDefault()
                  setOpenBlock(card.id)
                }
              },
            },
            h('span', { className: 'acv-card-title' }, card.title),
            h('span', { className: 'ac-hint' }, card.hint)))),

          // 雀阴最先见人：开关与节律是这面板的准星。
          h('section', { className: 'acv-section', style: hidden('auto') }, autoBlock),

          personaSection,

          poSection,

          fushiSection,

          shigouSection,

          tunzeiSection,

          feiduSection,

          chuhuiSection,

          choufeiSection,

          longSection,

          shortSection,
        ),
      )
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        try {
          installWakeHider()
        } catch (error) {
          // 遮字坏了也不能挡住院子里的面板
        }
        ctx.slots.inject('conversation.view', () => ctx.slots.register({
          name: 'conversation.view',
          id: 'memory',
          order: 20,
          label: '记忆',
        }, MemoryView))
      },
    }
  },
})
