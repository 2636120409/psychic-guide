/**
 * 自检：面板拆格之后，每一页都得有定义。
 * 跑法：node scripts/selftest-client.mjs
 *
 * 这一条是给拆格兜底的：主树里点了名的 section，若是哪次搬动漏了定义，
 * 语法查不出来（要到浏览器里才报错），这里先喊一声。
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'

const file = path.join(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..', 'client.js')
const source = fs.readFileSync(file, 'utf8')

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const defined = new Set()
for (const match of source.matchAll(/const ([A-Za-z_$][\w$]*Section) =/g)) defined.add(match[1])

const used = new Set()
for (const match of source.matchAll(/^\s{10}([A-Za-z_$][\w$]*Section),$/gm)) used.add(match[1])

check('主树里点名的每一页都有定义', () => {
  assert.ok(used.size >= 10, `只找到 ${used.size} 页，怕是正则没对上`)
  for (const name of used) assert.ok(defined.has(name), `缺定义：${name}`)
})

check('每一页都真的进了主树', () => {
  for (const name of defined) assert.ok(used.has(name), `定义了却没摆上去：${name}`)
})

check('定义与引用都是唯一一次', () => {
  for (const name of defined) {
    const definitions = source.match(new RegExp(`const ${name} =`, 'g')) || []
    assert.equal(definitions.length, 1, `${name} 定义了 ${definitions.length} 次`)
  }
})

console.log(`\n共 ${count} 项，全过（${used.size} 页）。`)
