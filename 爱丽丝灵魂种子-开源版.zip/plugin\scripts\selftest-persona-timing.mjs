/**
 * 自检：人设读出来的开口节奏。
 * 跑法：node scripts/selftest-persona-timing.mjs
 */
import assert from 'node:assert/strict'
import * as pt from '../lib/persona-timing.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('空人设是零分、基准节奏', () => {
  assert.equal(pt.personaScore(''), 0)
  const t = pt.timingFor('')
  assert.equal(t.minSeconds, 120)
  assert.equal(t.maxSeconds, 300)
  assert.equal(t.maxTurnsPerHour, 14)
})

check('话多的人设：更勤', () => {
  const t = pt.timingFor('活泼，爱聊，有点撒娇')
  assert.ok(t.personaScore > 0)
  assert.ok(t.minSeconds < 120)
  assert.ok(t.maxTurnsPerHour > 14)
})

check('话少的人设：更缓', () => {
  const t = pt.timingFor('安静，寡言，冷静')
  assert.ok(t.personaScore < 0)
  assert.ok(t.minSeconds > 120)
  assert.ok(t.maxTurnsPerHour < 14)
})

check('有上下限，不会越界', () => {
  const chatty = pt.timingFor('话痨 话多 黏人 撒娇 活泼 热情 主动 外向 元气 好奇 爱聊 健谈')
  assert.equal(chatty.personaScore, 3)
  const quiet = pt.timingFor('高冷 安静 冷淡 沉默 寡言 简洁 沉稳 内向 严肃 克制 少话 文静 冷静')
  assert.equal(quiet.personaScore, -3)
  assert.ok(chatty.minSeconds >= 20 && quiet.minSeconds >= 20)
  assert.ok(chatty.maxTurnsPerHour >= 2)
})

check('两样都有时互相抵', () => {
  const t = pt.timingFor('活泼，但安静')
  assert.ok(Math.abs(t.personaScore) <= 1)
})

check('词表里没有明显的坏字', () => {
  const all = pt.SOCIABLE.concat(pt.RESERVED)
  assert.ok(all.every((word) => word.length >= 2), all.join(' '))
  assert.equal(new Set(pt.RESERVED).size, pt.RESERVED.length)
})

console.log(`\n共 ${count} 项，全过。`)
