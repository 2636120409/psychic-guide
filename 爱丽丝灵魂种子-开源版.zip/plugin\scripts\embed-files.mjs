/**
 * 给工作区的文件建一张语义索引：问一句意思，翻出来是哪几个文件。
 *
 * 只收文档和脚本（md / mjs / js / txt / json），跳过 node_modules、模型、归档这些大件。
 * 索引落在 auto-conversation-memory 旁边，不进记忆账。
 *
 * 跑法：node scripts/embed-files.mjs
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const MEMORY_ROOT = path.join(HOME, 'auto-conversation-memory')
const OUT_FILE = path.join(MEMORY_ROOT, 'file-index.json')
const PYTHON = process.env.DSH_PYTHON || 'python'
const SCRIPT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..', '..', 'tools', 'embed', 'embed_texts.py')
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..')

const EXTS = new Set(['.md', '.mjs', '.js', '.txt', '.json'])
const SKIP_DIRS = new Set(['node_modules', '.git', '.pnpm-store', '.pack', 'package', 'profiles', 'dsh-crash-logs', 'models', 'tmp', 'archive', '.dsh'])
const MAX_FILES = 600
const MAX_BYTES = 1024 * 1024
const TEXT_LIMIT = 300

function walk(dir, depth, out) {
  if (out.length >= MAX_FILES || depth > 4) return
  let items = []
  try {
    items = fs.readdirSync(dir, { withFileTypes: true })
  } catch {
    return
  }
  items.sort((a, b) => a.name.localeCompare(b.name))
  for (const item of items) {
    if (out.length >= MAX_FILES) return
    if (item.isDirectory()) {
      if (SKIP_DIRS.has(item.name)) continue
      walk(path.join(dir, item.name), depth + 1, out)
      continue
    }
    const ext = path.extname(item.name).toLowerCase()
    if (!EXTS.has(ext)) continue
    const full = path.join(dir, item.name)
    try {
      const stat = fs.statSync(full)
      if (stat.size > MAX_BYTES) continue
      out.push({ full, rel: path.relative(ROOT, full), size: stat.size, mtime: stat.mtimeMs })
    } catch {
      // 读不到就算了
    }
  }
}

function titleOf(text, rel) {
  const heading = String(text || '').match(/^\s*#{1,3}\s+(.+)$/m)
  if (heading !== null) return heading[1].trim().slice(0, 40)
  return path.basename(rel)
}

function snippetOf(text) {
  return String(text || '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/[#>*`_-]{2,}/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, TEXT_LIMIT)
}

const files = []
walk(ROOT, 0, files)
if (files.length === 0) {
  console.log('embed-files: 没找到可索引的文件')
  process.exit(0)
}

const docs = files.map((file) => {
  let text = ''
  try {
    text = fs.readFileSync(file.full, 'utf8')
  } catch {
    text = ''
  }
  const title = titleOf(text, file.rel)
  const snippet = snippetOf(text)
  return { rel: file.rel, title, snippet, mtime: file.mtime, size: file.size, text: `${title}。${snippet}` }
}).filter((doc) => doc.text.trim().length > 0)

function embedOnce(texts) {
  const result = spawnSync(PYTHON, [SCRIPT], {
    input: JSON.stringify(texts),
    encoding: 'utf8',
    timeout: 300000,
    maxBuffer: 128 * 1024 * 1024,
  })
  if (result.error !== undefined && result.error !== null) throw result.error
  if (result.status !== 0) throw new Error(String(result.stderr || '').slice(0, 600))
  return JSON.parse(result.stdout)
}

// 一次喂太多，onnx 那头会闷死；分批来。
function embed(texts, batch = 32) {
  const out = []
  for (let at = 0; at < texts.length; at += batch) {
    const part = texts.slice(at, at + batch)
    out.push(...embedOnce(part))
  }
  return out
}

const vectors = embed(docs.map((doc) => doc.text))
fs.mkdirSync(MEMORY_ROOT, { recursive: true })
fs.writeFileSync(OUT_FILE, JSON.stringify({
  version: 1,
  at: Date.now(),
  root: ROOT,
  files: docs.map((doc, index) => ({
    rel: doc.rel,
    title: doc.title,
    snippet: doc.snippet,
    mtime: doc.mtime,
    size: doc.size,
    vector: vectors[index] || [],
  })),
}))
console.log(`embed-files: ${docs.length} 个文件，写到 ${OUT_FILE}`)
