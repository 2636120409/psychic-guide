/**
 * 自检：伏矢 · 体感（七宗的读数合成一句话，不报数）。
 * 跑法：node scripts/selftest-state-voice.mjs
 */
import assert from 'node:assert/strict'
import { stateVoiceLine, stateVoiceLines, STATE_TENDENCY } from '../lib/state-voice.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('一根都不够门槛，就说平顺', () => {
  const line = stateVoiceLine({ fatigue: 10, lust: 12, gluttony: 20, greed: 0, pride: 0, jealousy: 0, wrath: 5 })
  assert.ok(line.includes('平顺'), line)
})

check('缺项按零算，不抛', () => {
  assert.ok(stateVoiceLine().includes('平顺'))
  assert.ok(stateVoiceLine({ lust: 70 }).includes('软话'))
})

check('最重的一根当主调', () => {
  const line = stateVoiceLine({ fatigue: 10, lust: 70, greed: 10 })
  assert.ok(line.includes('讨一句软话'), line)
})

check('第二重的那根缀在后头当旁注', () => {
  const line = stateVoiceLine({ greed: 100, lust: 56 })
  assert.ok(line.includes('填不满'), line)
  assert.ok(line.includes('想往您那边靠'), line)
  assert.ok(!line.includes('；；'), line)
})

check('数只用来挑话，不出现在话里', () => {
  const line = stateVoiceLine({ fatigue: 66, lust: 88, gluttony: 74, greed: 100, pride: 51, jealousy: 33, wrath: 12 })
  assert.ok(!/\d/.test(line), line)
})

check('欲分低时不冒黏话', () => {
  const line = stateVoiceLine({ fatigue: 10, lust: 20 })
  assert.ok(!line.includes('抱') && !line.includes('黏'), line)
})

check('高黏那档仍带着分寸', () => {
  const line = stateVoiceLine({ lust: 90 })
  assert.ok(line.includes('不催'), line)
})

check('末尾那句「倾向不是命令」递得出去', () => {
  assert.ok(STATE_TENDENCY.includes('倾向'))
  assert.ok(STATE_TENDENCY.includes('不是命令'))
  const lines = stateVoiceLines({ fatigue: 10 })
  assert.equal(lines.length, 2)
  assert.ok(lines[0].startsWith('此刻的我：'))
  assert.equal(lines[1], STATE_TENDENCY)
})

console.log(`\n共 ${count} 项，全过。`)
