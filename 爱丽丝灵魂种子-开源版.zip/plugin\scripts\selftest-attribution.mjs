/**
 * 自检：归因的有效期。
 * 跑法：node scripts/selftest-attribution.mjs
 */
import assert from 'node:assert/strict'
import * as att from '../lib/attribution.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const now = 10_000_000

check('新鲜的有效', () => {
  const out = att.readValidAttribution({ d: 1, at: now - 60_000 }, now)
  assert.equal(out.d, 1)
})

check('过了两小时就归零', () => {
  const out = att.readValidAttribution({ d: -1, at: now - att.TTL_MS - 1 }, now)
  assert.equal(out.d, 0)
})

check('坏值当说不清', () => {
  assert.equal(att.readValidAttribution({ d: 5, at: now }, now).d, 0)
  assert.equal(att.readValidAttribution({ d: 1, at: 0 }, now).d, 0)
  assert.equal(att.readValidAttribution(null, now).d, 0)
})

check('只收内外两种', () => {
  assert.equal(att.isAttribution(1), true)
  assert.equal(att.isAttribution(-1), true)
  assert.equal(att.isAttribution(0), false)
})

console.log(`\n共 ${count} 项，全过。`)
