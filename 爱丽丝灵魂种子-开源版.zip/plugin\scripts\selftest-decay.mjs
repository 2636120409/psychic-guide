/**
 * 自检：一条账此刻还有多重。
 * 跑法：node scripts/selftest-decay.mjs
 */
import assert from 'node:assert/strict'
import * as decay from '../lib/decay.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const now = 400 * 24 * 60 * 60 * 1000

check('手写账不折旧', () => {
  const old = { kind: 'manual', at: 0, conf: 1 }
  const recent = { kind: 'manual', at: now, conf: 1 }
  assert.equal(decay.longTermWeight(old, now), decay.longTermWeight(recent, now))
  assert.equal(decay.longTermWeight(old, now), 1)
})

check('情绪账散得比日常快', () => {
  const day = 24 * 60 * 60 * 1000
  const emotion = decay.longTermWeight({ kind: 'emotion', at: now - day, conf: 1 }, now)
  const daily = decay.longTermWeight({ kind: 'daily', at: now - day, conf: 1 }, now)
  assert.ok(emotion < daily, `${emotion} vs ${daily}`)
})

check('被重新提起的分量抬一抬，封顶 1.6 倍', () => {
  const one = decay.longTermWeight({ kind: 'daily', at: now, conf: 1, hits: 1 }, now)
  const many = decay.longTermWeight({ kind: 'daily', at: now, conf: 1, hits: 999 }, now)
  assert.equal(one, 1)
  assert.equal(many, 1.6)
})

check('conf 有下限也有上限', () => {
  const low = decay.longTermWeight({ kind: 'daily', at: now, conf: -5 }, now)
  assert.equal(low, decay.CONF_FLOOR)
  const high = decay.longTermWeight({ kind: 'daily', at: now, conf: 9 }, now)
  assert.equal(high, 1)
})

check('没写入时按来路给底气', () => {
  assert.equal(decay.defaultConfidence('manual'), 1)
  assert.equal(decay.defaultConfidence('emotion'), 0.85)
  assert.equal(decay.defaultConfidence('daily'), 0.7)
})

check('不是条目就是零', () => {
  assert.equal(decay.longTermWeight(null, now), 0)
  assert.equal(decay.longTermWeight('字', now), 0)
})

const DAY = 24 * 60 * 60 * 1000

check('闲账慢慢丢，要紧账留得久', () => {
  const oldDaily = { kind: 'daily', at: now - 100 * DAY, conf: 0.7, text: '直播间的规矩，说了几十条' }
  const oldDear = { kind: 'daily', at: now - 100 * DAY, conf: 0.7, text: '主人说这个名字要一直用' }
  assert.ok(decay.memoryValue(oldDaily, now) < decay.FORGET_WEIGHT)
  assert.ok(decay.memoryValue(oldDear, now) > decay.FORGET_WEIGHT)
})

check('手写账不因淡而丢', () => {
  const old = { kind: 'manual', at: now - 999 * DAY, conf: 1, text: '主人写的' }
  assert.ok(decay.memoryValue(old, now) >= decay.FORGET_WEIGHT)
})

check('情绪账算要紧的', () => {
  const old = { kind: 'emotion', at: now - 100 * DAY, conf: 0.85, text: '心里有点乱' }
  assert.ok(decay.isDearEntry(old))
  assert.ok(decay.memoryValue(old, now) > decay.FORGET_WEIGHT)
})

console.log(`\n共 ${count} 项，全过。`)
