/**
 * 冷热两层自测：热层摆锚、冷层报数、作废不露面、该忘的不算。
 * 跑法：node scripts/selftest-memory-layers.mjs
 */
import assert from 'node:assert/strict'
import {
  splitMemoryLayers,
  memoryLayerLines,
  buildCooccurrence,
  relatedTerms,
  memoryAnchorLine,
  HOT_MIN_WEIGHT,
} from '../lib/memory-layers.mjs'

const DAY = 24 * 60 * 60 * 1000
const now = Date.UTC(2026, 10, 8, 6, 0, 0)

const fresh = {
  at: now - DAY,
  kind: 'daily',
  text: '主人说周末去一趟城南的书店',
  keys: ['书店', '周末'],
  hits: 2,
  conf: 0.9,
}
const old = {
  at: now - 60 * DAY,
  kind: 'daily',
  text: '六十天前的一句旧话',
  keys: ['旧事'],
  hits: 1,
  conf: 0.7,
}
const gone = {
  at: now - 400 * DAY,
  kind: 'emotion',
  text: '早该忘的',
  keys: [],
  hits: 1,
  conf: 0.5,
}
const voided = {
  at: now - DAY,
  kind: 'manual',
  text: '主人裁过作废的一条',
  keys: ['作废'],
  hits: 1,
  conf: 1,
  superseded: true,
}
const manual = {
  at: now - 500 * DAY,
  kind: 'manual',
  text: '主人手写的约定：每天留一句',
  keys: ['约定'],
  hits: 1,
  conf: 1,
}

const { hot, cold } = splitMemoryLayers([fresh, old, gone, voided, manual], now)
const hotTexts = hot.map((row) => row.text)
const coldTexts = cold.map((row) => row.text)

assert.ok(hotTexts.includes(fresh.text), '新的该进热层')
assert.ok(hotTexts.includes(manual.text), '主人手写的不折旧，该在热层')
assert.ok(coldTexts.includes(old.text), '六十天前的该沉下去')
assert.ok(!hotTexts.includes(gone.text) && !coldTexts.includes(gone.text), '淡到该忘的不算')
assert.ok(!hotTexts.includes(voided.text) && !coldTexts.includes(voided.text), '作废的不摆出来')
assert.ok(hot.every((row) => row.weight >= HOT_MIN_WEIGHT), '热层分量都在线以上')

const lines = memoryLayerLines([fresh, old, gone, voided, manual], now)
assert.ok(lines[0] === '<memory-layers>', '有开标签')
assert.ok(lines[lines.length - 1] === '</memory-layers>', '有闭标签')
assert.ok(lines.some((line) => line.includes('冷层 1 条')), '冷层报数')
assert.ok(lines.some((line) => line.includes('书店')), '热层带锚词')

assert.deepEqual(memoryLayerLines([], now), [], '空账不出声')

// 半吊子语义锚：一句话里老挨着的词互为近义，换个说法也能蹭到。
const bookstore = { at: now - DAY, kind: 'daily', text: '周末去城南书店买书', keys: ['书店', '城南', '买书'], conf: 0.9, hits: 1 }
const reading = { at: now - 2 * DAY, kind: 'daily', text: '书店那本旧书读完了', keys: ['书店', '旧书', '读完'], conf: 0.9, hits: 1 }
const index = buildCooccurrence([bookstore, reading])
const related = relatedTerms('书店', index, { exclude: ['书店'] })
assert.ok(related.includes('城南') || related.includes('旧书') || related.includes('买书'), '共现的近义词要能捞出来')
assert.ok(!related.includes('书店'), '别把自己当自己的近义')

const long = {
  text: '这是一条很长的账，长到必须掐开头才摆得下，后面还有好多字，好多字，多到一眼看不完，得往后再拖两行才够',
  keys: ['长账', '开头'],
  at: now,
  weight: 1,
}
const line = memoryAnchorLine(long, index)
assert.ok(line.includes('…'), '长的要掐开头')
assert.ok(line.includes('长账'), '长的要挂锚')

console.log('memory-layers: ok')
