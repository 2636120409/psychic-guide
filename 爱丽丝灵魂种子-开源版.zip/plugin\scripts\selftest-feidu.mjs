/**
 * 自检：非毒的待裁之对。
 * 跑法：node scripts/selftest-feidu.mjs
 */
import assert from 'node:assert/strict'
import * as feidu from '../lib/feidu.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const at = 1000
const entries = [
  { at, kind: 'daily', text: '主人喜欢安静' },
  { at, kind: 'daily', text: '主人不喜欢安静' },
  { at: at + 1, kind: 'manual', text: '另一件事' },
]

check('按时刻与字面认出是哪条', () => {
  const got = feidu.entryForSide(entries, { at, text: '主人喜欢安静' })
  assert.equal(got.text, '主人喜欢安静')
})

check('同刻多条时挑最像的', () => {
  const got = feidu.entryForSide(entries, { at, text: '主人不喜欢安静' })
  assert.equal(got.text, '主人不喜欢安静')
})

check('已作废的不算', () => {
  const got = feidu.entryForSide([{ at, kind: 'daily', text: '主人喜欢安静', superseded: true }], { at, text: '主人喜欢安静' })
  assert.equal(got, undefined)
})

check('肯否相左的一对还相左', () => {
  const dispute = {
    left: { at, text: '主人喜欢安静' },
    right: { at, text: '主人不喜欢安静' },
  }
  assert.equal(feidu.disputeStillClashes(dispute, entries), true)
})

check('一边找不到就不再问', () => {
  assert.equal(feidu.disputeStillClashes({ left: { at: 999, text: '没了' } }, entries), false)
})

check('字面不像的不算相左', () => {
  const dispute = {
    left: { at, text: '主人喜欢安静' },
    right: { at, text: '今天吃了面' },
  }
  assert.equal(feidu.disputeStillClashes(dispute, entries), false)
})

check('来路不对的不参与', () => {
  const got = feidu.entryForSide([{ at, kind: 'emotion', text: '主人喜欢安静' }], { at, text: '主人喜欢安静' })
  assert.equal(got, undefined)
})

console.log(`\n共 ${count} 项，全过。`)
