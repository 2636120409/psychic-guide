import fs from 'node:fs'

const t = fs.readFileSync(process.argv[2], 'utf8')
const lines = t.split(/\r?\n/)
const res = []

for (let i = 0; i < lines.length; i += 1) {
  const m = lines[i].match(/^([ \t]*)(?:async )?function ([A-Za-z0-9_]+)\s*\(/)
  if (m === null) continue
  const indent = m[1]
  // 往下找同缩进的收尾「}」
  let end = -1
  for (let j = i + 1; j < lines.length; j += 1) {
    if (lines[j] === `${indent}}`) { end = j; break }
  }
  if (end < 0) continue
  res.push({ name: m[2], lines: end - i + 1 })
}

res.sort((a, b) => b.lines - a.lines)
for (const item of res.slice(0, 12)) console.log(`${item.lines}  ${item.name}`)
console.log(`函数总数=${res.length}`)
