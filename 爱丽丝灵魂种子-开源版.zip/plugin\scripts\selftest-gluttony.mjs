/**
 * 暴食记账内核自检：金额、峰谷、逐轮累计、归档、坏账本备份、原子写入。
 * 只碰临时目录，绝不动 $DSH_HOME 里的真账。
 *   运行：node scripts/selftest-gluttony.mjs
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import * as g from '../lib/gluttony.mjs'

let failed = 0
function check(name, ok, detail = '') {
  if (ok) {
    console.log(`  ✓ ${name}`)
  } else {
    failed += 1
    console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`)
  }
}

const sundayEvening = Date.parse('2026-11-01T19:00:00+08:00')
const mondayMorning = Date.parse('2026-11-02T10:00:00+08:00')

console.log('价目与峰谷')
check('周日晚按谷价', g.isPeakTime(sundayEvening / 1000) === false)
check('周一上午按峰价', g.isPeakTime(mondayMorning / 1000) === true)

const usage = { inputTokens: 500000, cacheReadTokens: 300000, outputTokens: 200000 }
const off = g.usageCostUnits('deepseek-flash', usage, sundayEvening)
const peak = g.usageCostUnits('deepseek-flash', usage, mondayMorning)
check('谷价金额 1.306 元', off.units === g.moneyUnits(1.306), `实际 ${g.preciseMoney(off.units)}`)
check('峰价为谷价两倍', peak.units === off.units * 2, `峰 ${g.preciseMoney(peak.units)}`)
check('token 口径 input+cache+output', off.tokens === 1000000, `实际 ${off.tokens}`)

console.log('逐轮账与换算')
const ledger = g.freshLedger()
g.appendTurn(ledger, { scope: 'fingertest', at: sundayEvening, model: 'deepseek-flash', units: off.units, tokens: off.tokens })
g.appendTurn(ledger, { scope: 'fingertest', at: sundayEvening + 1000, model: 'deepseek-flash', units: g.moneyUnits(0.05), tokens: 200000 })
const sum = g.summarizeBook(ledger.accounting.books.fingertest)
check('两笔都在账上', sum.events === 2, `实际 ${sum.events}`)
check('金额 1.356 元', sum.money === 1.356, `实际 ${sum.money}`)
check('token 1,200,000', sum.tokens === 1200000, `实际 ${sum.tokens}`)
check('口数 = 1', sum.bites === 1, `实际 ${sum.bites}`)
check('分数 = 13', sum.points === 13, `实际 ${sum.points}`)
check('另一本账不受影响', Object.keys(ledger.accounting.books).length === 1)

console.log('按天退')
check('一天退一成（21 → 19）', g.decayDaily(21, 1) === 19, `实际 ${g.decayDaily(21, 1)}`)
check('单日封顶五分（60 退三天 → 45）', g.decayDaily(60, 3) === 45, `实际 ${g.decayDaily(60, 3)}`)
check('跨夜算一天', g.daysBetween(Date.parse('2026-11-01T18:00:00+08:00'), Date.parse('2026-11-02T09:00:00+08:00')) === 1)
check('同一天不算', g.daysBetween(Date.parse('2026-11-01T01:00:00+08:00'), Date.parse('2026-11-01T23:00:00+08:00')) === 0)
check('退不到负数', g.decayDaily(3, 10) === 0, `实际 ${g.decayDaily(3, 10)}`)

console.log('归档')
const archived = g.pruneLedger(ledger, Date.parse('2027-03-01T00:00:00+08:00'))
check('超 90 天被归档', archived.touched === true && archived.events.length === 2)
check('主账已清空旧明细', ledger.accounting.books.fingertest.events.length === 0)
const merged = g.mergeArchive({ version: 1, events: [], days: {} }, archived)
check('归档只增不丢', merged.events.length === 2)

console.log('坏账本与写入（临时目录）')
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gluttony-selftest-'))
const file = path.join(dir, 'ledger.json')

check('缺文件时给空账', g.readLedgerFile(file).recovered === false)
check('能正常写出', g.writeLedgerFile(file, ledger) === true)
const reopened = g.readLedgerFile(file)
check('写后能读回', reopened.recovered === false && reopened.ledger.version === g.LEDGER_VERSION)

fs.writeFileSync(file, '{ 这不是 JSON', 'utf8')
const broken = g.readLedgerFile(file)
check('坏账本被识别', broken.recovered === true)
check('坏账本已备份', typeof broken.backup === 'string' && fs.existsSync(broken.backup))
check('原档仍在（未被覆盖）', fs.readFileSync(file, 'utf8') === '{ 这不是 JSON')
check('空账可直接用', Object.keys(broken.ledger.accounting.books).length === 0)

fs.rmSync(dir, { recursive: true, force: true })

console.log(failed === 0 ? '\n全部通过' : `\n失败 ${failed} 项`)
process.exit(failed === 0 ? 0 : 1)
