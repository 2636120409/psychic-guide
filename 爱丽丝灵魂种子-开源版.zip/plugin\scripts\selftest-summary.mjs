/**
 * 自检：整理输出的读法。
 * 跑法：node scripts/selftest-summary.mjs
 */
import assert from 'node:assert/strict'
import { parseSummaryLines } from '../lib/summary.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('一行一条', () => {
  const out = parseSummaryLines('主人喜欢安静\n改用哈希链记账')
  assert.deepEqual(out, ['主人喜欢安静', '改用哈希链记账'])
})

check('剥掉编号与列表符号', () => {
  assert.deepEqual(parseSummaryLines('1. 主人喜欢安静\n- 换了记账法'), ['主人喜欢安静', '换了记账法'])
})

check('围栏与分区名不算条目', () => {
  const out = parseSummaryLines('```\n底层人格\n长期记忆\n主人喜欢安静\n```')
  assert.deepEqual(out, ['主人喜欢安静'])
})

check('长段落按句读拆开', () => {
  const out = parseSummaryLines('主人喜欢安静。他不爱被打扰；夜里才说话。')
  assert.deepEqual(out, ['主人喜欢安静', '他不爱被打扰', '夜里才说话'])
})

check('「没什么可记」整行丢掉', () => {
  assert.deepEqual(parseSummaryLines('无'), [])
  assert.deepEqual(parseSummaryLines('暂无'), [])
})

check('一条超 200 字的丢掉', () => {
  assert.deepEqual(parseSummaryLines('字'.repeat(201)), [])
})

check('最多留十六条', () => {
  const out = parseSummaryLines(Array.from({ length: 40 }, (_, i) => `第${i}条`).join('\n'))
  assert.equal(out.length, 16)
})

check('空输出给空表', () => {
  assert.deepEqual(parseSummaryLines(''), [])
  assert.deepEqual(parseSummaryLines(null), [])
})

console.log(`\n共 ${count} 项，全过。`)
