/**
 * 试拆 describePoFeatures 的一页：只切数组字面量，不碰页与页之间的声明。
 * 用法：node scripts/_try-split.mjs <id>
 */
import fs from 'node:fs'

const id = process.argv[2]
if (!id) throw new Error('要一个 id')

const p = new URL('../index.js', import.meta.url)
let t = fs.readFileSync(p, 'utf8')

const start = t.indexOf(`  out.${id} = [`)
if (start < 0) throw new Error(`找不到 out.${id}`)
const open = t.indexOf('[', start)

// 数括号，同时躲开字符串与注释
let depth = 0
let i = open
let quote = ''
while (i < t.length) {
  const ch = t[i]
  if (quote !== '') {
    if (ch === '\\') { i += 2; continue }
    if (ch === quote) quote = ''
    i += 1
    continue
  }
  if (ch === "'" || ch === '"' || ch === '`') { quote = ch; i += 1; continue }
  if (ch === '/' && t[i + 1] === '/') { i = t.indexOf('\n', i); if (i < 0) break; continue }
  if (ch === '/' && t[i + 1] === '*') { i = t.indexOf('*/', i); if (i < 0) break; i += 2; continue }
  if (ch === '[') depth += 1
  else if (ch === ']') {
    depth -= 1
    if (depth === 0) { i += 1; break }
  }
  i += 1
}
if (depth !== 0) throw new Error('括号没配平，先别动')

const literal = t.slice(open, i)
const name = `po${id[0].toUpperCase()}${id.slice(1)}`
const definition = `\n  /** ${id} 那一页的功能清单。 */\n  function ${name}() {\n    return ${literal}\n  }\n`

// 原处只留调用；定义插在 return out 前
t = t.slice(0, start) + `  out.${id} = ${name}()\n` + t.slice(t.indexOf('\n', i) + 1)
const fnStart = t.indexOf('function describePoFeatures(')
const ret = t.indexOf('  return out', fnStart)
t = t.slice(0, ret) + definition + t.slice(ret)

fs.writeFileSync(p, t, 'utf8')
console.log(`ok ${name}`)
