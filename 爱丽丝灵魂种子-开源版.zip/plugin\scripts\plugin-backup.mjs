#!/usr/bin/env node
/**
 * 吞贼 · 命令行回退。
 *
 * 插件要是坏到宿主都加载不起来，面板上的按钮自然也点不到；这时用这一支：
 *
 *   node scripts/plugin-backup.mjs list
 *   node scripts/plugin-backup.mjs snapshot [--reason "为什么留"]
 *   node scripts/plugin-backup.mjs restore --latest
 *   node scripts/plugin-backup.mjs restore --id 20261102-194017-247
 *
 * 不加 --plugin 时，默认收拾的就是脚本自己所在的这个插件。
 * 只用 node 内置模块，不依赖插件本体，坏了也能跑。
 */

import path from 'node:path'
import { fileURLToPath } from 'node:url'
import * as backup from '../lib/plugin-backup.mjs'

const here = path.dirname(fileURLToPath(import.meta.url))
const defaultPlugin = path.dirname(here)

function parseArgs(argv) {
  const out = { command: '', plugin: '', reason: '', id: '', latest: false }
  const rest = [...argv]
  out.command = rest.shift() || 'list'
  while (rest.length > 0) {
    const token = rest.shift()
    if (token === '--plugin') out.plugin = rest.shift() || ''
    else if (token === '--reason') out.reason = rest.shift() || ''
    else if (token === '--id') out.id = rest.shift() || ''
    else if (token === '--latest') out.latest = true
    else if (token === '--help' || token === '-h') out.command = 'help'
  }
  return out
}

function when(at) {
  const value = Number(at) || 0
  if (value <= 0) return ''
  const date = new Date(value)
  const pad = (number) => String(number).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
    `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}

function usage() {
  console.log([
    '吞贼 · 插件备份',
    '',
    '  node scripts/plugin-backup.mjs list [--plugin <插件目录>]',
    '  node scripts/plugin-backup.mjs snapshot [--reason "为什么留"] [--plugin <插件目录>]',
    '  node scripts/plugin-backup.mjs restore --latest [--plugin <插件目录>]',
    '  node scripts/plugin-backup.mjs restore --id <快照id> [--plugin <插件目录>]',
    '',
    `库房：${backup.BACKUP_ROOT}`,
  ].join('\n'))
}

function main() {
  const args = parseArgs(process.argv.slice(2))
  const target = args.plugin.trim().length > 0 ? path.resolve(args.plugin.trim()) : defaultPlugin

  if (args.command === 'help') {
    usage()
    return 0
  }

  if (args.command === 'list') {
    const account = backup.summary(target)
    if (account.ok !== true) {
      console.error(`吞贼：找不到插件目录（${target}）`)
      return 2
    }
    console.log(`吞贼的库房：${account.plugin} · ${account.count} 份`)
    console.log(`  ${account.dir}`)
    for (const item of backup.listSnapshots(target)) {
      console.log(`  ${item.id}  ${when(item.at)}  ${String(item.reason || '')}  ` +
        `${Array.isArray(item.files) ? item.files.length : 0} 个文件`)
    }
    if (account.count === 0) console.log('  还空着')
    return 0
  }

  if (args.command === 'snapshot') {
    const result = backup.snapshot(target, args.reason.trim().length > 0 ? args.reason.trim() : '命令行手动')
    if (result.ok !== true) {
      console.error(`吞贼：${result.error || '备份失败'}`)
      return 2
    }
    if (result.skipped === true) {
      console.log(`吞贼：和最近一份一样，不另存（${result.id}）`)
      return 0
    }
    console.log(`吞贼已备份：${result.plugin} · ${(result.files || []).length} 个文件 · ${result.id}`)
    console.log(`  ${result.dir}`)
    return 0
  }

  if (args.command === 'restore') {
    let result
    if (args.latest === true) result = backup.restoreLatest(target)
    else if (args.id.trim().length > 0) result = backup.restore(target, args.id.trim())
    else {
      console.error('要 --latest，或 --id <快照id>；先跑 list 看清 id。')
      return 2
    }
    if (result.ok !== true) {
      console.error(`吞贼：${result.error || '回退失败'}`)
      return 2
    }
    console.log(`已回退：${result.plugin} · ${result.id}（${when(result.at)}）`)
    console.log(`  ${result.restored.length} 个文件回到 ${result.root}`)
    if (Array.isArray(result.extra) && result.extra.length > 0) {
      console.log(`  快照之后才添的 ${result.extra.length} 个文件没动：${result.extra.slice(0, 8).join('、')}`)
    }
    console.log('  宿主里的插件要重新加载一次才吃得到旧版本。')
    return 0
  }

  console.error(`不认识这个命令：${args.command}`)
  usage()
  return 2
}

process.exitCode = main()
