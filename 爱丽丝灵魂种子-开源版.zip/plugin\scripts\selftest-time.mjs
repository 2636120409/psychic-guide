/**
 * 自检：臭肺的时钟与日子的说法。
 * 跑法：node scripts/selftest-time.mjs
 */
import assert from 'node:assert/strict'
import * as time from '../lib/time.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const at = (y, m, d, h = 12, min = 0) => new Date(y, m - 1, d, h, min, 0, 0).getTime()

check('日期按本地日历补零', () => {
  assert.equal(time.dayStamp(at(2026, 3, 7)), '2026-03-07')
})

check('日子的分段', () => {
  assert.equal(time.dayPartOf(5).name, '上午')
  assert.equal(time.dayPartOf(11).name, '上午')
  assert.equal(time.dayPartOf(12).name, '下午')
  assert.equal(time.dayPartOf(17).name, '下午')
  assert.equal(time.dayPartOf(18).name, '晚上')
  assert.equal(time.dayPartOf(4).name, '晚上')
  assert.deepEqual(time.DAY_PARTS.map((item) => item.hour), [9, 15, 21])
})

check('时钟取整到一刻，字面十五分钟不变', () => {
  const one = time.clockStamp(at(2026, 11, 4, 19, 2))
  const two = time.clockStamp(at(2026, 11, 4, 19, 6))
  assert.equal(one, two)
  assert.ok(one.includes('2026-11-04'))
  assert.ok(one.includes('周'))
  assert.ok(one.includes('前后（晚上）'))
})

check('多久以前：刚刚、分钟、钟头、日期', () => {
  const now = at(2026, 11, 4, 19, 0)
  assert.equal(time.ageStamp(now - 30 * 1000, now), '刚刚')
  assert.equal(time.ageStamp(now - 5 * 60 * 1000, now), '5 分钟前')
  assert.equal(time.ageStamp(now - 2 * 60 * 60 * 1000, now), '2 个钟头前')
  assert.equal(time.ageStamp(at(2026, 11, 1, 10), now), '3 天前')
  assert.equal(time.ageStamp(at(2026, 9, 1, 10), now), '2026-09-01')
  assert.equal(time.ageStamp(0, now), '')
})

check('关心那一行只说分钟或小时', () => {
  assert.equal(time.describeAgo(30 * 60 * 1000), '30 分钟')
  assert.equal(time.describeAgo(3 * 60 * 60 * 1000), '3 小时')
  assert.equal(time.describeAgo(0), '1 分钟')
})

console.log(`\n共 ${count} 项，全过。`)
