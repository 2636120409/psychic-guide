/**
 * 自检：非毒的模糊。
 * 跑法：node scripts/selftest-blur.mjs
 */
import assert from 'node:assert/strict'
import { blurNumber, blurText } from '../lib/blur.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('确数换虚数', () => {
  assert.equal(blurNumber(1), '一两')
  assert.equal(blurNumber(5), '几')
  assert.equal(blurNumber(15), '十来')
  assert.equal(blurNumber(50), '几十')
  assert.equal(blurNumber(500), '几百')
  assert.equal(blurNumber(5000), '上千')
  assert.equal(blurNumber('不是数'), '不是数')
})

check('一档抹日期与钟点', () => {
  assert.equal(blurText('2026年11月4日', 1), '那年')
  assert.equal(blurText('2026-11-04', 1), '那天')
  assert.equal(blurText('11月4号', 1), '那天')
  assert.equal(blurText('19:30 见', 1), '那会儿 见')
})

check('一档不动确数以外的东西', () => {
  assert.equal(blurText('吃了三口面', 1), '吃了三口面')
})

check('二档把数目糊掉', () => {
  assert.equal(blurText('吃了 5 口面', 2), '吃了 几口面')
})

check('三档把长引文收成大意', () => {
  const out = blurText('他说「这一整句很长很长的话」，我记着', 3)
  assert.equal(out, '他说「这一整句…」，我记着')
  assert.ok(!out.includes('很长很长的话'))
})

check('档位不到就不动', () => {
  assert.equal(blurText('喝了 8 杯水', 0), '喝了 8 杯水')
})

check('七天后按周、月、年说时间', () => {
  assert.equal(blurText('2026年11月4日 的事', 1, 3), '那年 的事')
  assert.equal(blurText('2026年11月4日 的事', 1, 20), '上周 的事')
  assert.equal(blurText('2026年11月4日 的事', 1, 45), '上个月 的事')
  assert.equal(blurText('2026年11月4日 的事', 1, 200), '半年前 的事')
  assert.equal(blurText('2026年11月4日 的事', 1, 400), '去年 的事')
})

check('糊过的词也跟着变粗', () => {
  assert.equal(blurText('上周他来过', 1, 45), '上个月他来过')
  assert.equal(blurText('上个月他来过', 1, 400), '去年他来过')
})

check('星期几也糊掉', () => {
  assert.equal(blurText('星期三见的', 1, 20), '上周见的')
})

console.log(`\n共 ${count} 项，全过。`)
