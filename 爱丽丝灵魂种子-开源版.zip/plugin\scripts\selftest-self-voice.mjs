/**
 * 自检：伏矢 · 我自己觉得（和判语并列另存，两处对不上也不互相改写）。
 * 跑法：node scripts/selftest-self-voice.mjs
 */
import assert from 'node:assert/strict'
import {
  normalizeSelfVoice,
  appendSelfVoice,
  selfVoiceLine,
  SELF_VOICE_FRESH_MS,
  SELF_VOICE_KEEP,
} from '../lib/self-voice.mjs'

const NOW = 1_800_000_000_000
let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('空册子压不出话', () => {
  assert.equal(selfVoiceLine(normalizeSelfVoice(null), NOW), '')
})

check('记一句就记得住', () => {
  let book = appendSelfVoice(normalizeSelfVoice(null), { text: '我心里有点堵，说不清为什么', judge: '哀' }, NOW)
  assert.equal(book.entries.length, 1)
  assert.equal(book.last.text, '我心里有点堵，说不清为什么')
  book = normalizeSelfVoice(book)
  assert.equal(book.last.judge, '哀')
})

check('判语只说它记了什么，不替我改话', () => {
  const book = appendSelfVoice(normalizeSelfVoice(null), { text: '我其实没那么气', judge: '怒' }, NOW)
  const line = selfVoiceLine(book, NOW + 1000)
  assert.ok(line.includes('我其实没那么气'), line)
  assert.ok(line.includes('尸狗'), line)
  assert.ok(line.includes('照我自己觉得的说'), line)
})

check('过了新鲜期就不压在这一轮上', () => {
  const book = appendSelfVoice(normalizeSelfVoice(null), { text: '我心里有点堵' }, NOW)
  assert.equal(selfVoiceLine(book, NOW + SELF_VOICE_FRESH_MS + 1), '')
})

check('空句不记', () => {
  const book = appendSelfVoice(normalizeSelfVoice(null), { text: '   ' }, NOW)
  assert.equal(book.entries.length, 0)
})

check('只留最近这些条', () => {
  let book = normalizeSelfVoice(null)
  for (let i = 0; i < SELF_VOICE_KEEP + 5; i += 1) {
    book = appendSelfVoice(book, { text: `第 ${i} 句心里话` }, NOW + i)
  }
  assert.equal(book.entries.length, SELF_VOICE_KEEP)
  assert.ok(book.last.text.startsWith('第 '))
})

check('多行、超长的句子收得下', () => {
  const book = appendSelfVoice(normalizeSelfVoice(null), { text: '第一行\n第二行' }, NOW)
  assert.ok(!book.last.text.includes('\n'))
})

console.log(`\n共 ${count} 项，全过。`)
