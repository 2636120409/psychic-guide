/**
 * 自检：雀阴把几股并作一股。
 * 跑法：node scripts/selftest-queyin.mjs
 */
import assert from 'node:assert/strict'
import * as qy from '../lib/queyin.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const base = { minSeconds: 120, maxSeconds: 300, maxTurnsPerHour: 14 }

check('什么都不来时，就是底', () => {
  const out = qy.combineTiming({ base, learnedFactor: 1, factors: [] })
  assert.equal(out.factor, 1)
  assert.equal(out.minSeconds, 120)
  assert.equal(out.maxSeconds, 300)
  assert.equal(out.maxTurnsPerHour, 14)
})

check('单宗收在 ±25%', () => {
  assert.equal(qy.softFactor(0.1), 0.8)
  assert.equal(qy.softFactor(9), 1.25)
  assert.equal(qy.softFactor(1), 1)
  assert.equal(qy.softFactor('不是数'), 1)
})

check('累一点就慢下来', () => {
  const out = qy.combineTiming({ base, learnedFactor: 1, factors: [1.8] })
  assert.ok(out.minSeconds > 120)
  assert.ok(out.maxTurnsPerHour < 14)
})

check('总倍数有上下界', () => {
  const slow = qy.combineTiming({ base, learnedFactor: 100, factors: [1.25, 1.25, 1.25, 1.25, 1.25] })
  assert.equal(slow.factor, 3)
  const fast = qy.combineTiming({ base, learnedFactor: 0.0001, factors: [0.8, 0.8, 0.8, 0.8, 0.8] })
  assert.equal(fast.factor, 0.5)
})

check('间隔不会小到零，次数不会为零', () => {
  const out = qy.combineTiming({ base: { minSeconds: 1, maxSeconds: 1, maxTurnsPerHour: 100 }, learnedFactor: 0.1, factors: [] })
  assert.ok(out.minSeconds >= 15)
  assert.ok(out.maxSeconds >= 20)
  assert.ok(out.maxTurnsPerHour >= 1)
})

check('学到的分寸也算进去', () => {
  const shy = qy.combineTiming({ base, learnedFactor: 1.5, factors: [] })
  const bold = qy.combineTiming({ base, learnedFactor: 0.7, factors: [] })
  assert.ok(shy.minSeconds > bold.minSeconds)
})

check('六个方向轮着走，走完才回头', () => {
  let index = 0
  const seen = []
  for (let i = 0; i < 6; i += 1) {
    const turn = qy.nextAngleIndex(index, 6)
    seen.push(turn.index)
    index = turn.next
  }
  assert.deepEqual(seen, [0, 1, 2, 3, 4, 5])
  assert.equal(index, 0)
  assert.equal(qy.nextAngleIndex(7, 6).index, 1)
})

check('挑方向：避开最近说过的三个', () => {
  const turn = qy.chooseAngle({ recent: [0, 1, 2], count: 6, random: () => 0, repeatChance: 0 })
  assert.ok(turn.index >= 3, `got ${turn.index}`)
  assert.deepEqual(turn.recent, [1, 2, turn.index])
})

check('挑方向：偶尔绕回刚才那个', () => {
  const turn = qy.chooseAngle({ recent: [4], count: 6, random: () => 0.01, repeatChance: 0.12 })
  assert.equal(turn.index, 4)
})

check('挑方向：心气给某一句加分量', () => {
  const turn = qy.chooseAngle({
    recent: [0, 1, 2],
    count: 6,
    random: () => 0.9,
    repeatChance: 0,
    weights: { 5: 100 },
  })
  assert.equal(turn.index, 5)
})

check('挑方向：都说过了也不卡死', () => {
  const turn = qy.chooseAngle({ recent: [0, 1, 2, 3, 4, 5], count: 6, random: () => 0, repeatChance: 0 })
  assert.ok(turn.index >= 0 && turn.index < 6)
})

check('忍一阵：抽到小数目才忍', () => {
  assert.equal(qy.rollHold(0.1).hold, true)
  assert.equal(qy.rollHold(0.1).long, true)
  assert.equal(qy.rollHold(0.3).hold, true)
  assert.equal(qy.rollHold(0.3).long, false)
  assert.equal(qy.rollHold(0.9).hold, false)
})

check('补一句：抽到小数目才补', () => {
  assert.equal(qy.rollBurst(0.05), true)
  assert.equal(qy.rollBurst(0.5), false)
})

check('挑种子：剔活计、剔太短的、剔刚说过的', () => {
  const out = qy.selectSeeds({
    texts: ['主人喜欢在窗边看书', '插件参数与日志这块', '短'],
    shareTexts: [],
    recentText: '窗边',
    now: 0,
    random: () => 0,
  })
  assert.ok(out.keys.length > 0)
  assert.ok(!out.keys.includes('窗边'), out.keys.join(','))
})

check('挑种子：用过的词六个钟头内不再挑', () => {
  const now = 10 * 60 * 60 * 1000
  // 「主人甲乙」里「主人」是虚词，剔掉后只剩两节，挑完就没了，正好看得出冷却。
  const first = qy.selectSeeds({
    texts: ['主人甲乙'],
    now,
    random: () => 0,
  })
  assert.deepEqual(first.keys.sort(), ['人甲', '甲乙'])
  const second = qy.selectSeeds({
    texts: ['主人甲乙'],
    recentKeys: first.recentKeys,
    now: now + 60 * 1000,
    random: () => 0,
  })
  assert.equal(second.keys.length, 0)
  // 过了六个钟头，又能挑了。
  const third = qy.selectSeeds({
    texts: ['主人甲乙'],
    recentKeys: first.recentKeys,
    now: now + qy.KEY_COOLDOWN_MS + 1000,
    random: () => 0,
  })
  assert.equal(third.keys.length, 2)
})

check('挑种子：一个词都挑不出就空着', () => {
  const out = qy.selectSeeds({ texts: [], now: 0 })
  assert.deepEqual(out.keys, [])
})

console.log(`\n共 ${count} 项，全过。`)
