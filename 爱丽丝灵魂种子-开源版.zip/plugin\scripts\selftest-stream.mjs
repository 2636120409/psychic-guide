/**
 * 自检：读模型吐出来的那一道流。
 * 跑法：node scripts/selftest-stream.mjs
 */
import assert from 'node:assert/strict'
import { collectStream } from '../lib/stream.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

async function* fake(chunks) {
  for (const chunk of chunks) yield chunk
}

const run = async () => {
  check('收正文、数分片', async () => {
    const out = await collectStream(fake([
      { type: 'text-delta', text: '甲' },
      { type: 'text-delta', text: '乙' },
    ]))
    assert.equal(out.text, '甲乙')
    assert.equal(out.chunks, 2)
    assert.equal(out.failure, '')
  })

  check('正常收尾不算失败', async () => {
    const out = await collectStream(fake([
      { type: 'text-delta', text: '好' },
      { type: 'finish', reason: { kind: 'stop' } },
    ]))
    assert.equal(out.failure, '')
  })

  check('非正常收尾记得下', async () => {
    const out = await collectStream(fake([
      { type: 'text-delta', text: '半' },
      { type: 'finish', reason: { kind: 'length' } },
    ]))
    assert.equal(out.failure, 'length')
  })

  check('出错时取那句话', async () => {
    const out = await collectStream(fake([
      { type: 'finish', reason: { kind: 'error', failure: new Error('炸了') } },
    ]))
    assert.equal(out.failure, '炸了')
  })

  check('边读边过一手', async () => {
    const seen = []
    await collectStream(fake([{ type: 'text-delta', text: '一' }, { type: 'text-delta', text: '二' }]), {
      onText: (piece) => seen.push(piece),
    })
    assert.deepEqual(seen, ['一', '二'])
  })

  check('坏分片不崩', async () => {
    const out = await collectStream(fake([null, 42, { type: 'text-delta', text: '字' }]))
    assert.equal(out.text, '字')
    assert.equal(out.chunks, 3)
  })

  console.log(`\n共 ${count} 项，全过。`)
}

await run()
