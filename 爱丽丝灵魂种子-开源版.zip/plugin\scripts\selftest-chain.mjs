/**
 * 自检：账链的哈希链。
 * 跑法：node scripts/selftest-chain.mjs
 */
import assert from 'node:assert/strict'
import * as chain from '../lib/chain.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const sample = () => [
  { at: 1000, kind: 'manual', text: '主人喜欢安静' },
  { at: 2000, kind: 'daily', text: '改用哈希链记账' },
  { at: 3000, kind: 'emotion', text: '一夜没睡好' },
]

check('打封条后验得过', () => {
  const list = sample()
  const { tip } = chain.seal(list)
  const result = chain.audit(list, tip)
  assert.equal(result.ok, true)
  assert.equal(result.count, 3)
})

check('改一个字，断在那一条', () => {
  const list = sample()
  const { tip } = chain.seal(list)
  list[1].text = '改用哈希链记帐'
  const result = chain.audit(list, tip)
  assert.equal(result.ok, false)
  assert.equal(result.brokenAt, 2)
  assert.equal(result.reason, 'hash')
})

check('接掉一环，断在衔接处', () => {
  const list = sample()
  chain.seal(list)
  list[2].prev = ''
  const result = chain.audit(list)
  assert.equal(result.ok, false)
  assert.equal(result.brokenAt, 3)
  assert.equal(result.reason, 'prev')
})

check('链尾对不上也算断', () => {
  const list = sample()
  chain.seal(list)
  const result = chain.audit(list, 'deadbeef')
  assert.equal(result.ok, false)
  assert.equal(result.reason, 'tip')
})

check('没上过链的旧账不算断', () => {
  const result = chain.audit([{ at: 1, text: '旧' }, { at: 2, text: '账' }])
  assert.equal(result.ok, true)
  assert.equal(result.unsealed, true)
})

check('空账也验得过', () => {
  const { tip } = chain.seal([])
  assert.equal(tip, '')
  assert.equal(chain.audit([], '').ok, true)
})

check('指纹只看该看的字段', () => {
  const one = chain.chainPayload({ at: 1, kind: 'daily', text: '甲', hits: 3 })
  const two = chain.chainPayload({ at: 1, kind: 'daily', text: '甲', hits: 99 })
  assert.equal(one, two)
})

console.log(`\n共 ${count} 项，全过。`)
