/**
 * 自检：七情合并成此刻的读数。
 * 跑法：node scripts/selftest-emotion-vector.mjs
 */
import assert from 'node:assert/strict'
import * as vec from '../lib/emotion-vector.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const pick = (list, id) => list.find((item) => item.id === id)

check('七样俱全，缺的为零', () => {
  const out = vec.vectorFromRecords([])
  assert.equal(out.length, 7)
  assert.ok(out.every((item) => item.value === 0))
})

check('一条记录原样折成百分数', () => {
  const out = vec.vectorFromRecords([{ emotions: [{ id: 'xi', name: '喜', score: 0.8 }] }])
  assert.equal(pick(out, 'xi').value, 80)
})

check('同一种情散在几条里会亮一点，但不过一', () => {
  const out = vec.vectorFromRecords([
    { emotions: [{ id: 'ai', name: '爱', score: 0.6 }] },
    { emotions: [{ id: 'ai', name: '爱', score: 0.5 }] },
  ])
  const value = pick(out, 'ai').value
  assert.ok(value > 60 && value <= 100, `got ${value}`)
})

check('相反的两情彼此压一压', () => {
  const out = vec.vectorFromRecords([
    { emotions: [{ id: 'xi', name: '喜', score: 0.6 }, { id: 'bei', name: '哀', score: 0.6 }] },
  ])
  assert.ok(pick(out, 'xi').value < 60, `got ${pick(out, 'xi').value}`)
  assert.ok(pick(out, 'bei').value < 60)
})

check('不为零的才进合并', () => {
  const out = vec.vectorFromRecords([{ emotions: [{ id: 'nu', name: '怒', score: 0 }, { id: 'wu', name: '恶', score: 0.4 }] }])
  assert.equal(pick(out, 'nu').value, 0)
  assert.equal(pick(out, 'wu').value, 40)
})

check('坏记录不崩', () => {
  const out = vec.vectorFromRecords([null, {}, { emotions: 'x' }, { emotions: [{ id: 'xi', name: '喜', score: '0.3' }] }])
  assert.equal(pick(out, 'xi').value, 30)
})

console.log(`\n共 ${count} 项，全过。`)
