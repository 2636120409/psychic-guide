/**
 * 自检：伏矢 · 七情的体感（七情的读数合成一句话，不报数）。
 * 跑法：node scripts/selftest-emotion-voice.mjs
 */
import assert from 'node:assert/strict'
import { emotionVoiceLine, emotionVoiceLines } from '../lib/emotion-voice.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('一样都不够门槛，就淡淡的', () => {
  assert.ok(emotionVoiceLine({ ai: 5, xi: 3, wu: 0, nu: 0, bei: 0, ju: 0, yu: 0 }).includes('淡淡'), emotionVoiceLine({}))
})

check('缺项按零算，不抛', () => {
  assert.ok(emotionVoiceLine().length > 0)
  assert.ok(emotionVoiceLine({ ai: 60 }).includes('偏暖'))
})

check('最重的一情当主调', () => {
  const line = emotionVoiceLine({ ai: 10, bei: 40 })
  assert.ok(line.includes('发沉'), line)
})

check('第二重的那根缀在后头当旁注', () => {
  const line = emotionVoiceLine({ bei: 40, xi: 50 })
  assert.ok(line.includes('轻快'), line)
  assert.ok(line.includes('；'), line)
})

check('数只用来挑话，不出现在话里', () => {
  const line = emotionVoiceLine({ ai: 72, xi: 51, wu: 22, nu: 19, bei: 41, ju: 31, yu: 25 })
  assert.ok(!/\d/.test(line), line)
})

check('嫌恶重时话短、不辩解', () => {
  const line = emotionVoiceLine({ wu: 30 })
  assert.ok(line.includes('短'), line)
})

check('想要重时是「说一句就等」，不催', () => {
  const line = emotionVoiceLine({ yu: 30 })
  assert.ok(line.includes('不催'), line)
})

check('递出去的只有一句', () => {
  const lines = emotionVoiceLines({ ai: 60 })
  assert.equal(lines.length, 1)
  assert.ok(lines[0].length > 0)
})

console.log(`\n共 ${count} 项，全过。`)
