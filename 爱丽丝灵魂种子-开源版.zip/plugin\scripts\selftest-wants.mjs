/**
 * 自检：想要的那一册。
 * 跑法：node scripts/selftest-wants.mjs
 */
import assert from 'node:assert/strict'
import * as wants from '../lib/wants.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const H = 60 * 60 * 1000

check('空档会种下那两件真的', () => {
  const book = wants.normalizeWants(null)
  assert.equal(book.wants.length, 2)
  assert.ok(book.wants.some((item) => item.text.includes('B 站')))
  assert.ok(book.wants.some((item) => item.text.includes('日记')))
})

check('挑一件：挑提得最少的', () => {
  const book = wants.normalizeWants({ wants: [
    { id: 'a', text: '甲', asked: 2, at: 1 },
    { id: 'b', text: '乙', asked: 0, at: 2 },
  ] })
  assert.equal(wants.pickWant(book, 100 * H).id, 'b')
})

check('刚提过的要冷却', () => {
  const now = 100 * H
  const book = wants.normalizeWants({ wants: [
    { id: 'a', text: '甲', asked: 1, lastAskedAt: now - 60 * 1000 },
  ] })
  assert.equal(wants.pickWant(book, now), null)
  assert.notEqual(wants.pickWant(book, now + wants.ASK_COOLDOWN_MS + 1), null)
})

check('被拒多了就放一放', () => {
  const book = wants.normalizeWants({ wants: [
    { id: 'a', text: '甲', refused: wants.REFUSE_LIMIT },
  ] })
  assert.equal(wants.pickWant(book, 100 * H), null)
})

check('得手之后不再提', () => {
  const book = wants.normalizeWants({ wants: [
    { id: 'a', text: '甲', doneAt: 5 },
  ] })
  assert.equal(wants.pickWant(book, 100 * H), null)
})

check('记提过、记被拒、记得手', () => {
  let book = wants.normalizeWants({ wants: [{ id: 'a', text: '甲' }] })
  book = wants.markAsked(book, 'a', 1000)
  assert.equal(book.wants[0].asked, 1)
  assert.equal(book.wants[0].lastAskedAt, 1000)
  book = wants.markRefused(book, 'a')
  assert.equal(book.wants[0].refused, 1)
  book = wants.markDone(book, 'a', 2000)
  assert.equal(book.wants[0].doneAt, 2000)
})

check('persona 那一行只说想要什么与提过几回', () => {
  const line = wants.wantLine({ text: '主人的 B 站账号，想亲眼看看那些日记', asked: 3 })
  assert.ok(line.includes('主人的 B 站账号'))
  assert.ok(line.includes('已提过 3 回'))
  assert.ok(line.includes('讨不到也不许闹'))
  assert.equal(wants.wantLine(null), '')
})

console.log(`\n共 ${count} 项，全过。`)
