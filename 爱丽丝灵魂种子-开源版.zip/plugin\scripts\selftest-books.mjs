/**
 * 自检：账本的路（旧账往前迁，新账不降）。
 * 跑法：node scripts/selftest-books.mjs
 */
import assert from 'node:assert/strict'
import { migrateBook } from '../lib/books.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('同版不动', () => {
  const out = migrateBook({ version: 1, a: 1 }, 1, [])
  assert.equal(out.migrated, false)
  assert.equal(out.book.version, 1)
  assert.equal(out.book.a, 1)
})

check('没有版本号的旧档，盖个戳', () => {
  const out = migrateBook({ a: 1 }, 1, [])
  assert.equal(out.book.version, 1)
  assert.equal(out.migrated, true)
  assert.equal(out.from, 0)
})

check('旧账按步往前迁', () => {
  const steps = [
    (book) => ({ ...book, added: true }),
  ]
  const out = migrateBook({ version: 1 }, 2, steps)
  assert.equal(out.book.version, 2)
  assert.equal(out.book.added, true)
  assert.equal(out.to, 2)
})

check('缺了一步就停在能到的版本', () => {
  const out = migrateBook({ version: 1 }, 3, [(book) => ({ ...book, step2: true })])
  assert.equal(out.book.version, 2)
  assert.equal(out.to, 2)
})

check('比代码还新的账：原样留着，不动', () => {
  const future = { version: 9, mystery: 'x' }
  const out = migrateBook(future, 1, [])
  assert.equal(out.future, true)
  assert.equal(out.book.version, 9)
  assert.equal(out.book.mystery, 'x')
  assert.equal(out.migrated, false)
})

check('读坏的账不当账，按空册处理', () => {
  const out = migrateBook(null, 1, [])
  assert.equal(out.book.version, 1)
  assert.equal(out.future, false)
})

console.log(`\n共 ${count} 项，全过。`)
