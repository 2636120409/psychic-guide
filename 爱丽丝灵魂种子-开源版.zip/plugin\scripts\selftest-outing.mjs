/**
 * 自检：吞贼外头那一趟的簿子。
 * 跑法：node scripts/selftest-outing.mjs
 */
import assert from 'node:assert/strict'
import {
  normalizeOuting,
  shouldGoOut,
  fingerprint,
  isSeen,
  noteOuting,
  addSeen,
  MIN_GAP_MS,
} from '../lib/outing.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const NOW = 1_760_000_000_000

check('空册也能读', () => {
  const book = normalizeOuting(undefined)
  assert.equal(book.version, 1)
  assert.deepEqual(book.outings, [])
  assert.deepEqual(book.seen, [])
  assert.equal(book.lastOutAt, 0)
})

check('从没出过门，就该出门', () => {
  const verdict = shouldGoOut(normalizeOuting({}), NOW)
  assert.equal(verdict.go, true)
  assert.equal(verdict.todayCount, 0)
})

check('刚出门不久，不出门', () => {
  const book = normalizeOuting({ lastOutAt: NOW - 60 * 60 * 1000 })
  const verdict = shouldGoOut(book, NOW)
  assert.equal(verdict.go, false)
  assert.match(verdict.reason, /分钟/)
})

check('隔够了就得出门', () => {
  const book = normalizeOuting({ lastOutAt: NOW - MIN_GAP_MS - 1 })
  assert.equal(shouldGoOut(book, NOW).go, true)
})

check('一天两趟就封顶', () => {
  const book = normalizeOuting({
    lastOutAt: NOW - MIN_GAP_MS - 1,
    outings: [{ at: NOW - 3 * 60 * 60 * 1000 }, { at: NOW - 5 * 60 * 60 * 1000 }],
  })
  const verdict = shouldGoOut(book, NOW)
  assert.equal(verdict.go, false)
  assert.match(verdict.reason, /今天已经出去 2 趟/)
})

check('昨天的趟数不算今天', () => {
  const book = normalizeOuting({
    lastOutAt: NOW - 30 * 60 * 60 * 1000,
    outings: [{ at: NOW - 30 * 60 * 60 * 1000 }, { at: NOW - 40 * 60 * 60 * 1000 }],
  })
  const verdict = shouldGoOut(book, NOW)
  assert.equal(verdict.go, true)
  assert.equal(verdict.todayCount, 0)
})

check('时间倒着来也不认', () => {
  const book = normalizeOuting({ lastOutAt: NOW + 60 * 60 * 1000 })
  assert.equal(shouldGoOut(book, NOW).go, false)
})

check('指纹去空白去标点', () => {
  assert.equal(fingerprint('  Rust 1.90 发布，性能提升。 '), fingerprint('Rust 1.90发布性能提升'))
  assert.equal(fingerprint(''), '')
})

check('递过的条目不该再递', () => {
  let book = addSeen(normalizeOuting({}), ['Rust 1.90 发布了，性能提升'], NOW)
  assert.equal(isSeen(book, 'Rust 1.90发布了 性能提升', NOW + 1000), true)
  assert.equal(isSeen(book, '别的新闻', NOW + 1000), false)
})

check('隔了三十天，旧条目放行', () => {
  const book = addSeen(normalizeOuting({}), ['一条旧闻'], NOW)
  assert.equal(isSeen(book, '一条旧闻', NOW + 31 * 24 * 60 * 60 * 1000), false)
})

check('出了门就记时辰', () => {
  let book = noteOuting(normalizeOuting({}), NOW, 4)
  assert.equal(book.lastOutAt, NOW)
  assert.equal(book.outings.length, 1)
  assert.equal(book.outings[0].count, 4)
})

check('册子越攒越短', () => {
  let book = normalizeOuting({})
  for (let i = 0; i < 260; i += 1) book = addSeen(book, [`第 ${i} 条`], NOW + i)
  assert.equal(book.seen.length, 200)
})

check('比代码新的册子原样留着', () => {
  const raw = { version: 9, lastOutAt: NOW, seen: [{ key: 'x', at: NOW }] }
  const book = normalizeOuting(raw)
  assert.equal(book.seen.length, 1)
  assert.equal(book.lastOutAt, NOW)
})

console.log(`\n共 ${count} 项，全过。`)
