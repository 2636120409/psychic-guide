/**
 * 自检：尸狗的字面一册（关键词判情与判语解析）。
 * 跑法：node scripts/selftest-judge.mjs
 */
import assert from 'node:assert/strict'
import * as judge from '../lib/judge.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('七情词表是七样，名字不重复', () => {
  assert.equal(judge.FRAMES.length, 7)
  const names = judge.FRAMES.map((frame) => frame.name)
  assert.equal(new Set(names).size, 7)
})

check('一句软话判出爱与喜', () => {
  const got = judge.judgeEmotions('想你了，看见你就开心')
  const ids = got.map((one) => one.id)
  assert.ok(ids.includes('ai'))
  assert.ok(ids.includes('xi'))
  assert.ok(got[0].score <= 1 && got[0].score > 0)
})

check('感叹号抬分，接近封顶', () => {
  const got = judge.judgeEmotions('气死了！！！离谱！！')
  assert.equal(got[0].id, 'nu')
  assert.ok(got[0].score >= 0.7 && got[0].score <= 1, `got ${got[0].score}`)
})

check('干净的一句不判出任何情', () => {
  assert.deepEqual(judge.judgeEmotions('把窗关一下'), [])
})

check('判语切成主人与我两段', () => {
  const parts = judge.splitJudgeSections('主人：怒 0.60\n我：惧 0.40')
  assert.ok(parts.master.includes('怒'))
  assert.ok(parts.own.includes('惧'))
})

check('读模型写回来的分数', () => {
  const got = judge.parseEmotionScores('喜 0.80\n喜 0.40\n哀 0.50')
  assert.equal(got[0].id, 'xi')
  assert.equal(got[0].score, 0.8)
  assert.ok(got.length >= 2 && got.length <= 3)
})

check('归因与托词的方向', () => {
  assert.equal(judge.splitJudgeAttribution('归因：外').d, 1)
  assert.equal(judge.splitJudgeAttribution('归因：内').d, -1)
  assert.equal(judge.guessAttribution('我搞砸了'), 1)
  assert.equal(judge.guessAttribution('你怎么又弄错'), -1)
  assert.equal(judge.guessAttribution('今天有雨'), 0)
})

check('是不是冲着我来', () => {
  assert.equal(judge.aimedAtMeNow(0, '你怎么又弄错'), true)
  assert.equal(judge.aimedAtMeNow(0, '你帮我把这个改一下'), false)
  assert.equal(judge.aimedAtMeNow(1, '你怎么又弄错'), false)
  // 从前这一句会过认：句里带「错」字（如「报错」）就被当成冲我来的。
  assert.equal(judge.aimedAtMeNow(0, '你帮我看下报错'), false)
  assert.equal(judge.aimedAtMeNow(0, '你这段代码老是出错'), true)
  // 真在责备的「错」还认得出，别把这条窄则收过了头。
  assert.equal(judge.aimedAtMeNow(0, '你这句写错了'), true)
  assert.equal(judge.aimedAtMeNow(0, '你错了'), true)
})

check('夸奖与否定', () => {
  assert.equal(judge.guessPraise('真聪明'), 1)
  assert.equal(judge.guessPraise('谢谢'), 0)
  assert.equal(judge.guessNegation('不对'), true)
})

check('离题三档', () => {
  assert.equal(judge.guessOffTopic('他们说这个插件要重写'), 2)
  assert.equal(judge.guessOffTopic('短'), 0)
})

console.log(`\n共 ${count} 项，全过。`)

check('判语后头那几行：得手、落空、夸奖、离题、归因都在', () => {
  const suffix = judge.JUDGE_SUFFIX
  for (const word of ['得手', '落空', '夸奖', '离题', '归因：外／内／无']) {
    assert.ok(suffix.includes(word), `缺 ${word}`)
  }
  assert.ok(!suffix.includes('}}'), '模板占位符漏出来了')
})
