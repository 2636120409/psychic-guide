/**
 * 自检：面板上那几句话。
 * 跑法：node scripts/selftest-report.mjs
 */
import assert from 'node:assert/strict'
import * as report from '../lib/report.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('查装：没东西、出错、空包', () => {
  assert.equal(report.formatScanReport(null), '尸狗没有查着东西')
  assert.equal(report.formatScanReport({ error: '读不了' }), '尸狗：读不了')
  assert.equal(report.formatScanReport({ packages: [] }), '尸狗：还没查到已装的插件')
})

check('查装：danger 有险、warn 存疑、其余无碍', () => {
  const text = report.formatScanReport({
    packages: [{ name: '某插件', version: '1.0.0', level: 'warn', items: [{ level: 'danger', text: '外连地址' }] }],
  })
  assert.ok(text.includes('某插件 1.0.0：存疑'))
  assert.ok(text.includes('✕ 外连地址'))
})

check('备份：什么都没翻到', () => {
  assert.equal(report.formatBackupReport(null), '吞贼没有翻到备份')
  assert.equal(report.formatBackupReport({ ok: false }), '吞贼：没有找到插件目录（package.json 里缺 dsh 声明）')
})

check('备份：一样就不另存', () => {
  assert.equal(report.formatBackupReport({ ok: true, skipped: true, id: 'abc' }), '吞贼：这一份和最近一次备份一样，不另存（abc）')
})

check('备份：刚备份完', () => {
  const text = report.formatBackupReport({ ok: true, plugin: '插件', id: 'x1', files: ['a', 'b'] })
  assert.ok(text.includes('吞贼已备份：插件 · 2 个文件 · x1'))
})

check('备份：库房清单与空库房', () => {
  const empty = report.formatBackupReport({ ok: true, plugin: '插件', count: 0, snapshots: [] })
  assert.ok(empty.includes('还空着，等第一回改动'))
  const some = report.formatBackupReport({
    ok: true,
    plugin: '插件',
    count: 1,
    snapshots: [{ id: 's1', reason: '改东西', files: 3 }],
  })
  assert.ok(some.includes('s1 · 改东西 · 3 个文件'))
  assert.ok(some.includes('回退：plugin_backup action=restore'))
})

check('备份：回退之后说的话', () => {
  const text = report.formatBackupReport({
    restored: ['index.js'],
    plugin: '插件',
    reason: '改坏了',
    id: 's9',
    extra: ['新文件'],
  })
  assert.ok(text.includes('已回退：插件 · 改坏了'))
  assert.ok(text.includes('1 个文件回到原位'))
  assert.ok(text.includes('快照之后才添的 1 个文件没动：新文件'))
})

console.log(`\n共 ${count} 项，全过。`)
