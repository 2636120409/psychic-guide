/**
 * 自检：暴怒的冷却（一天一回、一周两回）。
 * 跑法：node scripts/selftest-wrath-guard.mjs
 */
import assert from 'node:assert/strict'
import { normalizeGuard, allowOutburst, dayKeyOf, weekKeyOf } from '../lib/wrath-guard.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const MONDAY = new Date(2026, 10, 9, 10, 0, 0).getTime() // 2026-11-09 周一

check('同一天只许一回', () => {
  const first = allowOutburst(normalizeGuard(null), MONDAY)
  assert.equal(first.ok, true)
  const second = allowOutburst(first.guard, MONDAY + 60 * 1000)
  assert.equal(second.ok, false)
  assert.ok(second.why.includes('冷却'))
})

check('第二天翻开新的一页', () => {
  const first = allowOutburst(normalizeGuard(null), MONDAY)
  const nextDay = allowOutburst(first.guard, MONDAY + 24 * 60 * 60 * 1000)
  assert.equal(nextDay.ok, true)
})

check('一周只许两回，第三回压着', () => {
  let guard = normalizeGuard(null)
  const tuesday = MONDAY + 24 * 60 * 60 * 1000
  const wednesday = MONDAY + 2 * 24 * 60 * 60 * 1000
  guard = allowOutburst(guard, MONDAY).guard
  guard = allowOutburst(guard, tuesday).guard
  const third = allowOutburst(guard, wednesday)
  assert.equal(third.ok, false)
})

check('跨了下周就重新数', () => {
  let guard = normalizeGuard(null)
  guard = allowOutburst(guard, MONDAY).guard
  guard = allowOutburst(guard, MONDAY + 24 * 60 * 60 * 1000).guard
  const nextMonday = MONDAY + 7 * 24 * 60 * 60 * 1000
  assert.equal(allowOutburst(guard, nextMonday).ok, true)
})

check('日期键按本地日子算，周一当周首', () => {
  assert.equal(dayKeyOf(MONDAY), '2026-11-09')
  assert.equal(weekKeyOf(MONDAY), '2026-11-09')
  assert.equal(weekKeyOf(MONDAY + 3 * 24 * 60 * 60 * 1000), '2026-11-09')
  assert.equal(weekKeyOf(MONDAY + 7 * 24 * 60 * 60 * 1000), '2026-11-16')
})

console.log(`\n共 ${count} 项，全过。`)
