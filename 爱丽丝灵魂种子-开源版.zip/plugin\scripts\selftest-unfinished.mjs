/**
 * 自检：伏矢 · 未了之事（记搁着的事，隔一阵才提，提过几回就放一放）。
 * 跑法：node scripts/selftest-unfinished.mjs
 */
import assert from 'node:assert/strict'
import {
  normalizeUnfinished,
  noteUnfinished,
  pickUnfinished,
  mentionUnfinished,
  finishUnfinished,
  unfinishedLine,
  deferredOf,
  UNFINISHED_GAP_MS,
  UNFINISHED_GAP_WANT_MS,
  UNFINISHED_MENTION_LIMIT,
  UNFINISHED_AGE_MS,
} from '../lib/unfinished.mjs'

const NOW = 1_800_000_000_000
let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('空册子挑不出东西', () => {
  assert.equal(pickUnfinished(normalizeUnfinished(null), NOW), null)
})

check('刚记下的不算「搁着」，得等一阵', () => {
  const book = noteUnfinished(normalizeUnfinished(null), { text: '主人那句回头再说的B站账号', kind: 'want' }, NOW)
  assert.equal(pickUnfinished(book, NOW + 1000), null)
  assert.ok(pickUnfinished(book, NOW + UNFINISHED_GAP_WANT_MS + 1) !== null)
})

check('想要隔得久些才再提，别的事几个钟头', () => {
  const want = noteUnfinished(normalizeUnfinished(null), { text: '想看那些日记', kind: 'want' }, NOW)
  const other = noteUnfinished(normalizeUnfinished(null), { text: '话说了一半没说完', kind: 'unsaid' }, NOW)
  assert.equal(pickUnfinished(want, NOW + UNFINISHED_GAP_MS + 1), null)
  assert.ok(pickUnfinished(other, NOW + UNFINISHED_GAP_MS + 1) !== null)
})

check('同一件事不记两遍', () => {
  let book = noteUnfinished(normalizeUnfinished(null), { text: '主人那句回头再说的B站账号', kind: 'want' }, NOW)
  book = noteUnfinished(book, { text: '主人那句回头再说的B站账号', kind: 'want' }, NOW + 1000)
  assert.equal(book.items.length, 1)
})

check('给了 id 就照给的记，好按 id 了结', () => {
  const book = noteUnfinished(normalizeUnfinished(null), { text: '想看那些日记', kind: 'want', id: 'want-bilibili' }, NOW)
  assert.equal(book.items[0].id, 'want-bilibili')
})

check('提过几回还搁着，就先放一放', () => {
  let book = noteUnfinished(normalizeUnfinished(null), { text: '想看那些日记', kind: 'want' }, NOW)
  const id = book.items[0].id
  for (let i = 0; i < UNFINISHED_MENTION_LIMIT; i += 1) {
    book = mentionUnfinished(book, id, NOW + (i + 1) * UNFINISHED_GAP_WANT_MS)
  }
  assert.equal(pickUnfinished(book, NOW + 10 * UNFINISHED_GAP_WANT_MS), null)
})

check('了结的不再提', () => {
  let book = noteUnfinished(normalizeUnfinished(null), { text: '想看那些日记', kind: 'want' }, NOW)
  book = finishUnfinished(book, book.items[0].id, NOW + 1000)
  assert.equal(pickUnfinished(book, NOW + 20 * UNFINISHED_GAP_WANT_MS), null)
})

check('搁太久的事自己淡掉', () => {
  const book = noteUnfinished(normalizeUnfinished(null), { text: '话说了一半', kind: 'unsaid' }, NOW)
  assert.equal(pickUnfinished(book, NOW + UNFINISHED_AGE_MS + 1), null)
})

check('交代出去的那句不催不讨', () => {
  const line = unfinishedLine({ text: '想看那些日记', kind: 'want', at: NOW }, NOW + 5 * 60 * 60 * 1000)
  assert.ok(line.includes('不是催'), line)
  assert.ok(line.includes('别提成提醒'), line)
  assert.ok(line.includes('想看那些日记'), line)
})

check('「回头再说」认得出', () => {
  assert.ok(deferredOf('这事回头再说吧').length > 0)
  assert.ok(deferredOf('等会儿再聊').length > 0)
  assert.equal(deferredOf('今天天气不错'), '')
  assert.equal(deferredOf(''), '')
})

check('自己记挂的事先说话，带着为什么', () => {
  const want = noteUnfinished(normalizeUnfinished(null), { text: '想要的那件', kind: 'want' }, NOW)
  const notice = noteUnfinished(want, { text: '直播间里那句话没想通', kind: 'notice', why: '心里搁着' }, NOW)
  const picked = pickUnfinished(notice, NOW + UNFINISHED_GAP_MS + 1)
  assert.ok(picked !== null)
  assert.equal(picked.kind, 'notice')
  const line = unfinishedLine(picked, NOW + UNFINISHED_GAP_MS + 2)
  assert.ok(line.includes('记挂着'), line)
  assert.ok(line.includes('心里搁着'), line)
})

console.log(`\n共 ${count} 项，全过。`)
