# 吞贼 · 改前备份与回退

改插件最怕一种局面：改完起不来，旧的那份又没留。吞贼多担了一职——**每次动插件文件之前，先把眼下的样子收进库房**。

## 什么时候自动留

| 时机 | 说明 |
|---|---|
| 插件启动 | 加载成功时留一份，指纹没变就不另存 |
| 改动落笔前 | `write` / `edit` 等工具碰到插件目录里的文件，guard 在真正写盘**之前**同步拍照 |
| 面板「现在备份」 | 手动补一张 |
| 回退之前 | 先给现版本留一份，退错了还能再回来 |

自动那一张是同步的：工具还没写下去，旧文件已经在 `$DSH_HOME/backups/plugins/<包名>/<时间戳>/` 里了。同一阵子连着改几处，20 秒内只留第一张。

## 收哪些文件

按 `package.json` 的 `files` 清单收，外加 `package.json`、`cordis.patch.yml` 与 `scripts/`。`node_modules`、`.git` 与音频图片这类大件跳过；连年留下的 `index.v3.js`、`*.bak` 之类旧稿也不收，库房不会被撑大。

每份快照带一个 `manifest.json`：插件名、版本、时间、备份理由、每个文件的相对路径与 sha256、总字节数。每个插件最多留 30 份，再多丢最旧的。

## 怎么打开

- **面板**：吞贼那一块里有「插件备份 · 守旧版本」，能看现有几份、现在备份、退回某一版。
- **工具**：`plugin_backup`
  - `action=list` 看现有（默认）
  - `action=create` 现在备份一次
  - `action=restore` + `id` 退回某一份
  - `path` 不填就是本插件自己；填别的插件目录也能备份它

## 起不来的时候

面板点不到，就用命令行——只依赖 node 内置模块：

```bash
node scripts/plugin-backup.mjs list
node scripts/plugin-backup.mjs restore --latest
node scripts/plugin-backup.mjs restore --id 20261102-194017-247
```

回退完，宿主里的插件要重新加载一次才吃得到旧版本。

## 管不着的地方

- 用 `pwsh` 之类的 shell 直接改文件，guard 拦不到；改插件源码请走 `write` / `edit`，或者改完手动 `plugin_backup action=create`。
- 快照之后才添出来的文件，回退时不会删，只在结果里列出来。
- 库房里的东西以外，不复原任何插件数据（记忆、设置都在 `$DSH_HOME` 下，不归备份管）。
- 回退之后，插件要重新加载一次，旧版本才真正生效。
