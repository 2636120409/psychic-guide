/**
 * 自检：臭肺的分量。
 * 跑法：node scripts/selftest-scent.mjs
 */
import assert from 'node:assert/strict'
import * as scent from '../lib/scent.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const now = 100 * 24 * 60 * 60 * 1000

check('没条目算一分', () => {
  assert.equal(scent.entryWeight('long', null), 1)
  assert.equal(scent.entryWeight('short', undefined), 1)
})

check('带情绪的按分数抬：1 + 分 × 1.5', () => {
  assert.equal(scent.entryWeight('long', { emotion: { name: '喜', score: 0 } }), 1)
  assert.equal(scent.entryWeight('long', { emotion: { name: '喜', score: 1 } }), 2.5)
  assert.equal(scent.entryWeight('long', { emotion: { name: '喜', score: 0.4 } }), 1.6)
})

check('没情绪的按来路：情绪账 2.5、日常 1.5、其余 1', () => {
  assert.equal(scent.entryWeight('long', { kind: 'emotion' }), 2.5)
  assert.equal(scent.entryWeight('long', { kind: 'daily' }), 1.5)
  assert.equal(scent.entryWeight('long', { kind: 'manual' }), 1)
})

check('一星期折一半', () => {
  const base = scent.decayedWeight('long', { kind: 'daily', at: now - scent.WEIGHT_HALF_LIFE_MS }, now)
  assert.equal(Number(base.toFixed(3)), 0.75)
})

check('刚写的几乎不打折', () => {
  const base = scent.decayedWeight('long', { kind: 'daily', at: now }, now)
  assert.equal(base, 1.5)
})

check('没写时刻就当现在', () => {
  assert.equal(scent.decayedWeight('long', { kind: 'daily' }, now), 1.5)
})

check('分数越界也收着', () => {
  assert.equal(scent.entryWeight('long', { emotion: { name: '喜', score: 9 } }), 2.5)
  assert.equal(scent.entryWeight('long', { emotion: { name: '喜', score: -3 } }), 1)
})

console.log(`\n共 ${count} 项，全过。`)
