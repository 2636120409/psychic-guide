/**
 * 自检：一句人话。
 * 跑法：node scripts/selftest-errors.mjs
 */
import assert from 'node:assert/strict'
import { describe } from '../lib/errors.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('Error 只取 message', () => {
  assert.equal(describe(new Error('炸了')), '炸了')
})

check('带名字与代码的对象', () => {
  assert.equal(describe({ name: 'FsError', code: 'ENOENT', message: '找不到' }), 'FsError: 找不到 [ENOENT]')
})

check('普通对象转成短 JSON', () => {
  assert.equal(describe({ a: 1 }), '{"a":1}')
})

check('字符串与数字', () => {
  assert.equal(describe('字'), '字')
  assert.equal(describe(42), '42')
  assert.equal(describe(null), 'null')
})

check('循环引用不崩', () => {
  const loop = {}
  loop.self = loop
  assert.ok(typeof describe(loop) === 'string')
})

console.log(`\n共 ${count} 项，全过。`)
