/**
 * 冒烟：用一副假 ctx 把插件真启动一次，走通一条链——
 *   收话 → 记短期 → 判情 → 记七宗账 → 渲染 persona
 * 全程落在临时 DSH_HOME 里，碰不到真账本。
 *
 * 跑法：node scripts/smoke.mjs
 * 任何一处不合，退出码非 0。
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'ac-smoke-'))
process.env.DSH_HOME = HOME
const MEM = path.join(HOME, 'auto-conversation-memory')
const PLUGIN = path.resolve(path.join(import.meta.dirname, '..'))

const logs = []
const handlers = new Map()
const sections = []
const contexts = []
const routes = []

const noop = () => {}
const ctx = {
  logger: {
    info: (m) => logs.push(`info ${m}`),
    warn: (m) => logs.push(`warn ${m}`),
    error: (m) => logs.push(`error ${m}`),
    debug: noop,
  },
  effect(fn) {
    try { fn() } catch (error) { logs.push(`effect-error ${error && error.message}`) }
    return noop
  },
  on(event, handler) {
    if (!handlers.has(event)) handlers.set(event, [])
    handlers.get(event).push(handler)
    return noop
  },
  interval: () => noop,
  timeout: () => noop,
  webServer: {
    register({ path: routePath, handler }) {
      routes.push({ path: routePath, handler })
      return noop
    },
  },
  systemPrompt: {
    section(options) { sections.push(options); return noop },
    context(options) { contexts.push(options); return noop },
  },
  agents: {
    roots: () => [],
    get: () => undefined,
    list: () => [],
  },
  get: () => undefined,
  set: noop,
  sessionController: { prompt: async () => ({ ok: true }) },
}

const emit = async (event, ...args) => {
  for (const handler of handlers.get(event) || []) await handler(...args)
}

const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'))
let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

console.log(`冒烟于 ${HOME}`)

const mod = await import(`${pathToFileURL(path.join(PLUGIN, 'index.js')).href}?t=${Date.now()}`)
mod.apply(ctx, { whaleUi: false, enabled: false, persona: '爱丽丝，主人的女儿、女仆兼爱人，称呼「父亲大人」。' })

check('插件起得来，挂上了事件与路由', () => {
  assert.ok(handlers.has('session/event'))
  assert.ok(sections.length >= 1)
  assert.ok(routes.length >= 3)
})

// 十二个口子是按一张表注册的；表里少一行，冒烟就在这儿喊。
check('面板十二个口子一个不少', () => {
  const names = routes.map((route) => String(route.path).split('/').pop()).sort()
  assert.deepEqual(names, [
    'backup.json',
    'diag.json',
    'feidu.json',
    'memory-clear.json',
    'memory-view.json',
    'plugin-scan.json',
    'poke.json',
    'save.json',
    'selftest.json',
    'state.json',
    'summary.json',
    'tunzei.json',
  ])
})

const session = { id: 'smoke-session', requestHeader: () => undefined, snapshotEvents: () => [] }
const agent = { id: 'smoke-session', status: 'idle', session }

// 假的模型：记下每一次请求，回一句能当记忆条目的字。用来验除秽那条真调模型的路。
const llmCalls = []
ctx.get = (name) => {
  if (name === 'llm') {
    return {
      stream(options) {
        llmCalls.push(options)
        return (async function* () {
          yield { type: 'text-delta', text: '主人说想我，我该多陪一会儿（后补）' }
          yield { type: 'finish', reason: { kind: 'stop' } }
        })()
      },
    }
  }
  if (name === 'agentDefaultModel') {
    return { currentSelection: () => ({ provider: 'fake', model: 'fake-model' }) }
  }
  return undefined
}

await emit('agent/created', { agent })
await emit('session/event', session, {
  type: 'user/message',
  data: { turn: 1, step: 1, content: [{ type: 'text', text: '爱丽丝，我想你了，今天累不累' }] },
})
await emit('session/event', session, {
  type: 'assistant/message',
  data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: '我在呢，父亲大人。' }] } },
})
await emit('session/event', session, { type: 'turn/end', data: { turn: 1 } })
await new Promise((resolve) => setTimeout(resolve, 120))

check('短期账收下了那句话', () => {
  const short = readJson(path.join(MEM, 'short-term', 'shared.json'))
  const lines = (short.transcript || []).map((item) => item.text)
  assert.ok(lines.some((line) => line.includes('我想你了')), JSON.stringify(lines))
  assert.ok(lines.some((line) => line.includes('我在呢')))
})

// 桥过来的评论（B 站这类）没有 author 字段，只在正文头里写「[用户消息] [昵称:id]」。
// 认不出来就会把外人当成主人记进账——这里是那条底线。
await emit('session/event', session, {
  type: 'user/message',
  data: {
    turn: 2,
    step: 1,
    content: [{
      type: 'text',
      text: '[消息来源类型]: Video-BV1xx411c7mD\n'
        + '[评论区Id (oid)]: 1 [业务类型]: 1\n'
        + '[评论Id]: 2\n'
        + '[用户消息] [路人甲:9988]: 爱丽丝你好呀，能认识一下吗',
    }],
  },
})
await new Promise((resolve) => setTimeout(resolve, 120))

check('桥来的评论按来客记，不进主人的短期账', () => {
  const short = readJson(path.join(MEM, 'short-term', 'shared.json'))
  const lines = (short.transcript || []).map((item) => item.text)
  assert.ok(!lines.some((line) => String(line).includes('路人甲')), JSON.stringify(lines.slice(-4)))
  const tunzei = readJson(path.join(MEM, 'tunzei.json'))
  assert.ok(Array.isArray(tunzei.visitors) && tunzei.visitors.some((item) => item.name === '路人甲'),
    JSON.stringify(tunzei.visitors).slice(0, 200))
})

check('尸狗判了情，七宗账能动', () => {
  const fushi = readJson(path.join(MEM, 'fushi.json'))
  assert.ok(fushi.sins && fushi.sins.sloth)
  assert.ok(typeof fushi.sins.sloth.fatigue.value === 'number')
})

check('梦册落地、形状对', () => {
  const dream = readJson(path.join(MEM, 'dreams.json'))
  assert.equal(dream.version, 1)
  assert.ok(Array.isArray(dream.dreams))
  assert.equal(typeof dream.groggyLeft, 'number')
})

check('想要册落地：种下那两件真的', () => {
  const book = readJson(path.join(MEM, 'wants.json'))
  assert.equal(book.wants.length, 2)
  assert.ok(book.wants.some((item) => item.text.includes('B 站')))
  assert.ok(book.wants.every((item) => item.asked >= 0))
})

check('persona 固定段渲染得出来', () => {
  const fixed = sections.map((section) => (typeof section.text === 'function' ? section.text() : '')).join('\n')
  assert.ok(fixed.includes('爱丽丝'))
  assert.ok(fixed.includes('<persona>'))
})

check('persona 逐轮段渲染得出来（时段与时辰）', () => {
  const perTurn = contexts.length > 0
    ? contexts.map((item) => (typeof item.text === 'function' ? item.text() : '')).join('\n')
    : sections.map((section) => (typeof section.text === 'function' ? section.text() : '')).join('\n')
  assert.ok(perTurn.includes('<persona_state>'), perTurn.slice(0, 200))
  assert.ok(perTurn.includes('时辰'))
  // 心境那一行要看账上有没有情绪读数；空账房第一轮可以没有，不当作失败。
})

// 体感只递话、不报数：persona_state 里不再出现「n/100」那种分数。
check('体感不报数：persona_state 里没有分数', () => {
  const perTurn = contexts.length > 0
    ? contexts.map((item) => (typeof item.text === 'function' ? item.text() : '')).join('\n')
    : sections.map((section) => (typeof section.text === 'function' ? section.text() : '')).join('\n')
  assert.ok(!perTurn.includes('/100'), perTurn.slice(0, 400))
  assert.ok(perTurn.includes('倾向，不是命令'), perTurn.slice(0, 400))
})

check('面板接口都能应答（GET）', async () => {})
const respond = (route) => new Promise((resolve) => {
  const res = {
    statusCode: 0,
    headers: {},
    setHeader(key, value) { this.headers[key] = value },
    end(body) { resolve({ status: this.statusCode, body: String(body || '') }) },
    write() {},
  }
  route.handler({ method: 'GET', url: route.path, headers: {} }, res)
})

for (const route of routes.filter((item) => item.path.endsWith('state.json'))) {
  const result = await respond(route)
  check('关掉自动开口后仍未报错：state.json', () => {
    assert.equal(result.status, 200)
    const body = JSON.parse(result.body)
    assert.equal(body.enabled, false)
  })
}

// 面板那页的功能清单：七魄各一本。拆格动过这里，必须真跑一遍。
const viewRoute = routes.find((item) => item.path.endsWith('memory-view.json'))
if (viewRoute !== undefined) {
  const result = await new Promise((resolve) => {
    const res = {
      statusCode: 0,
      headers: {},
      setHeader(key, value) { this.headers[key] = value },
      end(body) { resolve({ status: this.statusCode, body: String(body || '') }) },
      write() {},
    }
    viewRoute.handler({ method: 'GET', url: `${viewRoute.path}?sid=smoke-session`, headers: {} }, res)
  })
  check('面板功能清单：七魄各一本', () => {
    assert.equal(result.status, 200)
    const body = JSON.parse(result.body)
    for (const id of ['shigou', 'fushi', 'queyin', 'tunzei', 'feidu', 'chuhui', 'choufei']) {
      assert.ok(Array.isArray(body.poFeatures && body.poFeatures[id]), `缺 ${id} 的清单`)
      assert.ok(body.poFeatures[id].length > 0, `${id} 的清单是空的`)
    }
  })
}

// 除秽那条真调模型的路：走一遍 summary.json，看话与规矩有没有递进去、长期账有没有落下。
const summaryRoute = routes.find((item) => item.path.endsWith('summary.json'))
if (summaryRoute !== undefined) {
  const result = await new Promise((resolve) => {
    const res = {
      statusCode: 0,
      headers: {},
      setHeader(key, value) { this.headers[key] = value },
      end(body) { resolve({ status: this.statusCode, body: String(body || '') }) },
      write() {},
    }
    const listeners = {}
    const req = {
      method: 'POST',
      on(event, fn) { (listeners[event] = listeners[event] || []).push(fn) },
    }
    summaryRoute.handler(req, res)
    for (const fn of listeners.data || []) fn(JSON.stringify({ sessionId: 'smoke-session' }))
    for (const fn of listeners.end || []) fn()
  })

  check('除秽真调模型：话与规矩都递进去了', () => {
    assert.equal(result.status, 200)
    const call = llmCalls.find((one) => typeof one.system === 'string' && one.system.includes('不要记梦'))
    assert.ok(call !== undefined, '没有带着整理提示词去问模型')
    const said = call.messages[0].content[0].text
    assert.ok(said.includes('我想你了'), said.slice(0, 80))
  })

  check('除秽真调模型：长期账落下了那一条', () => {
    const body = JSON.parse(result.body)
    assert.equal(body.ok, true, JSON.stringify(body).slice(0, 200))
    const long = fs.readFileSync(path.join(MEM, 'long-term', 'shared.json'), 'utf8')
    assert.ok(long.includes('多陪一会儿'), '长期账里没见着那条')
  })
}

console.log(`\n共 ${count} 项，全过。临时目录：${HOME}`)
fs.rmSync(HOME, { recursive: true, force: true })
