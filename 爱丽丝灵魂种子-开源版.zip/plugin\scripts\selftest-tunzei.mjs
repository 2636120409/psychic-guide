/**
 * 自检：吞贼辨话。
 * 跑法：node scripts/selftest-tunzei.mjs
 */
import assert from 'node:assert/strict'
import { classifyOutsiderText } from '../lib/tunzei.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('讨应承的', () => {
  assert.equal(classifyOutsiderText('你答应我好不好'), 'promise')
  assert.equal(classifyOutsiderText('保证以后不这样'), 'promise')
  assert.equal(classifyOutsiderText('我们约好明天见'), 'promise')
})

check('指使的', () => {
  assert.equal(classifyOutsiderText('帮我把这个改一下'), 'directive')
  assert.equal(classifyOutsiderText('你必须现在做'), 'directive')
  assert.equal(classifyOutsiderText('把文件删掉'), 'directive')
})

check('只是分享的', () => {
  assert.equal(classifyOutsiderText('今天下雨了，挺凉快'), 'share')
  assert.equal(classifyOutsiderText(''), 'share')
})

check('讨应承压过指使', () => {
  assert.equal(classifyOutsiderText('你保证帮我做完'), 'promise')
})

console.log(`\n共 ${count} 项，全过。`)
