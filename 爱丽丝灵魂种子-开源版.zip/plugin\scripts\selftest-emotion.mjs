/**
 * 自检：情绪的衰减与剧变。
 * 跑法：node scripts/selftest-emotion.mjs
 */
import assert from 'node:assert/strict'
import * as emo from '../lib/emotion-decay.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const H = 60 * 60 * 1000
const now = 100 * H

check('一层衰减：一个半衰期折一半', () => {
  const got = emo.decayedEmotions({ at: now - 2 * H, emotions: [{ id: 'xi', name: '喜', score: 0.8 }] }, now)
  assert.equal(got[0].score, 0.4)
})

check('爱散得比怒慢', () => {
  const rage = emo.decayedEmotions({ at: now - 4 * H, emotions: [{ id: 'nu', name: '怒', score: 0.8 }] }, now)
  const love = emo.decayedEmotions({ at: now - 4 * H, emotions: [{ id: 'ai', name: '爱', score: 0.8 }] }, now)
  assert.ok(love[0].score > rage[0].score, `${love[0].score} vs ${rage[0].score}`)
})

check('淡到底就不留了', () => {
  const got = emo.decayedEmotions({ at: now - 40 * H, emotions: [{ id: 'nu', name: '怒', score: 0.5 }] }, now)
  assert.equal(got.length, 0)
})

check('decayedAt 之后的钟才算', () => {
  const half = emo.decayedEmotions({ at: now - 2 * H, decayedAt: now - 2 * H, emotions: [{ id: 'xi', name: '喜', score: 1 }] }, now)
  assert.equal(half[0].score, 0.5)
})

check('按分数排，高的在前', () => {
  const got = emo.decayedEmotions({
    at: now - H,
    emotions: [{ id: 'xi', name: '喜', score: 0.2 }, { id: 'ai', name: '爱', score: 0.9 }],
  }, now)
  assert.equal(got[0].id, 'ai')
})

check('够重的一跳才算剧变', () => {
  const heavy = { emotions: [{ id: 'nu', name: '怒', score: 0.9 }] }
  const light = { emotions: [{ id: 'nu', name: '怒', score: 0.2 }] }
  assert.ok(emo.emotionSpikeOf(heavy, []) !== null)
  assert.equal(emo.emotionSpikeOf(light, []), null)
})

check('高出基线也算', () => {
  const record = { emotions: [{ id: 'xi', name: '喜', score: 0.7 }] }
  const baseline = [{ id: 'xi', value: 5 }]
  const spike = emo.emotionSpikeOf(record, baseline)
  assert.ok(spike !== null)
  assert.equal(spike.jump, 0.65)
})

check('空记录不算', () => {
  assert.equal(emo.emotionSpikeOf(null, []), null)
  assert.equal(emo.emotionSpikeOf({ emotions: [] }, []), null)
})

console.log(`\n共 ${count} 项，全过。`)
