/**
 * 问一句，翻文件：拿话去比文件索引，回前几条路径和摘要。
 *
 * 跑法：node scripts/embed-files-query.mjs "上次那个备份脚本在哪"
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const INDEX_FILE = path.join(HOME, 'auto-conversation-memory', 'file-index.json')
const PYTHON = process.env.DSH_PYTHON || 'python'
const SCRIPT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..', '..', 'tools', 'embed', 'embed_texts.py')
const TOP = 5
const HIT_ABOVE = 0.42

const question = String(process.argv.slice(2).join(' ') || '').trim().slice(0, 200)
if (question.length === 0) {
  console.log('embed-files-query: 问一句')
  process.exit(0)
}

let book
try {
  book = JSON.parse(fs.readFileSync(INDEX_FILE, 'utf8'))
} catch {
  console.log('embed-files-query: 还没有索引，先跑 embed-files')
  process.exit(0)
}
const files = Array.isArray(book.files) ? book.files : []
if (files.length === 0) {
  console.log('embed-files-query: 索引是空的')
  process.exit(0)
}

const result = spawnSync(PYTHON, [SCRIPT], {
  input: JSON.stringify([question]),
  encoding: 'utf8',
  timeout: 120000,
  maxBuffer: 16 * 1024 * 1024,
})
if ((result.error !== undefined && result.error !== null) || result.status !== 0) {
  console.log('embed-files-query: 算不出向量')
  process.exit(0)
}
const query = JSON.parse(result.stdout)[0] || []

const scored = []
for (const file of files) {
  const vector = Array.isArray(file.vector) ? file.vector : []
  if (vector.length === 0) continue
  let dot = 0
  for (let index = 0; index < query.length; index += 1) dot += query[index] * (vector[index] || 0)
  if (dot < HIT_ABOVE) continue
  scored.push({ score: dot, rel: String(file.rel || ''), title: String(file.title || ''), snippet: String(file.snippet || '') })
}
scored.sort((a, b) => b.score - a.score)
for (const one of scored.slice(0, TOP)) {
  console.log(`${one.score.toFixed(3)}  ${one.rel}  —— ${one.title}：${one.snippet.slice(0, 60)}`)
}
if (scored.length === 0) console.log('embed-files-query: 没翻到像的')
