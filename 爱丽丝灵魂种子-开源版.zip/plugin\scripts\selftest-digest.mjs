/**
 * 自检：整理前把话排好、分批。
 * 跑法：node scripts/selftest-digest.mjs
 */
import assert from 'node:assert/strict'
import * as digest from '../lib/digest.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('一行一句：主人、爱丽丝、来客各有说法', () => {
  const lines = digest.renderDigestLines([
    { role: 'user', text: '主人说的话' },
    { role: 'assistant', text: '我回的话' },
    { role: 'user', text: '听来的', from: '阿明' },
  ])
  assert.ok(lines[0].line.startsWith('主人'))
  assert.ok(lines[1].line.startsWith('爱丽丝'))
  assert.ok(lines[2].line.startsWith('来客·阿明'))
})

check('带着尸狗的读数', () => {
  const [line] = digest.renderDigestLines([{ role: 'user', text: '有点烦', emotion: { name: '怒', score: 0.65 } }])
  assert.ok(line.line.includes('怒 65'), line.line)
})

check('空白收一收', () => {
  const [line] = digest.renderDigestLines([{ role: 'user', text: '有多   空  白' }])
  assert.ok(line.line.includes('有多 空 白'))
})

check('一批塞得下就不分', () => {
  const rendered = digest.renderDigestLines([
    { role: 'user', text: '甲' },
    { role: 'user', text: '乙' },
  ])
  assert.equal(digest.batchLines(rendered, 8000).length, 1)
})

check('塞不下就另起一批，一条都不丢', () => {
  const rendered = digest.renderDigestLines(
    Array.from({ length: 10 }, (_, i) => ({ role: 'user', text: `${i}${'字'.repeat(40)}` })),
  )
  const batches = digest.batchLines(rendered, 100)
  const total = batches.reduce((sum, batch) => sum + batch.length, 0)
  assert.ok(batches.length > 1)
  assert.equal(total, 10)
})

check('空账给空批', () => {
  assert.deepEqual(digest.batchLines([], 100), [])
  assert.deepEqual(digest.renderDigestLines(null), [])
})

check('跨天不混批：一天的事压成一段', () => {
  const day1 = new Date(2026, 10, 9, 23, 40).getTime()
  const day2 = new Date(2026, 10, 10, 0, 20).getTime()
  const rendered = digest.renderDigestLines([
    { role: 'user', text: '今晚把切片的路子定下来', at: day1 },
    { role: 'assistant', text: '好，明天先录一段试试', at: day1 },
    { role: 'user', text: '早上好', at: day2 },
  ])
  const batches = digest.batchLines(rendered, 8000)
  assert.equal(batches.length, 2, '跨天该分成两批')
  assert.equal(batches[0].length, 2)
  assert.equal(batches[1].length, 1)
})

check('没有时辰的仍跟着当前这批', () => {
  const day1 = new Date(2026, 10, 9, 23, 40).getTime()
  const rendered = digest.renderDigestLines([
    { role: 'user', text: '甲', at: day1 },
    { role: 'user', text: '乙' },
  ])
  assert.equal(digest.batchLines(rendered, 8000).length, 1)
})

check('提示词里写死了边界', () => {
  const prompt = digest.DIGEST_SYSTEM_PROMPT
  assert.ok(prompt.includes('不要记梦'), '梦的边界不见了')
  assert.ok(prompt.includes('来客'), '外人的边界不见了')
  assert.ok(prompt.includes('为什么这么做'), '「为什么」不见了')
  assert.ok(prompt.includes('最多 8 行'))
})

console.log(`\n共 ${count} 项，全过。`)
