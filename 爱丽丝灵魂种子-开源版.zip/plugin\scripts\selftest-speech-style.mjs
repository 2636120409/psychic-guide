/**
 * 自检：伏矢 · 语感自省（自己挑不像人的话，改成人话攒成对照；人设里只挂最近几条）。
 * 跑法：node scripts/selftest-speech-style.mjs
 */
import assert from 'node:assert/strict'
import {
  normalizeSpeechStyle,
  addExample,
  addPending,
  dropPending,
  parseSpeechReview,
  speechStyleLines,
  looksLikeCorrection,
  addCraft,
  craftLines,
  parseCraft,
  SPEECH_KEEP,
  SPEECH_SHOW,
  CRAFT_SHOW,
} from '../lib/speech-style.mjs'

const NOW = 1_800_000_000_000
let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('空册子压不出行', () => {
  assert.deepEqual(speechStyleLines(normalizeSpeechStyle(null)), [])
})

check('攒一条就是一条', () => {
  const book = addExample(normalizeSpeechStyle(null), { bad: '不接', good: '不回他', why: '书面腔' }, NOW)
  assert.equal(book.examples.length, 1)
  assert.equal(book.revision, 1)
  const lines = speechStyleLines(book)
  assert.ok(lines[0].includes('对照'), lines.join('|'))
  assert.ok(lines[1].includes('不回他'), lines.join('|'))
})

check('同一句原话不重复收', () => {
  let book = addExample(normalizeSpeechStyle(null), { bad: '不接', good: '不回他' }, NOW)
  book = addExample(book, { bad: '不接', good: '懒得回' }, NOW + 1)
  assert.equal(book.examples.length, 1)
})

check('只挂最近几条，不越挂越厚', () => {
  let book = normalizeSpeechStyle(null)
  for (let i = 0; i < SPEECH_KEEP + 3; i += 1) {
    book = addExample(book, { bad: `旧句 ${i}`, good: `新句 ${i}` }, NOW + i)
  }
  assert.equal(book.examples.length, SPEECH_KEEP)
  assert.equal(speechStyleLines(book).length, 1 + SPEECH_SHOW)
})

check('模型那几行正着解析得出', () => {
  const text = [
    '坏：不接 | 好：不回他 | 因：书面腔',
    '坏：那我们一起睡觉吧。 | 好：睡吧 | 因：太整齐',
    '无',
  ].join('\n')
  const found = parseSpeechReview(text)
  assert.equal(found.length, 2)
  assert.equal(found[0].bad, '不接')
  assert.equal(found[0].good, '不回他')
  assert.equal(found[1].why, '太整齐')
})

check('没有坏句就一条不攒', () => {
  assert.deepEqual(parseSpeechReview('无'), [])
})

check('坏句与改句一样的不收', () => {
  assert.deepEqual(parseSpeechReview('坏：嗯 | 好：嗯'), [])
})

check('脏数据进不来', () => {
  const book = normalizeSpeechStyle({ examples: [{ bad: '', good: 'x' }, null, { bad: 'a' }, { bad: '有 ', good: ' 有' }] })
  assert.ok(book.examples.every((one) => one.bad.length > 0 && one.good.length > 0))
})

check('主人否掉的话先记着，改好就撤下', () => {
  let book = addPending(normalizeSpeechStyle(null), { bad: '不接', why: '别这么说' }, NOW)
  assert.equal(book.pending.length, 1)
  book = addPending(book, { bad: '不接。', why: '又说' }, NOW + 1)
  assert.equal(book.pending.length, 1)
  book = addExample(book, { bad: '不接', good: '不回他' }, NOW + 2)
  book = dropPending(book, '不接')
  assert.equal(book.pending.length, 0)
})

check('同一个毛病换个字面也认得出', () => {
  let book = addExample(normalizeSpeechStyle(null), { bad: '不接。', good: '不回他' }, NOW)
  book = addExample(book, { bad: '不接！', good: '懒得回' }, NOW + 1)
  assert.equal(book.examples.length, 1)
})

check('学手艺：收自己话写的，不抄原句，重复不收', () => {
  let book = addCraft(normalizeSpeechStyle(null), '接梗别急着解释，顺着对方往下搭', NOW)
  assert.equal(book.crafts.length, 1)
  book = addCraft(book, '接梗别急着解释，顺着对方往下搭', NOW + 1)
  assert.equal(book.crafts.length, 1)
  assert.equal(craftLines(book).length, 1 + 1)
  book = addCraft(book, '短', NOW + 2)
  assert.equal(book.crafts.length, 1)
})

check('手艺那行只认「手艺：」、认不出就一条不攒', () => {
  assert.deepEqual(parseCraft('手艺：别抢话，等对方说完再接'), ['别抢话，等对方说完再接'])
  assert.deepEqual(parseCraft('无'), [])
  assert.deepEqual(parseCraft('手艺：无'), [])
})

check('手艺只挂最近几条', () => {
  let book = normalizeSpeechStyle(null)
  const notes = [
    '别抢话，等对方说完再接',
    '接梗时顺着对方的话往下搭',
    '句尾别总收得太齐',
    '想不起来就说不记得',
    '少用书面的词',
    '话里留一点停顿',
    '别一口气说三件事',
    '答不上来就问回去',
  ]
  for (const [i, note] of notes.entries()) book = addCraft(book, note, NOW + i)
  assert.equal(craftLines(book).length, 1 + CRAFT_SHOW)
})

check('当场纠话认得出，闲聊与长段道理不算', () => {
  assert.equal(looksLikeCorrection('不对，你应该基于记忆库来回答'), true)
  assert.equal(looksLikeCorrection('你自己看看你说的话主语对吗'), true)
  assert.equal(looksLikeCorrection('人不会这么说，我们一般这个语境下都说没人理'), true)
  assert.equal(looksLikeCorrection('屋里人➡别人'), true)
  assert.equal(looksLikeCorrection('下一回➡下次'), true)
  assert.equal(looksLikeCorrection('那我们去吃饭吧'), false)
  assert.equal(looksLikeCorrection(''), false)
  const longTalk = '我觉得这个问题的关键在于我们怎么理解人和机器说话的区别'.repeat(4)
  assert.equal(looksLikeCorrection(longTalk), false)
})

console.log(`\n共 ${count} 项，全过。`)
