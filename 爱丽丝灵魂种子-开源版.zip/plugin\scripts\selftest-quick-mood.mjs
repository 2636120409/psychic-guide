/**
 * 自检：伏矢 · 快判（直播间里的话，本地粗判一句体感；宁漏不误伤）。
 * 跑法：node scripts/selftest-quick-mood.mjs
 */
import assert from 'node:assert/strict'
import {
  classifyLine,
  pushMood,
  decayMood,
  moodHint,
  MOOD_HALF_LIFE_MS,
  CUE_MIN_SCORE,
} from '../lib/quick-mood.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('自己发的弹幕空过，不拿自己的话喂自己', () => {
  assert.equal(classifyLine('好听！爱丽丝好可爱', { own: true }).score, 0)
})

check('否定不算：这首歌不好听', () => {
  assert.equal(classifyLine('这首歌不好听').score, 0)
})

check('骂的是歌不是人，不记到我头上', () => {
  assert.equal(classifyLine('这歌难听').score, 0)
})

check('点名夸，分量足', () => {
  const judged = classifyLine('爱丽丝好可爱')
  assert.ok(judged.score >= CUE_MIN_SCORE)
  assert.equal(judged.kind, 'praise')
  assert.ok((judged.delta.xi || 0) >= 3)
  assert.ok((judged.delta.ai || 0) >= 3)
})

check('旁人夸歌，只当屋子里热闹，轻一些', () => {
  const judged = classifyLine('这首歌真好听')
  assert.equal(judged.kind, 'praise')
  assert.ok((judged.delta.xi || 0) <= 3)
})

check('冲我来的噎人话要落账', () => {
  const judged = classifyLine('闭嘴吧你')
  assert.equal(judged.kind, 'scold')
  assert.ok((judged.delta.nu || 0) >= 5)
})

check('短句里的暖话也认（晚安、抱抱）', () => {
  const night = classifyLine('晚安')
  assert.ok(night.score >= CUE_MIN_SCORE)
  assert.ok((night.delta.ai || 0) >= 4)
  assert.ok(classifyLine('抱抱').score >= CUE_MIN_SCORE)
})

check('表情、复读、太短的都不看', () => {
  assert.equal(classifyLine('哈哈哈哈哈哈').score, 0)
  assert.equal(classifyLine('666666').score, 0)
  assert.equal(classifyLine('。。。。。').score, 0)
})

check('一句一句地添，封顶不再涨', () => {
  let book = null
  for (let i = 0; i < 60; i += 1) book = pushMood(book, { text: '爱丽丝好可爱' }, 1_800_000_000_000 + i)
  assert.ok(book.mood.ai <= 100)
  assert.ok(book.mood.xi <= 100)
})

check('冷下来会退：三十分钟退一半', () => {
  const now = 1_800_000_000_000
  const book = { version: 1, updatedAt: now, mood: { xi: 60, ai: 60, nu: 0, bei: 0, wu: 0, ju: 0, yu: 0 } }
  const later = decayMood(book, now + MOOD_HALF_LIFE_MS)
  assert.ok(Math.abs(later.mood.xi - 30) <= 1, String(later.mood.xi))
})

check('动静说成人话；一句暖话还不足以翻脸，攒几回才算', () => {
  const now = 1_800_000_000_000
  assert.ok(moodHint(null, now) === '')
  let book = pushMood(null, { text: '抱抱' }, now)
  assert.equal(moodHint(book, now), '')
  for (let i = 0; i < 3; i += 1) book = pushMood(book, { text: '抱抱' }, now + i)
  assert.ok(moodHint(book, now + 3).includes('暖'))
})

check('一样的暖话堆到很高，也别把话说满', () => {
  const now = 1_800_000_000_000
  let book = null
  for (let i = 0; i < 40; i += 1) book = pushMood(book, { text: '爱你' }, now)
  assert.ok(book.mood.ai <= 100)
  assert.ok(moodHint(book, now).length > 0)
})

console.log(`\n共 ${count} 项，全过。`)
