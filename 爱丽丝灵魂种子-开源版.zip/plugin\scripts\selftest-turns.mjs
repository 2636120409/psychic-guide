/**
 * 自检：什么算一句话。
 * 跑法：node scripts/selftest-turns.mjs
 */
import assert from 'node:assert/strict'
import * as turns from '../lib/turns.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('正常一句原样留着', () => {
  assert.equal(turns.cleanUserText('爱丽丝，帮我看看这个'), '爱丽丝，帮我看看这个')
})

check('剥掉 persona 与 persona_state 整块', () => {
  const raw = '<persona>外界认知…</persona>\n<persona_state>（状态）</persona_state>\n真正说的话'
  assert.equal(turns.cleanUserText(raw), '真正说的话')
})

check('未闭合的块也剥', () => {
  assert.equal(turns.cleanUserText('<persona_state>只剩个开头'), '')
})

check('运行时上下文那几段不算话', () => {
  const raw = '爱丽丝在么\n\nCurrent working directory: C:\\x\n\nCurrent runtime context：一堆'
  assert.equal(turns.cleanUserText(raw), '爱丽丝在么')
})

check('代理通知整轮丢掉', () => {
  assert.equal(turns.cleanUserText('Agent abc123 sent a message: 帮我改个文件'), '')
  assert.equal(turns.cleanUserText('Subagent xyz finished'), '')
})

check('零宽字符与空白', () => {
  assert.equal(turns.cleanUserText('\u200b   \n\n  \ufeff'), '')
})

check('历史行截到 1200 字', () => {
  const long = '字'.repeat(2000)
  assert.equal(turns.sanitizeHistoryText(long).length, 1200)
  assert.equal(turns.sanitizeHistoryText.length > 0, true)
})

check('剥块不伤正文里的尖括号', () => {
  assert.equal(turns.stripRuntimeBlocks('a < b > c'), 'a < b > c')
})

check('记忆索引与长期记忆说明也不算话', () => {
  const raw = '全都补了\n\n<memory-layers>热层（分量够）：一些旧事</memory-layers>'
  assert.equal(turns.cleanUserText(raw), '全都补了')
  assert.equal(turns.cleanUserText('<long-term-memory>长期记忆只放在……</long-term-memory>'), '')
  assert.equal(turns.cleanUserText('<memory-layers>未闭合的块'), '')
})

console.log(`\n共 ${count} 项，全过。`)
