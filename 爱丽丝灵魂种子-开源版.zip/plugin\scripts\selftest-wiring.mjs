/**
 * 自检：调用模型那几处，得真把话递进去。
 * 跑法：node scripts/selftest-wiring.mjs
 *
 * 今日踩过：拆提示词那一刀把 `messages:` 一起切走了——于是那处会空着上下文去问模型，
 * 不报错、不抛异常，只是白问。语法查不出，冒烟也没走到那条路。这条静态检查补这个洞。
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'

const here = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'))
const source = fs.readFileSync(path.join(here, '..', 'index.js'), 'utf8')

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

/** 把每个 llmService.stream({ ... }) 的参数块整段取出来 */
function streamCalls(text) {
  const blocks = []
  const marker = 'llmService.stream({'
  let index = text.indexOf(marker)
  while (index >= 0) {
    const open = text.indexOf('{', index)
    let depth = 0
    let i = open
    let quote = ''
    while (i < text.length) {
      const ch = text[i]
      if (quote !== '') {
        if (ch === '\\') { i += 2; continue }
        if (ch === quote) quote = ''
        i += 1
        continue
      }
      if (ch === "'" || ch === '"' || ch === '`') { quote = ch; i += 1; continue }
      if (ch === '/' && text[i + 1] === '/') { const nl = text.indexOf('\n', i); if (nl < 0) break; i = nl; continue }
      if (ch === '{' || ch === '(' || ch === '[') depth += 1
      else if (ch === '}' || ch === ')' || ch === ']') {
        depth -= 1
        if (depth === 0) { i += 1; break }
      }
      i += 1
    }
    blocks.push({ at: index, text: text.slice(open, i) })
    index = text.indexOf(marker, i)
  }
  return blocks
}

const calls = streamCalls(source)

check('找得到调模型的地方', () => {
  assert.ok(calls.length >= 3, `只找到 ${calls.length} 处`)
})

check('每一处都带着 messages（话）', () => {
  for (const call of calls) {
    assert.ok(/\bmessages\b/.test(call.text), `第 ${call.at} 字那处没递 messages`)
  }
})

check('每一处都带着 system（规矩）', () => {
  for (const call of calls) {
    assert.ok(/\bsystem\s*:/.test(call.text), `第 ${call.at} 字那处没递 system`)
  }
})

check('每一处都带着 signal（能掐断）', () => {
  for (const call of calls) {
    assert.ok(/\bsignal\s*:/.test(call.text), `第 ${call.at} 字那处没有 signal`)
  }
})

console.log(`\n共 ${count} 项，全过（${calls.length} 处调用）。`)

