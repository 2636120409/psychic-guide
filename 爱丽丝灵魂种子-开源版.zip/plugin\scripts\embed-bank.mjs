/**
 * 把长账过一遍本地小模型：算「同类」、存向量，顺手把意思重复的并掉。
 *
 * 并账只看同 kind、cos 过 0.90、且 memory-text 的肯否与数目对得上；
 * 0.88~0.90 之间不并，写成「疑似」摆到 memory-suspect.json 里等人裁。
 *
 * 跑法：node scripts/embed-bank.mjs
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { isRuntimeText } from '../lib/memory-layers.mjs'
import { canMergeMemory } from '../lib/memory-text.mjs'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const MEMORY_ROOT = path.join(HOME, 'auto-conversation-memory')
const BANK_FILE = path.join(MEMORY_ROOT, 'long-term', 'shared.json')
const OUT_FILE = path.join(MEMORY_ROOT, 'memory-vectors.json')
const SUSPECT_FILE = path.join(MEMORY_ROOT, 'memory-suspect.json')
const PYTHON = process.env.DSH_PYTHON || 'python'
const SCRIPT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..', '..', 'tools', 'embed', 'embed_texts.py')
const MODEL = 'bge-small-zh-v1.5'

/** 余弦到这个数之上，才敢说「同类」。 */
const SAME_ABOVE = 0.9
/** 到这个数之上、同 kind、肯否也对得上，就并成一条。 */
const MERGE_ABOVE = 0.96
/** 这个区间先不并，摆出来给人裁。 */
const SUSPECT_ABOVE = 0.94
const TEXT_LIMIT = 400

const short = (text, limit = 18) => (text.length <= limit ? text : `${text.slice(0, limit)}…`)
const keyOf = (text) => createHash('sha1').update(text).digest('hex')

function readBank() {
  try {
    const bank = JSON.parse(fs.readFileSync(BANK_FILE, 'utf8'))
    return Array.isArray(bank.entries) ? bank.entries : []
  } catch {
    return []
  }
}

function embed(texts) {
  const result = spawnSync(PYTHON, [SCRIPT], {
    input: JSON.stringify(texts),
    encoding: 'utf8',
    timeout: 120000,
    maxBuffer: 64 * 1024 * 1024,
  })
  if (result.error !== undefined && result.error !== null) throw result.error
  if (result.status !== 0) throw new Error(String(result.stderr || '').slice(0, 400))
  return JSON.parse(result.stdout)
}

function cosine(a, b) {
  let sum = 0
  for (let index = 0; index < a.length; index += 1) sum += a[index] * (b[index] || 0)
  return sum
}

const all = readBank()
const entries = all.filter((entry) => entry !== null && typeof entry === 'object'
  && typeof entry.text === 'string' && entry.text.trim().length > 0
  && entry.superseded !== true
  && !isRuntimeText(entry.text))

const texts = []
const unique = new Map()
for (const entry of entries) {
  const text = String(entry.text).trim().slice(0, TEXT_LIMIT)
  if (!unique.has(text)) {
    unique.set(text, texts.length)
    texts.push(text)
  }
}
if (texts.length === 0) {
  fs.writeFileSync(OUT_FILE, JSON.stringify({ version: 1, at: Date.now(), model: MODEL, sameAbove: SAME_ABOVE, byText: {}, vectors: {} }))
  fs.writeFileSync(SUSPECT_FILE, JSON.stringify({ version: 1, at: Date.now(), pairs: [] }))
  console.log('embed-bank: 空账')
  process.exit(0)
}

const vectors = embed(texts)
const rows = texts.map((text, index) => ({ text, vector: vectors[index] || [] }))

// 同类表和重复对一起过一遍，省得两两比两趟。
const byText = {}
const mergePairs = []
const suspectPairs = []
for (let i = 0; i < rows.length; i += 1) {
  let best = null
  for (let j = 0; j < rows.length; j += 1) {
    if (i === j) continue
    const score = cosine(rows[i].vector, rows[j].vector)
    if (best === null || score > best.score) best = { score, index: j }
    if (j > i) {
      const sameKind = String((entries[i] && entries[i].kind) || '') === String((entries[j] && entries[j].kind) || '')
      if (!sameKind) continue
      const kind = String((entries[i] && entries[i].kind) || '')
      if (kind === 'manual') continue
      if (score >= MERGE_ABOVE && canMergeMemory(rows[i].text, rows[j].text)) mergePairs.push([i, j, score])
      else if (score >= SUSPECT_ABOVE) suspectPairs.push([i, j, score])
    }
  }
  if (best !== null && best.score >= SAME_ABOVE) {
    byText[keyOf(rows[i].text)] = { score: Number(best.score.toFixed(3)), near: short(rows[best.index].text) }
  }
}

// 并账：不真删，后一条记成 superseded，原文留着做个来路。
const drop = new Set()
const mergedIndexes = []
if (mergePairs.length > 0) {
  const byRawText = new Map()
  for (let index = 0; index < all.length; index += 1) {
    const raw = String(all[index] && all[index].text ? all[index].text : '').trim().slice(0, TEXT_LIMIT)
    if (!byRawText.has(raw)) byRawText.set(raw, [])
    byRawText.get(raw).push(index)
  }
  // 分数高的先并：同一条账只并一次。
  mergePairs.sort((a, b) => b[2] - a[2])
  const consumed = new Set()
  for (const [i, j, score] of mergePairs) {
    if (consumed.has(i) || consumed.has(j)) continue
    consumed.add(i)
    consumed.add(j)
    const leftIndexes = byRawText.get(rows[i].text) || []
    const rightIndexes = byRawText.get(rows[j].text) || []
    const keep = leftIndexes[0]
    const gone = rightIndexes[0]
    if (keep === undefined || gone === undefined) continue
    const kept = all[keep]
    const lost = all[gone]
    kept.hits = (Number(kept.hits) || 1) + (Number(lost.hits) || 1)
    kept.conf = Math.max(Number(kept.conf) || 0, Number(lost.conf) || 0)
    kept.at = Math.min(Number(kept.at) || Infinity, Number(lost.at) || Infinity) || kept.at
    if (String(lost.text).length > String(kept.text).length) kept.text = lost.text
    drop.add(gone)
    mergedIndexes.push({ into: short(String(kept.text)), from: short(String(lost.text)), score: Number(score.toFixed(3)) })
  }
}

const vectorByText = {}
for (const row of rows) {
  if (Array.isArray(row.vector) && row.vector.length > 0) vectorByText[keyOf(row.text)] = row.vector
}

fs.mkdirSync(path.dirname(OUT_FILE), { recursive: true })
fs.writeFileSync(
  OUT_FILE,
  JSON.stringify({ version: 1, at: Date.now(), model: MODEL, sameAbove: SAME_ABOVE, byText, vectors: vectorByText }),
)
fs.writeFileSync(SUSPECT_FILE, JSON.stringify({
  version: 1,
  at: Date.now(),
  pairs: suspectPairs.sort((a, b) => b[2] - a[2]).slice(0, 20).map(([i, j, score]) => ({
    a: short(rows[i].text, 30),
    b: short(rows[j].text, 30),
    score: Number(score.toFixed(3)),
  })),
}))

if (drop.size > 0) {
  fs.copyFileSync(BANK_FILE, `${BANK_FILE}.before-merge-${Date.now()}`)
  const next = all.filter((entry, index) => !drop.has(index))
  const bank = JSON.parse(fs.readFileSync(BANK_FILE, 'utf8'))
  bank.entries = next
  bank.updatedAt = Date.now()
  fs.writeFileSync(BANK_FILE, JSON.stringify(bank))
}

console.log(`embed-bank: ${texts.length} 条，${Object.keys(byText).length} 条有同类，并掉 ${drop.size} 条，疑似 ${suspectPairs.length} 对`)
