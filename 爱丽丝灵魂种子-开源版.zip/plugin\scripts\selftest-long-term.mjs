/**
 * 自检：长账的进与并。
 * 跑法：node scripts/selftest-long-term.mjs
 */
import assert from 'node:assert/strict'
import * as bank from '../lib/long-term.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const now = 1_000_000
const weightOf = () => 1

check('新条目进账', () => {
  const out = bank.appendToBank([], [{ kind: 'daily', text: '主人喜欢安静' }], { now, weightOf })
  assert.equal(out.list.length, 1)
  assert.equal(out.added, 1)
  assert.equal(out.list[0].hits, 1)
})

check('同一句话再来一次：不加行，坐实一回', () => {
  const first = bank.appendToBank([], [{ kind: 'daily', text: '主人喜欢安静' }], { now, weightOf })
  const second = bank.appendToBank(first.list, [{ kind: 'daily', text: '主人喜欢安静' }], { now: now + 1, weightOf })
  assert.equal(second.list.length, 1)
  assert.equal(second.list[0].hits, 2)
  assert.equal(second.reinforced, 1)
})

check('空正文不收', () => {
  const out = bank.appendToBank([], [{ kind: 'daily', text: '   ' }], { now, weightOf })
  assert.equal(out.list.length, 0)
})

check('满了按分量取舍，原顺序不乱', () => {
  const list = [
    { at: 1, kind: 'daily', text: '甲', hits: 1 },
    { at: 2, kind: 'daily', text: '乙', hits: 1 },
    { at: 3, kind: 'daily', text: '丙', hits: 1 },
  ]
  const kept = bank.trimBy(list, 2, (entry) => (entry.text === '乙' ? 0.5 : 1))
  assert.deepEqual(kept.map((entry) => entry.text), ['甲', '丙'])
})

check('淡到看不见的忘掉，手写的不忘', () => {
  const list = [
    { at: 1, kind: 'daily', text: '淡了' },
    { at: 2, kind: 'manual', text: '手写的' },
  ]
  const out = bank.settleEntries(list, { now, weightOf: (entry) => (entry.kind === 'manual' ? 1 : 0.01) })
  assert.equal(out.forgotten, 1)
  assert.deepEqual(out.entries.map((entry) => entry.text), ['手写的'])
})

check('意思重合的并成一条，分量相加', () => {
  const list = [
    { at: 1, kind: 'daily', text: '主人喜欢安静', hits: 1, keys: ['主人', '喜欢'] },
    { at: 2, kind: 'daily', text: '主人喜欢安静些', hits: 1, keys: ['主人', '喜欢'] },
  ]
  const out = bank.settleEntries(list, { now, weightOf })
  assert.equal(out.merged, 1)
  assert.equal(out.entries.length, 1)
  assert.equal(out.entries[0].hits, 2)
})

check('作废的条目留着，不并也不忘', () => {
  const list = [{ at: 1, kind: 'daily', text: '旧的对', superseded: true }]
  const out = bank.settleEntries(list, { now, weightOf: () => 0 })
  assert.equal(out.entries.length, 1)
  assert.equal(out.forgotten, 0)
})

check('没变化就报 changed=false', () => {
  const list = [{ at: 1, kind: 'manual', text: '手写的' }]
  const out = bank.settleEntries(list, { now, weightOf })
  assert.equal(out.changed, false)
})

check('面板整册按行写回：底气给满、时刻算现在', () => {
  const out = bank.bankFromLines(['甲', '', '乙'], { now, weightOf })
  assert.deepEqual(out.map((entry) => entry.text), ['甲', '乙'])
  assert.ok(out.every((entry) => entry.conf === 1 && entry.at === now))
})

check('面板整册写回：每条留着自己的时刻', () => {
  const out = bank.bankFromEntries([
    { at: 123, kind: 'daily', text: '旧事', hits: 3 },
    { text: '新事' },
    { text: '   ' },
  ], { now, weightOf })
  assert.equal(out.length, 2)
  assert.equal(out[0].at, 123)
  assert.equal(out[0].hits, 3)
  assert.equal(out[0].conf, 1)
  assert.equal(out[1].at, now)
})

console.log(`\n共 ${count} 项，全过。`)
