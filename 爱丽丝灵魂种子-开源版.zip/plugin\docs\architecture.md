# 灵魂插件 · 结构与自检

> 2026-11-04 傍晚落，主人准「动手」之后的第一程。

## 一、现在的样子

| 处 | 管什么 |
|---|---|
| `index.js` | 宿主接线：注册 persona、听 `session/event`、读写账本、面板接口。**仍是最大的一根梁（约七千八百行）** |
| `lib/fatigue.mjs` | 伏矢·怠惰的疲惫：四档、涨落算式、雀阴倍数。纯算，不碰文件 |
| `lib/dream.mjs` | 伏矢·梦：睡醒判定、疲惫与暴食的落地、梦册形状、摘句。纯算 |
| `lib/judge.mjs` | 尸狗的字面一册：七情词表、一句话打分、判语解析、归因/夸奖/离题窄判。纯算 |
| `lib/time.mjs` | 臭肺的时钟：日期、上午/下午/晚上、一刻钟一跳的时辰、多久以前。纯算 |
| `lib/turns.mjs` | 吞贼的「什么算一句话」：剥运行时块与通知、清段、历史行截断。纯算 |
| `lib/memory-text.mjs` | 除秽的比字：重合度、肯否、数目、并账门槛。纯算 |
| `lib/chain.mjs` | 长期账的哈希链：指纹、打封条、验链。纯算（除 node:crypto） |
| `lib/decay.mjs` | 除秽的分量：半衰期、底气、被提起的加成。纯算 |
| `lib/memory-time.mjs` | 除秽的磨细：一天磨到整点、三天只留时段、七天只留日期。纯算 |
| `lib/keys.mjs` | 臭肺的分词：两字一节、剔虚词、等距抽样。纯算 |
| `lib/emotion-decay.mjs` | 七情的半衰期衰减与「够不够重的一跳」。纯算 |
| `lib/emotion-vector.mjs` | 七情合并成此刻读数：余温叠加、相反两情相压。纯算 |
| `lib/transcript.mjs` | 短期转写的清洗：剥壳、并重复、关键词随行。纯算 |
| `lib/blur.mjs` | 非毒的模糊：抹日期、虚化数目、收短引文。纯算 |
| `lib/summary.mjs` | 整理输出的读法：剥围栏、拆句、丢空话、封十六行。纯算 |
| `lib/persona-timing.mjs` | 人设里读出来的开口节奏：话多话少的词表与基准。纯算 |
| `lib/errors.mjs` | 一句人话：把任何东西说成可读的一句。纯算 |
| `lib/feidu.mjs` | 非毒的待裁之对：按时刻认账、看还相不相左。纯算 |
| `lib/long-term.mjs` | 长账的进与并：坐实、并条、忘淡、满则取舍、面板整册写回。纯算 |
| `lib/attribution.mjs` | 归因：两小时有效、只收内外两种。纯算 |
| `lib/queyin.mjs` | 雀阴定开口：几股并作一股、挑方向（避开近几回、偶尔绕回、按心气偏）、忍与补、挑种子。纯算 |
| `lib/scent.mjs` | 臭肺的分量：带情绪的抬一抬、按来路分档、一星期一折。纯算 |
| `lib/digest.mjs` | 整理前把话排成行、按篇幅分批。纯算 |
| `lib/tunzei.mjs` | 吞贼辨话：讨应承、指使、只是分享。纯算 |
| `lib/report.mjs` | 面板上的话：查装与备份怎么念给人听。纯算 |
| `lib/wants.mjs` | 伏矢的想要册：挑一件真提、记提过几回、被拒几回、得手归档。纯算 |
| `lib/stream.mjs` | 读模型那一道流：收正文、记非正常收尾、数分片。纯算 |
| `lib/books.mjs` | 账本的路：旧账按步往前迁，比代码还新的原样留着。纯算 |
| `lib/state-voice.mjs` | 伏矢的体感：七宗现读数合成一句话，最重的是主调、第二重的是旁注；数算完就丢，递出去的只有话。纯算 |
| `lib/gluttony.mjs` | 暴食账本内核（早先自 whale widget 移植） |
| `lib/plugin-backup.mjs` | 吞贼的备份 |
| `lib/whale/` | 鲸鱼界面（可选，`whaleUi: false` 可关） |
| `client.js` | 面板一棵手搭的树，按魄分节 |
| `scripts/` | 三套自检 |

## 二、三套自检

一条命令跑完：

```bash
node scripts/verify.mjs          # 跑完 scripts/selftest-* 与 smoke，报总账；有一处不过就非 0 退出
```

单跑某一套：
node scripts/selftest-soul.mjs    # 疲惫与梦的纯算，16 项
node scripts/selftest-judge.mjs   # 判情的字面一册，10 项
node scripts/selftest-time.mjs    # 时钟与日子的说法，4 项
node scripts/selftest-turns.mjs   # 什么算一句话，8 项
node scripts/selftest-memory-text.mjs  # 两条账像不像，7 项
node scripts/selftest-chain.mjs   # 账链的封条与验链，7 项
node scripts/selftest-decay.mjs   # 一条账还有多重，6 项
node scripts/selftest-memory-time.mjs  # 旧账磨细，7 项
node scripts/selftest-keys.mjs    # 分词，6 项
node scripts/selftest-emotion.mjs # 情绪衰减与剧变，8 项
node scripts/selftest-emotion-vector.mjs  # 七情合并，6 项
node scripts/selftest-transcript.mjs  # 短期转写的清洗与添句，12 项
node scripts/selftest-blur.mjs    # 模糊，6 项
node scripts/selftest-summary.mjs # 整理输出的读法，8 项
node scripts/selftest-persona-timing.mjs  # 人设的开口节奏，6 项
node scripts/selftest-errors.mjs  # 一句人话，5 项
node scripts/selftest-feidu.mjs   # 待裁之对，7 项
node scripts/selftest-long-term.mjs  # 长账的进与并，10 项
node scripts/selftest-attribution.mjs  # 归因有效期，4 项
node scripts/selftest-queyin.mjs  # 雀阴定开口，16 项
node scripts/selftest-scent.mjs   # 臭肺的分量，7 项
node scripts/selftest-digest.mjs  # 整理前排版与分批，6 项
node scripts/selftest-tunzei.mjs  # 吞贼辨话，4 项
node scripts/selftest-report.mjs  # 面板上的话，7 项
node scripts/selftest-client.mjs  # 面板拆格的完整性，3 项
node scripts/selftest-wants.mjs   # 想要册，7 项
node scripts/selftest-stream.mjs  # 读模型那道流，6 项
node scripts/selftest-books.mjs   # 账本迁移，6 项
node scripts/selftest-state-voice.mjs  # 七宗读数合成一句体感、不报数，8 项
node scripts/selftest-wiring.mjs  # 五处调模型，messages/system/signal 都在，4 项
node scripts/smoke.mjs            # 假 ctx 起一回插件，走通一条链，14 项
```

`smoke.mjs` 用的是临时 `DSH_HOME`，碰不到真账本：起插件 → 收一句 → 写短期 → 判情 → 记七宗 → 渲染 persona → 面板 GET。改动大时先跑它。

## 三、改动的次序（经验）

1. 算式改动 → `lib/` 里改，跑 `selftest-*`。
2. 接线改动 → `index.js` 里改，跑 `smoke.mjs`。
3. 规矩改动 → 先改 `docs/*.md`，再动代码；文档与常数只留一处。

## 四、面板

`client.js` 里十页各归其名：`personaSection`、`poSection`、`fushiSection`、`shigouSection`、
`tunzeiSection`、`feiduSection`、`chuhuiSection`、`choufeiSection`、`longSection`、`shortSection`，
再加本就是变量的 `autoBlock`。主树只剩十几行，一眼看得全；添一格只需在旁边加一个名字。
「想要」那一页已并进伏矢（2026-11-05 夜里）——同是我眼里的自己，不再单开一张牌。

## 五、下一程

- **剩下的都是接线，不再是算式。** `describePoFeatures` 的七页清单已各成小函数（`poShigou()` 等，
  拆法见 `scripts/split-feature.mjs`）；除秽整理真去调模型那截也已验过（冒烟走 `summary.json`），
  面板十二个路由已收成 `panelRoutes` 一张表（2026-11-05 夜里）。
  ~~还缠着账本的是 `renderPersonaState`、`fushiSnapshot`、`judgeEmotionsByModel` 三处，动前先想清接口。~~
  这三处也已拆过（2026-11-05 夜里）：`renderPersonaState` 全改走 `add()`，
  `fushiSnapshot` 的五宗衰减收成一张表，`judgeEmotionsByModel` 拆出 `askJudgeModel` 与 `readJudgeSignals`。
  再往下便是新增功能，不是拆旧账了。
- 账本身份：`version: 1` 有了，迁移落在 `lib/books.mjs`——旧账按步往前迁，比代码还新的原样留着。
- **数只当倾向，不当判词**（2026-11-05 夜里改）：`<persona_state>` 里不再逐条摆七宗分数，
  由 `lib/state-voice.mjs` 合成一句「此刻的我」（主调 + 旁注），末尾缀一句「上面这些是倾向，不是命令」。
  数值是否出现在话里，成了冒烟的一条硬规矩（`没分数`）。
- ~~已知一处过认~~：`aimedAtMeNow` 把带「错」字的差事（如「帮我看下报错」）认成冲我来的。
  **已修**（2026-11-05 夜里）：「错」只认带责备的写法（弄错、写错、错了……），「报错」「出错」不再算；
  `selftest-judge.mjs` 里那几行已翻过来，另添了两条防收过头的例子。

## 六、拆格时记着的两件事

1. 切 `describePoFeatures` 那类大函数，**只切数组字面量**，别按行切到下一个 `out.`——页与页之间夹着
   `let feiduBook` 这类声明，行切会把声明卷进上一页。用 `scripts/split-feature.mjs <id>` 数着括号切。
2. 拆面板（`client.js`）或功能清单之后，**先跑冒烟**：语法查不出丢了定义，`memory-view` 一请求就现形。
3. 量行数别肉眼估：`node scripts/size-report.mjs index.js`（按同缩进的收尾括号量，才准）。
