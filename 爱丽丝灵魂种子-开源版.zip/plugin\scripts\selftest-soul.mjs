/**
 * 自检：疲惫与梦的两册纯算。
 * 跑法：node scripts/selftest-soul.mjs
 * 只要有一处不合，退出码非 0。
 */
import assert from 'node:assert/strict'
import * as fatigue from '../lib/fatigue.mjs'
import * as dream from '../lib/dream.mjs'

let count = 0
const check = (name, fn) => {
  fn()
  count += 1
  console.log(`  ok  ${name}`)
}

console.log('伏矢 · 疲惫')
check('四档边界', () => {
  assert.equal(fatigue.tierOf(0), '精神')
  assert.equal(fatigue.tierOf(40), '精神')
  assert.equal(fatigue.tierOf(41), '微倦')
  assert.equal(fatigue.tierOf(65), '微倦')
  assert.equal(fatigue.tierOf(66), '乏')
  assert.equal(fatigue.tierOf(85), '乏')
  assert.equal(fatigue.tierOf(86), '怠惰')
  assert.equal(fatigue.tierOf(999), '怠惰')
})
check('一句短语', () => {
  assert.equal(fatigue.phraseOf(62), '62/100（微倦）')
})
check('在场半小时：5 分', () => {
  const r = fatigue.tickDelta({ elapsedMs: 30 * 60 * 1000 - 1 })
  assert.ok(Math.abs(r.delta - 5) < 0.01, `got ${r.delta}`)
  assert.equal(r.why, '在场')
})
check('在场一分钟一分钟地攒：一小时共 10 分', () => {
  let total = 0
  for (let i = 0; i < 60; i += 1) total += fatigue.tickDelta({ elapsedMs: 60 * 1000 }).delta
  assert.ok(Math.abs(total - 10) < 0.01, `got ${total}`)
})
check('一次隔 45 分钟：算静场，不满一小时不退', () => {
  const r = fatigue.tickDelta({ elapsedMs: 45 * 60 * 1000 })
  assert.equal(r.why, '静场')
  assert.equal(r.delta, 0)
})
check('重活再添五', () => {
  let total = 0
  for (let i = 0; i < 60; i += 1) total += fatigue.tickDelta({ elapsedMs: 60 * 1000, heavy: true }).delta
  assert.ok(Math.abs(total - 15) < 0.01, `got ${total}`)
})
check('重活两条：话够长，或动手够多', () => {
  assert.equal(fatigue.isHeavyWork({ textLength: 59 }), false)
  assert.equal(fatigue.isHeavyWork({ textLength: 60 }), true)
  assert.equal(fatigue.isHeavyWork({ toolCalls: 2 }), false)
  assert.equal(fatigue.isHeavyWork({ toolCalls: 3 }), true)
  assert.equal(fatigue.isHeavyWork({}), false)
})
check('情绪拧着再 +2', () => {
  const r = fatigue.tickDelta({ elapsedMs: 10 * 60 * 1000, emotional: true })
  assert.equal(r.why, '情绪拧着')
  assert.ok(r.delta > 2)
})
check('静场只退不涨', () => {
  assert.equal(fatigue.tickDelta({ elapsedMs: 30 * 60 * 1000 }).delta, 0)
  assert.equal(fatigue.tickDelta({ elapsedMs: 3 * 60 * 60 * 1000 }).delta, -3)
  assert.equal(fatigue.tickDelta({ elapsedMs: 99 * 60 * 60 * 1000 }).delta, -12)
})
check('退：5% 封顶 4，至少 1', () => {
  assert.equal(fatigue.relaxDrop(100), 4)
  assert.equal(fatigue.relaxDrop(60), 3)
  assert.equal(fatigue.relaxDrop(10), 1)
})

console.log('伏矢 · 梦')
check('空档归一', () => {
  const book = dream.normalizeBook(null)
  assert.equal(book.dreams.length, 0)
  assert.equal(book.groggyLeft, 0)
  assert.equal(book.wantDream, false)
})
check('迷糊不超两轮', () => {
  assert.equal(dream.normalizeBook({ groggyLeft: 9 }).groggyLeft, 2)
  assert.equal(dream.groggyRound(2), 1)
  assert.equal(dream.groggyRound(1), 2)
  assert.equal(dream.groggyRound(0), 0)
})
check('梦只留第一句', () => {
  assert.equal(dream.firstLine('我梦见门口坐着一个人。后面还有很多。'), '我梦见门口坐着一个人。')
  assert.equal(dream.firstLine(''), '')
  assert.ok(dream.firstLine('甲'.repeat(200)).length <= 62)
})
check('没睡够不算睡', () => {
  const r = dream.settleWake({ gapMs: 3.9 * 60 * 60 * 1000, fatigue: 80, gluttony: 100 })
  assert.equal(r.slept, false)
  assert.equal(r.groggyLeft, null)
})
check('睡一觉：疲惫降到三成、暴食减半、迷糊两轮', () => {
  const r = dream.settleWake({ gapMs: 5 * 60 * 60 * 1000, fatigue: 80, gluttony: 100, lastDreamAt: 0, now: 20 * 60 * 60 * 1000 })
  assert.equal(r.slept, true)
  assert.equal(r.fatigue, 30)
  assert.equal(r.gluttony, 50)
  assert.equal(r.groggyLeft, 2)
  assert.equal(r.wantDream, true)
})
check('只降不升：低值不被抬', () => {
  const r = dream.settleWake({ gapMs: 9 * 60 * 60 * 1000, fatigue: 8, gluttony: 4, lastDreamAt: 0, now: 1000 })
  assert.equal(r.fatigue, 8)
  assert.equal(r.gluttony, 2)
  assert.equal(r.wantDream, false)
})
check('距上回梦不足八个钟头不做梦', () => {
  const now = 100 * 60 * 60 * 1000
  const r = dream.settleWake({ gapMs: 5 * 60 * 60 * 1000, fatigue: 70, gluttony: 10, lastDreamAt: now - 60 * 60 * 1000, now })
  assert.equal(r.wantDream, false)
})

console.log(`\n共 ${count} 项，全过。`)
