/**
 * 自检：旧账磨细。
 * 跑法：node scripts/selftest-memory-time.mjs
 */
import assert from 'node:assert/strict'
import * as memoTime from '../lib/memory-time.mjs'
import * as time from '../lib/time.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

const now = new Date(2026, 10, 4, 19, 30, 15, 500).getTime()
const hoursAgo = (h) => now - h * 60 * 60 * 1000
const daysAgo = (d) => now - d * 24 * 60 * 60 * 1000

check('一天以内不动', () => {
  const { entries, changed } = memoTime.blurEntries([{ at: hoursAgo(3), text: '近事' }], now)
  assert.equal(changed, 0)
  assert.equal(entries[0].precision, undefined)
})

check('一天以上磨到整点', () => {
  const { entries, changed } = memoTime.blurEntries([{ at: daysAgo(2), text: '甲' }], now)
  assert.equal(changed, 1)
  assert.equal(entries[0].precision, 'hour')
  assert.equal(entries[0].at % memoTime.HOUR_MS, 0)
})

check('三天以上只剩上午/下午/晚上', () => {
  const { entries } = memoTime.blurEntries([{ at: daysAgo(4), text: '乙' }], now)
  assert.equal(entries[0].precision, 'period')
  assert.ok(['上午', '下午', '晚上'].includes(entries[0].dayPart))
  assert.ok(entries[0].when.includes(entries[0].dayPart))
})

check('七天以上只剩日期', () => {
  const { entries } = memoTime.blurEntries([{ at: daysAgo(9), text: '丙' }], now)
  assert.equal(entries[0].precision, 'date')
  assert.equal(entries[0].dayPart, undefined)
  assert.equal(entries[0].when, time.dayStamp(entries[0].at))
})

check('磨过的再磨一遍不动', () => {
  const first = memoTime.blurEntries([{ at: daysAgo(2), text: '甲' }], now)
  const second = memoTime.blurEntries(first.entries, now)
  assert.equal(second.changed, 0)
})

check('正文与次序不动', () => {
  const input = [
    { at: daysAgo(9), text: '旧' },
    { at: daysAgo(4), text: '中' },
    { at: hoursAgo(1), text: '新' },
  ]
  const { entries } = memoTime.blurEntries(input, now)
  assert.deepEqual(entries.map((entry) => entry.text), ['旧', '中', '新'])
})

check('坏时刻原样留着', () => {
  const { entries, changed } = memoTime.blurEntries([{ at: 0, text: '没时刻' }, { text: '也没' }], now)
  assert.equal(changed, 0)
  assert.equal(entries.length, 2)
})

console.log(`\n共 ${count} 项，全过。`)
