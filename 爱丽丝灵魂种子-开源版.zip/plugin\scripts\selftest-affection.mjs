/**
 * 自检：亲密度那条轴（爱剩多少，决定想不想先开口）与未了之事的逾期分量。
 * 跑法：node scripts/selftest-affection.mjs
 */
import assert from 'node:assert/strict'
import { affectionAxis, loveScoreOf } from '../lib/affection.mjs'
import { decayedEmotions } from '../lib/emotion-decay.mjs'
import {
  normalizeUnfinished,
  noteUnfinished,
  pickUnfinished,
  unfinishedLine,
  overdueOf,
  OVERDUE_DUE_MS,
  ADMIT_AFTER_STEPS,
} from '../lib/unfinished.mjs'

const NOW = 1_800_000_000_000
let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('爱淡的时候收着，不抢着开口', () => {
  const axis = affectionAxis(20)
  assert.ok(axis.factor > 1)
  assert.equal(axis.tier, '平常')
})

check('爱浓的时候挨近，间隔缩短', () => {
  const close = affectionAxis(70)
  const burning = affectionAxis(90)
  assert.ok(close.factor < 1)
  assert.ok(burning.factor < close.factor)
})

check('从七情账里取爱的现值，取最浓的一条', () => {
  const records = [
    { at: NOW, emotions: [{ id: 'ai', name: '爱', score: 0.4 }] },
    { at: NOW, emotions: [{ id: 'ai', name: '爱', score: 0.8 }] },
    { at: NOW, emotions: [{ id: 'xi', name: '喜', score: 0.9 }] },
  ]
  assert.equal(loveScoreOf(records, decayedEmotions, NOW), 80)
})

check('搁过一期就有分量，翻倍不止一期', () => {
  const book = noteUnfinished(normalizeUnfinished(null), { text: '替主人查省 token 的办法', kind: 'unsaid' }, NOW)
  const item = book.items[0]
  const due = OVERDUE_DUE_MS.unsaid
  assert.equal(overdueOf(item, NOW + due - 1).steps, 0)
  assert.equal(overdueOf(item, NOW + due).factor, 2)
  assert.equal(overdueOf(item, NOW + due * 2 + 1).factor, 4)
})

check('拖过三期就得认账，不再只当「又想到了」', () => {
  const book = noteUnfinished(normalizeUnfinished(null), { text: '主人说的那本诗集还没找来', kind: 'unsaid' }, NOW)
  const item = book.items[0]
  const late = NOW + OVERDUE_DUE_MS.unsaid * ADMIT_AFTER_STEPS + 1
  const line = unfinishedLine(item, late)
  assert.ok(line.includes('办不到'), line)
})

check('逾期最重的那件先浮上来', () => {
  const first = noteUnfinished(normalizeUnfinished(null), { text: '旧事一件', kind: 'unsaid' }, NOW)
  const both = noteUnfinished(first, { text: '新事一件', kind: 'unsaid' }, NOW)
  const later = NOW + OVERDUE_DUE_MS.unsaid * 3 + 1
  assert.equal(pickUnfinished(both, later).text, '旧事一件')
})

console.log(`\n共 ${count} 项，全过。`)
