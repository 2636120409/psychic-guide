/**
 * 自检：两条账像不像。
 * 跑法：node scripts/selftest-memory-text.mjs
 */
import assert from 'node:assert/strict'
import * as memo from '../lib/memory-text.mjs'

let count = 0
const check = (name, fn) => { fn(); count += 1; console.log(`  ok  ${name}`) }

check('标点空格与大小写不算数', () => {
  assert.equal(memo.normalizeMemoryText(' 主人 喜欢，插件！ '), '主人喜欢插件')
})

check('同一句话重合为 1', () => {
  assert.equal(memo.textOverlap('改用哈希链记长期账', '改用哈希链记长期账'), 1)
})

check('不相干的两句重合很低', () => {
  assert.ok(memo.textOverlap('今天吃了面', '午夜十二点的钟声') < 0.2)
})

check('肯否先分开', () => {
  assert.equal(memo.memoryPolarity('喜欢'), 1)
  assert.equal(memo.memoryPolarity('不喜欢'), -1)
})

check('数目排序后比对', () => {
  assert.equal(memo.memoryNumbers('三月七号，花了 12.5 块'), '12.5')
  assert.equal(memo.memoryNumbers('没有数目'), '')
})

check('够像才并：同义并得，肯否不并，数目不并', () => {
  assert.equal(memo.canMergeMemory('主人喜欢安静', '主人喜欢安静些'), true)
  assert.equal(memo.canMergeMemory('主人喜欢安静', '主人不喜欢安静'), false)
  assert.equal(memo.canMergeMemory('定了三点的闹钟', '定了四点的闹钟'), false)
  assert.equal(memo.canMergeMemory('', '空'), false)
})

check('门槛值随册走', () => {
  assert.equal(memo.MERGE_OVERLAP, 0.72)
})

console.log(`\n共 ${count} 项，全过。`)
