/**
 * 一条命令验完：语法 + 全部自检。
 *
 * 跑法：node scripts/verify.mjs
 * 先对宿主与客户端做 node --check，再逐个起子进程跑 scripts/selftest-* 与 smoke；
 * 有一处不过就非 0 退出。
 */
import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const here = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'))
const root = path.dirname(here)
const rows = []
let failed = 0

const note = (name, pass, line) => {
  rows.push({ name, pass, line: line || '' })
  if (!pass) failed += 1
}

// 一、语法：宿主、客户端、以及 lib 下每一册
const syntaxFiles = ['index.js', 'client.js']
const libDir = path.join(root, 'lib')
if (fs.existsSync(libDir)) {
  for (const name of fs.readdirSync(libDir)) {
    if (name.endsWith('.mjs')) syntaxFiles.push(path.join('lib', name))
  }
}
for (const rel of syntaxFiles) {
  const full = path.join(root, rel)
  if (!fs.existsSync(full)) continue
  const result = spawnSync(process.execPath, ['--check', full], { encoding: 'utf8' })
  const detail = (result.stderr || '').split(/\r?\n/).find((line) => line.trim().length > 0) || ''
  note(`语法 ${rel}`, result.status === 0, result.status === 0 ? '通过' : detail.slice(0, 80))
}

// 二、自检：scripts/selftest-* 与 smoke
const files = fs.readdirSync(here)
  .filter((name) => /^selftest-.*\.mjs$/.test(name) || name === 'smoke.mjs')
  .sort()
for (const name of files) {
  const result = spawnSync(process.execPath, [path.join(here, name)], { encoding: 'utf8' })
  const out = `${result.stdout || ''}${result.stderr || ''}`
  const line = out.split(/\r?\n/).reverse().find((text) => /共 \d+ 项|全过/.test(text)) || ''
  note(name, result.status === 0, line.trim())
}

const width = Math.max(...rows.map((row) => row.name.length))
for (const row of rows) {
  console.log(`${row.pass ? 'ok  ' : 'FAIL'} ${row.name.padEnd(width)}  ${row.line}`)
}
console.log(`\n${rows.length - failed}/${rows.length} 项通过。`)
process.exit(failed === 0 ? 0 : 1)
